AURA X NEWS v1.3
White-background Malayalam XAUUSD news, CME and outlook platform
built by rafi

INSTALL / UPDATE
----------------
1. Close AuRa X News.
2. Extract this ZIP completely.
3. Double-click:

   Install-AuRa-X-News.cmd

4. Open the Desktop shortcut:

   AuRa X News

No Docker and no MT5 are required. Existing cache, saved stories and
translations are retained during an update.

CME NEWS — ONE TOP-LEVEL TAB
----------------------------
The previous three top-level CME tabs are replaced with one:

   CME News

Inside CME News there are four smaller sections:

- All CME
- Live News
- Upcoming
- Outlook

Every CME-related source is grouped under this one section, including official
RSS, the official Economic Release Calendar, Metals/FX commentary, press
releases, CME Gold outlook links and Metals Update links.

FASTER COLLECTION
-----------------
- Official CME RSS: scheduled every 60 seconds
- Official Investing.com RSS: scheduled every 60 seconds
- CME/Investing Gold-specific indexes: scheduled every 120 seconds
- CME official Economic Release Calendar: scheduled separately
- Local dashboard cache check: every 10 seconds
- Priority sources are fetched concurrently, so one slow source no longer
  delays all other CME or Investing.com feeds
- Manual Refresh news forces every source to become due immediately
- Up to 180 items are read from each CME/Investing priority feed
- Previously collected stories remain available in the local SQLite cache

ADDITIONAL COVERAGE
-------------------
CME:
- Official CME Economic Research RSS
- Featured Reports
- Financial Economic Releases
- Daily Market Commentary
- Metals Commentary
- FX Commentary
- Press Releases
- Gold and Metals index
- Macro and Economic Research index
- Gold Outlook index
- Metals Update index
- Official Economic Release Calendar

Investing.com:
- Forex News RSS
- Commodities News RSS
- Economic Indicators RSS
- Metals Analysis RSS
- Gold latest-news index
- Gold analysis index
- Dollar and macro news index
- Gold forecast/outlook index

IMPORTANT
---------
RSS is near-live publisher delivery, not a paid zero-latency professional
newswire. Polling is intentionally limited to responsible intervals.

Google News index feeds are clearly labelled as indexed links. The original
CME Group or Investing.com page opens when the user selects Open original.

Malayalam translation, impact analysis and outlook extraction are automated.
They are educational information, not guaranteed trade predictions.
