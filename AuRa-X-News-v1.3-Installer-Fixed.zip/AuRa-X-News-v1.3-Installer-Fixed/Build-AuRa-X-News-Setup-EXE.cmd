@echo off
setlocal
title Build AuRa X News Setup EXE
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" (
  echo Inno Setup 6 is not installed.
  echo Install it, then run this file again.
  pause
  exit /b 1
)
"%ISCC%" "%~dp0installer\AuRa-X-News.iss"
echo.
echo Build completed. Check installer\Output.
pause
