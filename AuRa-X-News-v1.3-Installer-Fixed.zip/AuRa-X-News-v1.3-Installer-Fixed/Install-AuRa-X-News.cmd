@echo off
setlocal
title AuRa X News v1.3 Installer
echo.
echo ============================================
echo  AuRa X News v1.3 Installer
echo  XAUUSD news and Gold outlook platform
echo  built by rafi
echo ============================================
echo.
echo This window will remain open and show the result.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\Install.ps1"
echo.
pause
