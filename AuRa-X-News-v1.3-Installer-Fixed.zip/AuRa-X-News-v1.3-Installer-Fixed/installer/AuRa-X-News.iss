#define MyAppName "AuRa X News"
#define MyAppVersion "1.3"
#define MyAppPublisher "rafi"

[Setup]
AppId={{ACAEF68B-7BB9-4056-A55D-802942F3D70C}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={tmp}\AuRa-X-News-Setup
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=Output
OutputBaseFilename=AuRa-X-News-Setup-v1.3
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
Uninstallable=no

[Files]
Source: "..\*"; DestDir: "{tmp}\AuRa-X-News"; Flags: recursesubdirs createallsubdirs ignoreversion

[Run]
Filename: "{tmp}\AuRa-X-News\Install-AuRa-X-News.cmd"; Flags: waituntilterminated
