param(
    [string]$InstallRoot = "",
    [string]$LogPath = ""
)

$ErrorActionPreference = "Stop"
$success = $false
$transcriptStarted = $false

if ([string]::IsNullOrWhiteSpace($InstallRoot)) {
    $InstallRoot = Join-Path $env:LOCALAPPDATA "Programs\AuRaXNews"
}

if ([string]::IsNullOrWhiteSpace($LogPath)) {
    $desktopPath = [Environment]::GetFolderPath("Desktop")
    $LogPath = Join-Path $desktopPath "AuRa-X-News-Install-Log.txt"
}

function Find-Python {
    $candidates = @(
        [pscustomobject]@{
            Exe = "py.exe"
            PrefixArgs = @("-3")
        },
        [pscustomobject]@{
            Exe = "python.exe"
            PrefixArgs = @()
        },
        [pscustomobject]@{
            Exe = (Join-Path $env:LOCALAPPDATA "Programs\Python\Python314\python.exe")
            PrefixArgs = @()
        },
        [pscustomobject]@{
            Exe = (Join-Path $env:LOCALAPPDATA "Python\pythoncore-3.14-64\python.exe")
            PrefixArgs = @()
        },
        [pscustomobject]@{
            Exe = (Join-Path $env:LOCALAPPDATA "Programs\Python\Python313\python.exe")
            PrefixArgs = @()
        },
        [pscustomobject]@{
            Exe = (Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe")
            PrefixArgs = @()
        },
        [pscustomobject]@{
            Exe = (Join-Path $env:LOCALAPPDATA "Programs\Python\Python311\python.exe")
            PrefixArgs = @()
        }
    )

    foreach ($candidate in $candidates) {
        try {
            if ([System.IO.Path]::IsPathRooted($candidate.Exe)) {
                if (!(Test-Path $candidate.Exe -PathType Leaf)) {
                    continue
                }
            }

            $commandArgs = @()
            $commandArgs += $candidate.PrefixArgs
            $commandArgs += @("-c", "import sys; print(sys.executable)")

            $null = & $candidate.Exe @commandArgs 2>$null

            if ($LASTEXITCODE -eq 0) {
                return $candidate
            }
        }
        catch {
        }
    }

    return $null
}

function Test-LocalPort {
    param(
        [string]$HostName,
        [int]$Port,
        [int]$TimeoutMilliseconds = 500
    )

    $client = New-Object System.Net.Sockets.TcpClient

    try {
        $result = $client.BeginConnect($HostName, $Port, $null, $null)

        if (!$result.AsyncWaitHandle.WaitOne($TimeoutMilliseconds)) {
            return $false
        }

        $client.EndConnect($result)
        return $true
    }
    catch {
        return $false
    }
    finally {
        $client.Close()
    }
}

try {
    try {
        Start-Transcript -Path $LogPath -Force | Out-Null
        $transcriptStarted = $true
    }
    catch {
    }

    $sourceRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\app")).Path

    Write-Host ""
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host " AuRa X News v1.3 Installer" -ForegroundColor Cyan
    Write-Host " XAUUSD news and Gold outlook platform" -ForegroundColor Cyan
    Write-Host " built by rafi" -ForegroundColor DarkCyan
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Destination: $InstallRoot"
    Write-Host "Installation log: $LogPath"
    Write-Host ""

    $pythonCommand = Find-Python

    if ($null -eq $pythonCommand) {
        throw "Python 3.11 or newer was not found. Install Python from python.org, enable Add Python to PATH, and run this installer again."
    }

    New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null

    Write-Host "Copying AuRa X News files..." -ForegroundColor Cyan

    $null = & robocopy.exe $sourceRoot $InstallRoot /MIR /XD ".venv" "data" "logs" "__pycache__" /XF "*.pyc"
    $copyExitCode = $LASTEXITCODE

    if ($copyExitCode -ge 8) {
        throw "Application copy failed. Robocopy exit code: $copyExitCode"
    }

    $venv = Join-Path $InstallRoot ".venv"
    $venvPython = Join-Path $venv "Scripts\python.exe"

    if (!(Test-Path $venvPython -PathType Leaf)) {
        Write-Host "Creating private Python environment..." -ForegroundColor Cyan

        $venvArgs = @()
        $venvArgs += $pythonCommand.PrefixArgs
        $venvArgs += @("-m", "venv", $venv)

        & $pythonCommand.Exe @venvArgs

        if ($LASTEXITCODE -ne 0) {
            throw "Could not create the private Python environment."
        }
    }

    Write-Host "Installing fast CME, Investing.com, Malayalam translation, and outlook components..." -ForegroundColor Cyan

    & $venvPython -m pip install --disable-pip-version-check --upgrade pip

    if ($LASTEXITCODE -ne 0) {
        throw "pip upgrade failed."
    }

    $requirements = Join-Path $InstallRoot "requirements.txt"
    & $venvPython -m pip install --disable-pip-version-check -r $requirements

    if ($LASTEXITCODE -ne 0) {
        throw "Dependency installation failed."
    }

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)

    $launcher = Join-Path $InstallRoot "Start-AuRa-X-News.vbs"
    $launcherContent = 'Set shell = CreateObject("WScript.Shell")' + [Environment]::NewLine
    $launcherContent += 'shell.CurrentDirectory = "' + $InstallRoot + '"' + [Environment]::NewLine
    $launcherContent += 'shell.Run Chr(34) & "' + $venvPython + '" & Chr(34) & " " & Chr(34) & "' + (Join-Path $InstallRoot "main.py") + '" & Chr(34), 0, False' + [Environment]::NewLine
    [System.IO.File]::WriteAllText($launcher, $launcherContent, $utf8NoBom)

    $uninstaller = Join-Path $InstallRoot "Uninstall-AuRa-X-News.cmd"
    $uninstallContent = '@echo off' + [Environment]::NewLine
    $uninstallContent += 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' + (Join-Path $InstallRoot "Uninstall.ps1") + '"' + [Environment]::NewLine
    $uninstallContent += 'pause' + [Environment]::NewLine
    [System.IO.File]::WriteAllText($uninstaller, $uninstallContent, $utf8NoBom)

    $shell = New-Object -ComObject WScript.Shell
    $desktop = [Environment]::GetFolderPath("Desktop")

    $oldShortcut = Join-Path $desktop "XAU News Malayalam.lnk"
    Remove-Item $oldShortcut -Force -ErrorAction SilentlyContinue

    $desktopLink = Join-Path $desktop "AuRa X News.lnk"
    $desktopShortcut = $shell.CreateShortcut($desktopLink)
    $desktopShortcut.TargetPath = "wscript.exe"
    $desktopShortcut.Arguments = '"' + $launcher + '"'
    $desktopShortcut.WorkingDirectory = $InstallRoot
    $desktopShortcut.Description = "Malayalam XAUUSD news and outlook reader"
    $desktopShortcut.Save()

    $startMenu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\AuRa X News"
    New-Item -ItemType Directory -Force -Path $startMenu | Out-Null

    $startLink = Join-Path $startMenu "AuRa X News.lnk"
    $startShortcut = $shell.CreateShortcut($startLink)
    $startShortcut.TargetPath = "wscript.exe"
    $startShortcut.Arguments = '"' + $launcher + '"'
    $startShortcut.WorkingDirectory = $InstallRoot
    $startShortcut.Description = "Malayalam XAUUSD news and outlook reader"
    $startShortcut.Save()

    $uninstallLink = Join-Path $startMenu "Uninstall AuRa X News.lnk"
    $uninstallShortcut = $shell.CreateShortcut($uninstallLink)
    $uninstallShortcut.TargetPath = $uninstaller
    $uninstallShortcut.WorkingDirectory = $InstallRoot
    $uninstallShortcut.Save()

    Write-Host ""
    Write-Host "Starting AuRa X News..." -ForegroundColor Cyan

    Start-Process -FilePath "wscript.exe" -ArgumentList ('"' + $launcher + '"')

    $ready = $false

    for ($attempt = 0; $attempt -lt 40; $attempt++) {
        Start-Sleep -Milliseconds 500

        if (Test-LocalPort -HostName "127.0.0.1" -Port 8767) {
            $ready = $true
            break
        }
    }

    Write-Host ""

    if ($ready) {
        Write-Host "Local news service: ONLINE" -ForegroundColor Green
    }
    else {
        Write-Warning "The shortcut was created, but the local service did not answer within 20 seconds. Open the desktop shortcut once more if the window does not appear."
    }

    Write-Host "AuRa X News v1.3 installed successfully." -ForegroundColor Green
    Write-Host "Desktop shortcut: AuRa X News"
    Write-Host "No Docker and no MT5 are required."
    Write-Host ""
    Write-Host "The first news collection and Malayalam translation can take 1-3 minutes." -ForegroundColor Yellow
    Write-Host "Prediction cards show source-published outlooks, not guaranteed price forecasts." -ForegroundColor Yellow

    $success = $true
}
catch {
    Write-Host ""
    Write-Host "AURA X NEWS INSTALLATION ERROR" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host "Full log: $LogPath" -ForegroundColor Yellow
}
finally {
    if ($transcriptStarted) {
        try {
            Stop-Transcript | Out-Null
        }
        catch {
        }
    }
}

if (!$success) {
    exit 1
}

exit 0
