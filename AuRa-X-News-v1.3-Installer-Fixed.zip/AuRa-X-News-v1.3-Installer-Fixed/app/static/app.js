const state = {
  group: "all",
  timeline: "all",
  direction: "all",
  cmeSection: "all",
  search: "",
  items: [],
  counts: {},
  sourceStatus: [],
  signature: "",
  readingUntil: 0,
  pending: false,
  scrollByView: new Map(),
};

const labels = {
  all: "All XAU News",
  high: "High Impact",
  predictions: "Gold Outlook & Predictions",
  cme: "CME News",
  forexfactory: "Forex Factory",
  investing: "Investing.com",
  tradingview: "TradingView",
  official: "Official Macro",
  other: "Other Gold Sources",
  saved: "Saved",
};

const $ = id => document.getElementById(id);

function escapeHtml(value) {
  return String(value ?? "").replace(
    /[&<>"']/g,
    character => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    })[character],
  );
}

function formatDate(value) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleString([], {
    weekday: "short",
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    timeZoneName: "short",
  });
}

function translationLabel(status) {
  if (status === "WEB_TRANSLATED") {
    return "Web Malayalam translation";
  }
  if (status === "RETRY") {
    return "Translation retry pending · local explanation available";
  }
  return "Local Malayalam fallback · web translation pending";
}

function predictionTarget(item) {
  const low = item.prediction_target_low || "";
  const high = item.prediction_target_high || "";
  if (!low) return "No explicit price target";
  if (high && high !== low) {
    return `US$${low} – US$${high}`;
  }
  return `US$${low}`;
}

function predictionPercent(item) {
  const low = item.prediction_percent_low || "";
  const high = item.prediction_percent_high || "";
  if (!low) return "Not stated";
  if (high && high !== low) {
    return `${low}% – ${high}%`;
  }
  return `${low}%`;
}

function predictionBox(item) {
  if (!Number(item.is_prediction || 0)) return "";
  const direction = String(
    item.prediction_direction || "MIXED",
  ).toLowerCase();

  return `
    <div class="prediction-box ${direction}">
      <div class="prediction-box-head">
        <strong>SOURCE OUTLOOK</strong>
        <span class="prediction-direction ${direction}">
          ${escapeHtml(item.prediction_direction || "MIXED")}
        </span>
      </div>
      <div class="prediction-metrics">
        <div>
          <span>Horizon</span>
          <strong>${escapeHtml(item.prediction_horizon || "UNSPECIFIED")}</strong>
        </div>
        <div>
          <span>Price target</span>
          <strong>${escapeHtml(predictionTarget(item))}</strong>
        </div>
        <div>
          <span>Expected move</span>
          <strong>${escapeHtml(predictionPercent(item))}</strong>
        </div>
        <div>
          <span>Basis</span>
          <strong>${escapeHtml(item.prediction_basis || "SOURCE FORECAST")}</strong>
        </div>
      </div>
      <p>
        <strong>Malayalam outlook explanation:</strong>
        ${escapeHtml(
          item.prediction_explanation_ml
          || "Source outlook details ലഭ്യമല്ല.",
        )}
      </p>
      <small>
        Extraction confidence:
        ${escapeHtml(item.prediction_strength || 0)}%.
        This measures how clearly the headline/summary states an outlook;
        it is not forecast accuracy.
      </small>
    </div>`;
}

function card(item) {
  const impact = String(
    item.impact_level || "LOW",
  ).toLowerCase();
  const bias = String(
    item.xau_bias || "MIXED",
  ).toLowerCase();
  const isCalendar = item.kind === "calendar";
  const saved = Number(item.saved || 0) === 1;
  const isPrediction = Number(item.is_prediction || 0) === 1;

  const calendarValues = isCalendar ? `
    <div class="calendar-values">
      <div>
        <span>Actual</span>
        <strong>${escapeHtml(item.actual || "—")}</strong>
      </div>
      <div>
        <span>Forecast</span>
        <strong>${escapeHtml(item.forecast || "—")}</strong>
      </div>
      <div>
        <span>Previous</span>
        <strong>${escapeHtml(item.previous || "—")}</strong>
      </div>
    </div>` : "";

  return `
    <article
      class="news-card ${impact} ${isPrediction ? "prediction-card" : ""}"
      data-id="${escapeHtml(item.id)}"
    >
      <div class="card-head">
        <div>
          <div class="source-label">${escapeHtml(item.source)}</div>
          <div class="card-time">
            ${escapeHtml(formatDate(item.event_time || item.published_at))}
            · ${escapeHtml(item.status)}
          </div>
        </div>
        <div class="head-badges">
          ${isPrediction ? `<span class="outlook-badge">OUTLOOK</span>` : ""}
          <span class="impact-badge ${impact}">
            ${escapeHtml(item.impact_level)} IMPACT
          </span>
        </div>
      </div>

      <div class="card-body">
        <h2 class="mal-title">
          ${escapeHtml(item.mal_title || item.title)}
        </h2>
        <p class="english-title">
          ${escapeHtml(item.title)}
        </p>
        <span class="translation-note">
          ${escapeHtml(translationLabel(item.translation_status))}
        </span>

        ${calendarValues}

        ${item.mal_summary ? `
          <p class="summary">
            <strong>മലയാളം സംഗ്രഹം:</strong>
            ${escapeHtml(item.mal_summary)}
          </p>` : ""}

        ${item.summary ? `
          <p class="summary">
            <strong>Original summary:</strong>
            ${escapeHtml(item.summary)}
          </p>` : ""}

        ${predictionBox(item)}

        <div class="explanation">
          <strong>Gold / XAUUSD impact explanation</strong><br>
          ${escapeHtml(item.mal_explanation)}
        </div>
      </div>

      <div class="card-footer">
        <span class="bias ${bias}">
          Rule-based impact:
          ${escapeHtml(item.xau_bias)}
          · ${escapeHtml(item.confidence)}%
        </span>
        <div class="card-actions">
          <button
            data-save="${escapeHtml(item.id)}"
            data-saved="${saved ? "1" : "0"}"
          >${saved ? "Saved" : "Save"}</button>
          <a
            href="${escapeHtml(item.link || item.source_home)}"
            target="_blank"
            rel="noopener"
          >Open original</a>
        </div>
      </div>
    </article>`;
}

function signature(items) {
  return items.map(item => [
    item.id,
    item.updated_at,
    item.translation_status,
    item.saved,
    item.is_prediction,
    item.prediction_direction,
    item.prediction_target_low,
    item.prediction_target_high,
  ].join(":")).join("|");
}

function viewKey() {
  return [
    state.group,
    state.timeline,
    state.direction,
    state.cmeSection,
    state.search,
  ].join("|");
}

function renderConsensus() {
  const panel = $("prediction-consensus");
  const active = state.group === "predictions";
  panel.hidden = !active;

  if (!active) return;

  $("consensus-bullish").textContent =
    state.counts.prediction_bullish || 0;
  $("consensus-bearish").textContent =
    state.counts.prediction_bearish || 0;
  $("consensus-rangebound").textContent =
    state.counts.prediction_rangebound || 0;
  $("consensus-scenario").textContent =
    (state.counts.prediction_scenario || 0)
    + (state.counts.prediction_mixed || 0);
}

function render(force = false) {
  const grid = $("news-grid");
  const nextSignature = signature(state.items);
  const now = Date.now();
  const reading = now < state.readingUntil;

  if (!force && nextSignature === state.signature) return;
  if (!force && reading) {
    state.pending = true;
    $("reader-state").textContent =
      "READING MODE · UPDATE HELD";
    return;
  }

  const previousScroll =
    state.scrollByView.get(viewKey()) ?? window.scrollY;

  state.signature = nextSignature;
  state.pending = false;

  const cmeLabels = {
    all: "All CME",
    live: "CME Live News",
    upcoming: "CME Upcoming",
    outlook: "CME Outlook",
  };

  $("result-title").textContent =
    state.group === "cme"
      ? `CME News · ${cmeLabels[state.cmeSection] || "All CME"}`
      : (labels[state.group] || "AuRa X News");
  $("result-count").textContent =
    `${state.items.length} stories`;
  $("reader-state").textContent =
    `UPDATED ${new Date().toLocaleTimeString()}`;

  renderConsensus();

  grid.innerHTML = state.items.length
    ? state.items.map(card).join("")
    : `<div class="empty-card">
        ഈ filter-ൽ news/outlook ലഭ്യമല്ല.
        Source status പരിശോധിക്കുക അല്ലെങ്കിൽ Refresh news അമർത്തുക.
      </div>`;

  requestAnimationFrame(() => {
    window.scrollTo({
      top: previousScroll,
      behavior: "instant",
    });
  });
}

function updateCounts(counts) {
  const sourceCounts = {
    all: counts.total || 0,
    high: counts.high || 0,
    predictions: counts.predictions || 0,
    cme: counts.cme || 0,
    forexfactory: counts.forexfactory || 0,
    investing: counts.investing || 0,
    tradingview: counts.tradingview || 0,
    official: counts.official || 0,
    other: counts.other || 0,
    saved: counts.saved || 0,
  };

  for (const [key, value] of Object.entries(sourceCounts)) {
    const element = document.querySelector(
      `[data-count="${key}"]`,
    );
    if (element) element.textContent = value;
  }

  const cmeCounts = {
    all: counts.cme || 0,
    live: counts.cme_live || 0,
    upcoming: counts.cme_upcoming || 0,
    outlook: (
      (counts.cme_outlook || 0)
      + (state.items || []).filter(
        item => (
          item.source_group === "cme_live"
          && Number(item.is_prediction || 0) === 1
        ),
      ).length
    ),
  };

  for (const [key, value] of Object.entries(cmeCounts)) {
    const element = document.querySelector(
      `[data-cme-count="${key}"]`,
    );
    if (element) element.textContent = value;
  }
}

function renderHealth(statuses) {
  const connected = statuses.filter(
    item => Number(item.ok) === 1,
  ).length;

  const pill = $("health-pill");
  pill.textContent =
    `${connected}/${statuses.length || "—"} SOURCES`;
  pill.classList.toggle("online", connected > 0);

  $("health-panel").innerHTML = statuses.length
    ? statuses.map(item => `
        <div class="health-row">
          <strong>${escapeHtml(item.source)}</strong>
          <span class="${
            Number(item.ok) ? "health-ok" : "health-fail"
          }">${
            Number(item.ok) ? "ONLINE" : "ERROR"
          }</span>
          <small>
            ${escapeHtml(item.item_count)} items ·
            ${escapeHtml(item.checked_at)}<br>
            ${escapeHtml(item.message)}
          </small>
        </div>`).join("")
    : `<div class="health-row">
         <strong>Waiting for first source check…</strong>
       </div>`;
}

async function load(force = false) {
  const params = new URLSearchParams({
    group: state.group,
    timeline: state.timeline,
    direction: state.direction,
    cme_section: state.cmeSection,
    search: state.search,
    limit: "240",
  });

  try {
    const response = await fetch(
      `/api/news?${params.toString()}`,
      { cache: "no-store" },
    );
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const data = await response.json();
    state.items = data.items || [];
    state.counts = data.counts || {};
    state.sourceStatus = data.source_status || [];

    updateCounts(state.counts);
    renderHealth(state.sourceStatus);
    render(force);
  } catch (error) {
    $("health-pill").textContent = "BACKEND ERROR";
    $("news-grid").innerHTML =
      `<div class="empty-card">
        Backend unavailable:
        ${escapeHtml(error.message)}
      </div>`;
  }
}

function markReading() {
  state.readingUntil = Date.now() + 120000;
  state.scrollByView.set(
    viewKey(),
    window.scrollY,
  );
  $("reader-state").textContent =
    "READING MODE · AUTO UPDATE PAUSED";
}

function showPredictionControls() {
  const visible = state.group === "predictions";
  $("prediction-direction-tabs").hidden = !visible;
  if (!visible) {
    state.direction = "all";
    document
      .querySelectorAll(
        "#prediction-direction-tabs button",
      )
      .forEach(button => {
        button.classList.toggle(
          "active",
          button.dataset.direction === "all",
        );
      });
  }
}

document
  .querySelectorAll("#source-tabs button")
  .forEach(button => {
    button.addEventListener("click", () => {
      document
        .querySelectorAll("#source-tabs button")
        .forEach(item => {
          item.classList.remove("active");
        });

      button.classList.add("active");
      state.group = button.dataset.group || "all";

      const cmeTabs = $("cme-section-tabs");

      if (state.group === "cme") {
        cmeTabs.hidden = false;
        state.cmeSection = "all";

        document
          .querySelectorAll(
            "#cme-section-tabs [data-cme-section]",
          )
          .forEach(item => {
            item.classList.toggle(
              "active",
              item.dataset.cmeSection === "all",
            );
          });
      } else {
        cmeTabs.hidden = true;
        state.cmeSection = "all";
      }

      if (state.group === "predictions") {
        state.timeline = "all";
        document
          .querySelectorAll(".timeline-tabs button")
          .forEach(item => {
            item.classList.toggle(
              "active",
              item.dataset.timeline === "all",
            );
          });
      }

      showPredictionControls();
      state.signature = "";
      load(true);
    });
  });

document
  .querySelectorAll(
    "#cme-section-tabs [data-cme-section]",
  )
  .forEach(button => {
    button.addEventListener("click", () => {
      document
        .querySelectorAll(
          "#cme-section-tabs [data-cme-section]",
        )
        .forEach(item => {
          item.classList.remove("active");
        });

      button.classList.add("active");
      state.cmeSection =
        button.dataset.cmeSection || "all";
      state.timeline = "all";

      document
        .querySelectorAll(".timeline-tabs button")
        .forEach(item => {
          item.classList.toggle(
            "active",
            item.dataset.timeline === "all",
          );
        });

      state.signature = "";
      load(true);
    });
  });

document
  .querySelectorAll(".timeline-tabs button")
  .forEach(button => {
    button.addEventListener("click", () => {
      document
        .querySelectorAll(".timeline-tabs button")
        .forEach(item => {
          item.classList.remove("active");
        });

      button.classList.add("active");
      state.timeline =
        button.dataset.timeline || "all";
      state.signature = "";
      load(true);
    });
  });

document
  .querySelectorAll(
    "#prediction-direction-tabs button",
  )
  .forEach(button => {
    button.addEventListener("click", () => {
      document
        .querySelectorAll(
          "#prediction-direction-tabs button",
        )
        .forEach(item => {
          item.classList.remove("active");
        });

      button.classList.add("active");
      state.direction =
        button.dataset.direction || "all";
      state.signature = "";
      load(true);
    });
  });

let searchTimer = null;
$("search-input").addEventListener(
  "input",
  event => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => {
      state.search = event.target.value.trim();
      state.signature = "";
      load(true);
    }, 350);
  },
);

$("refresh-button").addEventListener(
  "click",
  async () => {
    $("refresh-button").disabled = true;
    $("refresh-button").textContent =
      "Refreshing…";

    try {
      await fetch(
        "/api/refresh",
        { method: "POST" },
      );
      state.readingUntil = 0;
      setTimeout(() => load(true), 2500);
    } finally {
      setTimeout(() => {
        $("refresh-button").disabled = false;
        $("refresh-button").textContent =
          "Refresh news";
      }, 3000);
    }
  },
);

$("news-grid").addEventListener(
  "click",
  async event => {
    const button = event.target.closest(
      "[data-save]",
    );
    if (!button) return;

    const itemId = button.dataset.save;
    const nextSaved =
      button.dataset.saved !== "1";

    await fetch(
      `/api/save/${encodeURIComponent(itemId)}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          saved: nextSaved,
        }),
      },
    );

    button.dataset.saved =
      nextSaved ? "1" : "0";
    button.textContent =
      nextSaved ? "Saved" : "Save";

    load(false);
  },
);

$("health-toggle").addEventListener(
  "click",
  () => {
    $("health-panel").hidden =
      !$("health-panel").hidden;
  },
);

window.addEventListener(
  "scroll",
  markReading,
  { passive: true },
);
window.addEventListener(
  "wheel",
  markReading,
  { passive: true },
);
document.addEventListener(
  "pointerdown",
  event => {
    if (event.target.closest(".news-card")) {
      markReading();
    }
  },
);

setInterval(() => {
  if (
    state.pending
    && Date.now() >= state.readingUntil
  ) {
    render(true);
  }
}, 1000);

setInterval(
  () => load(false),
  10000,
);

showPredictionControls();
load(true);
