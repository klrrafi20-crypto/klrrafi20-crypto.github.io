from __future__ import annotations

import hashlib
import html
import json
import logging
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from typing import Any
from urllib.parse import urljoin
from zoneinfo import ZoneInfo

import feedparser
import requests
from bs4 import BeautifulSoup, Tag
from dateutil import parser as date_parser

from impact import (
    calendar_bias,
    clean_text,
    fallback_title,
    headline_bias,
    impact_level,
    malayalam_explanation,
)
from predictions import prediction_analysis
from sources import FeedSource, SOURCES
from storage import NewsStore


LOGGER = logging.getLogger(__name__)

RELEVANCE_TERMS = {
    "gold", "xau", "bullion", "precious metal", "comex",
    "federal reserve", "fomc", "powell", "interest rate",
    "inflation", "cpi", "ppi", "pce", "payroll", "nonfarm",
    "unemployment", "jobless", "dollar", "dxy", "treasury",
    "yield", "central bank", "geopolitical", "war", "sanction",
    "tariff", "china", "etf", "gdp", "retail sales",
    "jobless claims", "consumer confidence", "pmi", "ism",
    "employment", "rate decision",
}

MAJOR_CURRENCIES = {
    "USD", "EUR", "GBP", "JPY",
    "CNY", "AUD", "CAD", "CHF",
}

CME_EVENT_PAGE = re.compile(
    r"/education/events/econoday/\d+",
    re.IGNORECASE,
)

DATE_PATTERNS = (
    re.compile(
        r"\b\d{4}-\d{2}-\d{2}\b"
    ),
    re.compile(
        r"\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)"
        r"[a-z]*\s+\d{1,2},?\s+\d{4}\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b\d{1,2}\s+"
        r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)"
        r"[a-z]*\s+\d{4}\b",
        re.IGNORECASE,
    ),
)

TIME_PATTERN = re.compile(
    r"\b\d{1,2}(?::\d{2})?\s*(?:AM|PM|am|pm)\b"
    r"|\b\d{1,2}:\d{2}\b"
)


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def iso_now() -> str:
    return utc_now().isoformat()


def stable_id(*parts: str) -> str:
    digest = hashlib.sha256(
        "\x1f".join(parts).encode(
            "utf-8",
            errors="ignore",
        )
    ).hexdigest()
    return digest[:32]


def strip_html(value: str) -> str:
    text = BeautifulSoup(
        html.unescape(value or ""),
        "html.parser",
    ).get_text(" ")
    return clean_text(text)


def parse_datetime(
    value: Any,
    default_tz: timezone | ZoneInfo = timezone.utc,
) -> datetime:
    if isinstance(value, datetime):
        result = value
    else:
        try:
            result = date_parser.parse(str(value))
        except (
            TypeError,
            ValueError,
            OverflowError,
        ):
            result = utc_now()

    if result.tzinfo is None:
        result = result.replace(tzinfo=default_tz)

    return result.astimezone(timezone.utc)


def relevant(
    title: str,
    summary: str,
    group: str,
) -> bool:
    if group in {
        "forexfactory",
        "official",
        "cme_upcoming",
        "prediction_rss",
    }:
        return True

    text = f"{title} {summary}".lower()
    return any(term in text for term in RELEVANCE_TERMS)


def timeline_for(
    date: datetime,
    kind: str,
) -> str:
    now = utc_now()

    if kind == "calendar":
        if date > now + timedelta(minutes=5):
            return "UPCOMING"
        if date >= now - timedelta(hours=8):
            return "CURRENT"
        return "PAST"

    return (
        "CURRENT"
        if date >= now - timedelta(hours=30)
        else "PAST"
    )


def source_link(entry: Any) -> str:
    return clean_text(
        getattr(entry, "link", "")
        or entry.get("link", "")
    )


def timezone_from_text(text: str) -> timezone | ZoneInfo:
    lowered = text.lower()

    if "singapore" in lowered:
        return ZoneInfo("Asia/Singapore")
    if (
        "eastern time" in lowered
        or re.search(r"\bET\b", text)
    ):
        return ZoneInfo("America/New_York")
    if (
        "central time" in lowered
        or re.search(r"\bCT\b", text)
    ):
        return ZoneInfo("America/Chicago")
    if "gmt" in lowered or "utc" in lowered:
        return timezone.utc

    # CME economic-release pages commonly present US releases.
    return ZoneInfo("America/New_York")


def title_currency(title: str) -> str:
    lowered = title.lower()

    if any(
        key in lowered
        for key in (
            "u.s.", "us ", "fed", "fomc",
            "nonfarm", "payroll", "cpi",
            "ppi", "pce", "jobless",
            "retail sales", "gdp", "ism",
        )
    ):
        return "USD"
    if "euro" in lowered or "ecb" in lowered:
        return "EUR"
    if "uk " in lowered or "boe" in lowered:
        return "GBP"
    if "japan" in lowered or "boj" in lowered:
        return "JPY"
    if "china" in lowered:
        return "CNY"

    return ""


def calendar_item(
    *,
    source: FeedSource,
    title: str,
    event_date: datetime,
    link: str,
    summary: str,
    source_name: str | None = None,
) -> dict[str, Any]:
    impact = impact_level(title, summary)
    now_iso = iso_now()
    status = timeline_for(event_date, "calendar")
    currency = title_currency(title)
    item_id = stable_id(
        source_name or source.name,
        title,
        event_date.isoformat(),
        link,
    )

    return {
        "id": item_id,
        "source": source_name or source.name,
        "source_group": "cme_upcoming",
        "source_home": source.home_url,
        "attribution": source.attribution,
        "kind": "calendar",
        "title": title,
        "summary": summary,
        "link": link,
        "published_at": event_date.isoformat(),
        "event_time": event_date.isoformat(),
        "impact_level": impact,
        "xau_bias": "WAIT",
        "confidence": 45 if impact == "HIGH" else 35,
        "mal_title": fallback_title(title),
        "mal_summary": "",
        "mal_explanation": malayalam_explanation(
            title,
            impact,
            "WAIT",
            "calendar",
            "",
            "",
            "",
        ),
        "translation_status": "FALLBACK",
        "status": status,
        "currency": currency,
        "actual": "",
        "forecast": "",
        "previous": "",
        "raw_json": json.dumps(
            {
                "official_cme": True,
                "source_url": link,
            },
            ensure_ascii=False,
        ),
        "first_seen": now_iso,
        "updated_at": now_iso,
    }


class NewsCollector:
    def __init__(self, store: NewsStore) -> None:
        self.store = store
        self.stop_event = threading.Event()
        self.wake_event = threading.Event()
        self.thread: threading.Thread | None = None
        self.scheduler_lock = threading.RLock()
        self.next_due: dict[str, float] = {}
        self.session = requests.Session()
        self.session.headers.update(
            {
                "User-Agent": (
                    "Mozilla/5.0 "
                    "(Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 "
                    "Chrome/124 Safari/537.36 "
                    "AuRa-X-News/1.3 "
                    "personal news reader"
                ),
                "Accept": (
                    "application/rss+xml, "
                    "application/xml, text/xml, "
                    "application/json, text/html;"
                    "q=0.9, */*;q=0.8"
                ),
            }
        )

    def start(self) -> None:
        if self.thread and self.thread.is_alive():
            return

        self.thread = threading.Thread(
            target=self._loop,
            name="news-collector",
            daemon=True,
        )
        self.thread.start()

    def stop(self) -> None:
        self.stop_event.set()
        self.wake_event.set()

    def refresh_now(self) -> None:
        with self.scheduler_lock:
            self.next_due.clear()
        self.wake_event.set()

    @staticmethod
    def _source_key(source: FeedSource) -> str:
        return f"{source.group}:{source.name}"

    @staticmethod
    def _source_priority(source: FeedSource) -> int:
        if (
            source.group.startswith("cme")
            or source.group == "investing"
        ):
            return 0
        if source.group in {"forexfactory", "official"}:
            return 1
        return 2

    def _loop(self) -> None:
        with ThreadPoolExecutor(
            max_workers=8,
            thread_name_prefix="news-source",
        ) as executor:
            while not self.stop_event.is_set():
                now = time.monotonic()

                with self.scheduler_lock:
                    due_sources = [
                        source
                        for source in SOURCES
                        if source.enabled
                        and self.next_due.get(
                            self._source_key(source),
                            0.0,
                        ) <= now
                    ]

                if due_sources:
                    due_sources.sort(
                        key=lambda source: (
                            self._source_priority(source),
                            source.name,
                        )
                    )

                    futures = {
                        executor.submit(
                            self._collect_source,
                            source,
                        ): source
                        for source in due_sources
                    }

                    for future in as_completed(futures):
                        source = futures[future]

                        try:
                            future.result()
                        except Exception:
                            LOGGER.exception(
                                "Unhandled source worker error: %s",
                                source.name,
                            )

                        interval = max(
                            45,
                            int(source.poll_seconds),
                        )

                        with self.scheduler_lock:
                            self.next_due[
                                self._source_key(source)
                            ] = (
                                time.monotonic()
                                + interval
                            )

                    continue

                with self.scheduler_lock:
                    future_times = [
                        self.next_due.get(
                            self._source_key(source),
                            now,
                        )
                        for source in SOURCES
                        if source.enabled
                    ]

                nearest = (
                    min(future_times)
                    if future_times
                    else now + 5
                )
                wait_seconds = max(
                    0.5,
                    min(5.0, nearest - now),
                )

                self.wake_event.wait(wait_seconds)
                self.wake_event.clear()

    def _collect_source(
        self,
        source: FeedSource,
    ) -> None:
        checked_at = iso_now()

        try:
            if source.kind == "forex_factory_calendar":
                items = self._fetch_forex_factory(source)
            elif source.kind == "cme_calendar":
                items = self._fetch_cme_calendar(source)
            else:
                items = self._fetch_rss(source)

            for item in items:
                self.store.upsert_news(item)

            self.store.update_source_status(
                source.name,
                source.group,
                True,
                len(items),
                (
                    "Connected · scheduled every "
                    f"{max(45, int(source.poll_seconds))} sec"
                ),
                checked_at,
            )
        except Exception as exc:
            LOGGER.exception(
                "Source failed: %s",
                source.name,
            )
            self.store.update_source_status(
                source.name,
                source.group,
                False,
                0,
                clean_text(exc)[:300],
                checked_at,
            )

    def _fetch_rss(
        self,
        source: FeedSource,
    ) -> list[dict[str, Any]]:
        priority_source = (
            source.group.startswith("cme")
            or source.group == "investing"
        )
        response = self.session.get(
            source.url,
            timeout=14 if priority_source else 18,
        )
        response.raise_for_status()
        feed = feedparser.parse(response.content)

        if feed.bozo and not feed.entries:
            raise RuntimeError(
                str(feed.bozo_exception)
            )

        items: list[dict[str, Any]] = []
        cme_article_links: list[
            tuple[str, str]
        ] = []

        entry_limit = (
            180
            if source.group in {
                "cme_live",
                "cme_outlook",
                "investing",
            }
            else 100
        )

        for entry in feed.entries[:entry_limit]:
            title = strip_html(
                entry.get("title", "")
            )
            summary = strip_html(
                entry.get("summary", "")
                or entry.get("description", "")
            )

            if (
                not title
                or not relevant(
                    title,
                    summary,
                    source.group,
                )
            ):
                continue

            published_value = (
                entry.get("published")
                or entry.get("updated")
                or entry.get("created")
                or iso_now()
            )
            published = parse_datetime(
                published_value
            )
            link = (
                source_link(entry)
                or source.home_url
            )
            impact = impact_level(
                title,
                summary,
            )
            bias, confidence = headline_bias(
                title,
                summary,
            )
            now_iso = iso_now()
            item_id = stable_id(
                source.name,
                link,
                title,
            )
            prediction = prediction_analysis(
                title,
                summary,
                source.name,
                force=source.kind == "prediction_rss",
            )

            items.append(
                {
                    "id": item_id,
                    "source": source.name,
                    "source_group": source.group,
                    "source_home": source.home_url,
                    "attribution": source.attribution,
                    "kind": "headline",
                    "title": title,
                    "summary": summary,
                    "link": link,
                    "published_at": (
                        published.isoformat()
                    ),
                    "event_time": "",
                    "impact_level": impact,
                    "xau_bias": bias,
                    "confidence": confidence,
                    "mal_title": (
                        fallback_title(title)
                    ),
                    "mal_summary": "",
                    "mal_explanation": (
                        malayalam_explanation(
                            title,
                            impact,
                            bias,
                            "headline",
                        )
                    ),
                    "translation_status": (
                        "FALLBACK"
                    ),
                    "status": timeline_for(
                        published,
                        "headline",
                    ),
                    "currency": "",
                    "actual": "",
                    "forecast": "",
                    "previous": "",
                    "raw_json": "{}",
                    "first_seen": now_iso,
                    "updated_at": now_iso,
                    **prediction,
                }
            )

            if (
                source.group == "cme_live"
                and "cmegroup.com" in link
                and any(
                    phrase in title.lower()
                    for phrase in (
                        "fresh from the trading room",
                        "market focus",
                        "infocus",
                        "trading room",
                    )
                )
            ):
                cme_article_links.append(
                    (title, link)
                )

        # CME commentary sometimes contains a table titled
        # "Upcoming economic events". Extract those official dates.
        for article_title, link in cme_article_links[:8]:
            try:
                items.extend(
                    self._extract_cme_article_events(
                        source,
                        article_title,
                        link,
                    )
                )
            except Exception as exc:
                LOGGER.info(
                    "CME article calendar parse skipped: %s",
                    exc,
                )

        return items

    def _fetch_cme_calendar(
        self,
        source: FeedSource,
    ) -> list[dict[str, Any]]:
        response = self.session.get(
            source.url,
            timeout=22,
        )
        response.raise_for_status()
        soup = BeautifulSoup(
            response.text,
            "html.parser",
        )
        items: dict[str, dict[str, Any]] = {}

        # 1) Parse event cards/links from the official CME calendar.
        for anchor in soup.find_all(
            "a",
            href=CME_EVENT_PAGE,
        ):
            if not isinstance(anchor, Tag):
                continue

            title = clean_text(
                anchor.get_text(" ", strip=True)
            )
            link = urljoin(
                source.url,
                str(anchor.get("href") or ""),
            )

            if not title:
                continue

            container = anchor
            for _ in range(5):
                if not container.parent:
                    break
                container = container.parent
                text = clean_text(
                    container.get_text(
                        " ",
                        strip=True,
                    )
                )
                if any(
                    pattern.search(text)
                    for pattern in DATE_PATTERNS
                ):
                    break

            text = clean_text(
                container.get_text(
                    " ",
                    strip=True,
                )
            )
            event_date = self._date_from_text(
                text
            )

            if not event_date:
                time_tag = container.find("time")
                if isinstance(time_tag, Tag):
                    event_date = self._date_from_text(
                        str(
                            time_tag.get("datetime")
                            or time_tag.get_text(
                                " ",
                                strip=True,
                            )
                        )
                    )

            if not event_date:
                continue

            item = calendar_item(
                source=source,
                title=title,
                event_date=event_date,
                link=link,
                summary=(
                    "Official CME Group economic-release "
                    "calendar event."
                ),
            )
            items[item["id"]] = item

        # 2) Parse JSON embedded in the page.
        for script in soup.find_all(
            "script",
            type="application/ld+json",
        ):
            try:
                payload = json.loads(
                    script.string or ""
                )
            except (
                TypeError,
                json.JSONDecodeError,
            ):
                continue

            for record in self._walk_json(payload):
                title = clean_text(
                    record.get("name")
                    or record.get("headline")
                    or record.get("eventName")
                    or record.get("title")
                )
                date_value = (
                    record.get("startDate")
                    or record.get("date")
                    or record.get("eventStart")
                    or record.get("eventStartTimestamp")
                )
                link = clean_text(
                    record.get("url")
                    or source.url
                )

                if not title or not date_value:
                    continue

                event_date = parse_datetime(
                    date_value
                )
                item = calendar_item(
                    source=source,
                    title=title,
                    event_date=event_date,
                    link=urljoin(
                        source.url,
                        link,
                    ),
                    summary=(
                        "Official CME Group calendar event "
                        "from page metadata."
                    ),
                )
                items[item["id"]] = item

        # Always retain an official calendar access card when the
        # JavaScript-rendered page exposes no parseable rows.
        if not items:
            now = utc_now()
            item = calendar_item(
                source=source,
                title=(
                    "CME Group Live Economic Release "
                    "Calendar"
                ),
                event_date=now + timedelta(
                    minutes=10
                ),
                link=source.home_url,
                summary=(
                    "Open the official CME Group calendar "
                    "for the complete current U.S. and "
                    "global release schedule. The page is "
                    "JavaScript-driven and may not expose "
                    "all rows to an external reader."
                ),
                source_name=(
                    "CME Official Calendar Access"
                ),
            )
            item["impact_level"] = "HIGH"
            item["confidence"] = 100
            item["mal_explanation"] = (
                "ഇത് CME Group-ന്റെ ഔദ്യോഗിക "
                "Economic Release Calendar link ആണ്. "
                "Upcoming CPI, NFP, GDP, central-bank "
                "events തുടങ്ങിയവയുടെ exact സമയം "
                "official page-ൽ പരിശോധിക്കുക. "
                "Tool-ൽ event rows ലഭിക്കാത്തപ്പോൾ "
                "ഈ card തുടരും; ഇത് fabricated event അല്ല."
            )
            items[item["id"]] = item

        return list(items.values())

    def _extract_cme_article_events(
        self,
        source: FeedSource,
        article_title: str,
        link: str,
    ) -> list[dict[str, Any]]:
        response = self.session.get(
            link,
            timeout=18,
        )
        response.raise_for_status()
        soup = BeautifulSoup(
            response.text,
            "html.parser",
        )

        heading_text = ""
        event_table: Tag | None = None

        for element in soup.find_all(
            ["h2", "h3", "h4", "h5",
             "strong", "p"],
        ):
            text = clean_text(
                element.get_text(
                    " ",
                    strip=True,
                )
            )
            if (
                "upcoming economic event"
                in text.lower()
            ):
                heading_text = text
                table = element.find_next("table")
                if isinstance(table, Tag):
                    event_table = table
                break

        if not event_table:
            return []

        zone = timezone_from_text(
            heading_text
            + " "
            + clean_text(
                event_table.parent.get_text(
                    " ",
                    strip=True,
                )
                if event_table.parent
                else ""
            )
        )

        items: list[dict[str, Any]] = []

        for row in event_table.find_all("tr"):
            cells = [
                clean_text(
                    cell.get_text(
                        " ",
                        strip=True,
                    )
                )
                for cell in row.find_all(
                    ["th", "td"]
                )
            ]

            if len(cells) < 2:
                continue

            if any(
                word in " ".join(cells).lower()
                for word in (
                    "date time venue",
                    "date venue",
                )
            ):
                continue

            date_text = cells[0]
            time_text = (
                cells[1]
                if len(cells) >= 3
                else ""
            )
            title = (
                cells[2]
                if len(cells) >= 3
                else cells[1]
            )

            if not title:
                continue

            try:
                event_date = date_parser.parse(
                    f"{date_text} {time_text}",
                    fuzzy=True,
                )
            except (
                ValueError,
                TypeError,
                OverflowError,
            ):
                continue

            if event_date.tzinfo is None:
                event_date = event_date.replace(
                    tzinfo=zone
                )

            event_date = event_date.astimezone(
                timezone.utc
            )

            if not (
                utc_now() - timedelta(days=2)
                <= event_date
                <= utc_now() + timedelta(days=90)
            ):
                continue

            items.append(
                calendar_item(
                    source=source,
                    title=title,
                    event_date=event_date,
                    link=link,
                    summary=(
                        "Upcoming event listed in the "
                        f"CME Group article: {article_title}. "
                        f"Displayed timezone context: "
                        f"{heading_text or 'CME article time'}."
                    ),
                    source_name=(
                        "CME Upcoming Economic Events"
                    ),
                )
            )

        return items

    def _date_from_text(
        self,
        text: str,
    ) -> datetime | None:
        date_match: re.Match[str] | None = None

        for pattern in DATE_PATTERNS:
            date_match = pattern.search(text)
            if date_match:
                break

        if not date_match:
            return None

        time_match = TIME_PATTERN.search(text)
        combined = date_match.group(0)

        if time_match:
            combined += f" {time_match.group(0)}"

        try:
            parsed = date_parser.parse(
                combined,
                fuzzy=True,
            )
        except (
            ValueError,
            TypeError,
            OverflowError,
        ):
            return None

        if parsed.tzinfo is None:
            parsed = parsed.replace(
                tzinfo=timezone_from_text(text)
            )

        return parsed.astimezone(timezone.utc)

    def _walk_json(
        self,
        value: Any,
    ) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []

        if isinstance(value, dict):
            results.append(value)
            for child in value.values():
                results.extend(
                    self._walk_json(child)
                )
        elif isinstance(value, list):
            for child in value:
                results.extend(
                    self._walk_json(child)
                )

        return results

    def _fetch_forex_factory(
        self,
        source: FeedSource,
    ) -> list[dict[str, Any]]:
        response = self.session.get(
            source.url,
            timeout=18,
        )
        response.raise_for_status()
        payload = response.json()

        if not isinstance(payload, list):
            raise RuntimeError(
                "Forex Factory JSON is not a list."
            )

        items: list[dict[str, Any]] = []
        now_iso = iso_now()

        for raw in payload:
            if not isinstance(raw, dict):
                continue

            title = clean_text(
                raw.get("title")
                or raw.get("event")
                or raw.get("name")
            )
            currency = clean_text(
                raw.get("country")
                or raw.get("currency")
            ).upper()
            declared_impact = clean_text(
                raw.get("impact")
            ).upper()

            if (
                not title
                or (
                    currency not in MAJOR_CURRENCIES
                    and declared_impact
                    not in {
                        "HIGH",
                        "MEDIUM",
                        "MED",
                    }
                )
            ):
                continue

            date_value = (
                raw.get("date")
                or raw.get("datetime")
                or raw.get("time")
            )
            event_date = parse_datetime(
                date_value
            )
            actual = clean_text(
                raw.get("actual")
            )
            forecast = clean_text(
                raw.get("forecast")
            )
            previous = clean_text(
                raw.get("previous")
            )
            impact = impact_level(
                title,
                "",
                declared_impact,
            )
            bias, confidence = calendar_bias(
                title,
                actual,
                forecast,
            )
            status = timeline_for(
                event_date,
                "calendar",
            )
            link = source.home_url
            item_id = stable_id(
                source.name,
                title,
                event_date.isoformat(),
                currency,
            )

            items.append(
                {
                    "id": item_id,
                    "source": source.name,
                    "source_group": source.group,
                    "source_home": source.home_url,
                    "attribution": source.attribution,
                    "kind": "calendar",
                    "title": title,
                    "summary": (
                        f"{currency} economic calendar "
                        f"event. Actual "
                        f"{actual or '—'}, Forecast "
                        f"{forecast or '—'}, Previous "
                        f"{previous or '—'}."
                    ),
                    "link": link,
                    "published_at": (
                        event_date.isoformat()
                    ),
                    "event_time": (
                        event_date.isoformat()
                    ),
                    "impact_level": impact,
                    "xau_bias": bias,
                    "confidence": confidence,
                    "mal_title": (
                        fallback_title(title)
                    ),
                    "mal_summary": "",
                    "mal_explanation": (
                        malayalam_explanation(
                            title,
                            impact,
                            bias,
                            "calendar",
                            actual,
                            forecast,
                            previous,
                        )
                    ),
                    "translation_status": (
                        "FALLBACK"
                    ),
                    "status": status,
                    "currency": currency,
                    "actual": actual,
                    "forecast": forecast,
                    "previous": previous,
                    "raw_json": (
                        json.dumps(
                            raw,
                            ensure_ascii=False,
                            default=str,
                        )
                    ),
                    "first_seen": now_iso,
                    "updated_at": now_iso,
                }
            )

        return items
