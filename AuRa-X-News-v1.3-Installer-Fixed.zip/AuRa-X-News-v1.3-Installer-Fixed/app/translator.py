from __future__ import annotations

import logging
import threading
import time
from typing import Any

import requests

from impact import fallback_title
from storage import NewsStore

LOGGER = logging.getLogger(__name__)

TRANSLATE_URL = "https://translate.googleapis.com/translate_a/single"


class MalayalamTranslator:
    def __init__(self, store: NewsStore) -> None:
        self.store = store
        self.stop_event = threading.Event()
        self.thread: threading.Thread | None = None
        self.session = requests.Session()
        self.session.headers.update(
            {
                "User-Agent": (
                    "AuRa-X-News/1.3 local personal news reader"
                )
            }
        )

    def start(self) -> None:
        if self.thread and self.thread.is_alive():
            return
        self.thread = threading.Thread(
            target=self._loop,
            name="malayalam-translator",
            daemon=True,
        )
        self.thread.start()

    def stop(self) -> None:
        self.stop_event.set()

    def _translate(self, text: str) -> str:
        if not text.strip():
            return ""
        response = self.session.get(
            TRANSLATE_URL,
            params={
                "client": "gtx",
                "sl": "en",
                "tl": "ml",
                "dt": "t",
                "q": text[:2800],
            },
            timeout=10,
        )
        response.raise_for_status()
        payload: Any = response.json()
        pieces = payload[0] if isinstance(payload, list) and payload else []
        translated = "".join(
            str(piece[0])
            for piece in pieces
            if isinstance(piece, list) and piece
        ).strip()
        if not translated:
            raise RuntimeError("Translation endpoint returned no text.")
        return translated

    def _loop(self) -> None:
        while not self.stop_event.is_set():
            items = self.store.untranslated(limit=8)
            if not items:
                self.stop_event.wait(10)
                continue

            for item in items:
                if self.stop_event.is_set():
                    return
                try:
                    mal_title = self._translate(item["title"])
                    summary = item.get("summary") or ""
                    mal_summary = (
                        self._translate(summary)
                        if summary
                        else ""
                    )
                    self.store.update_translation(
                        item["id"],
                        mal_title,
                        mal_summary,
                        "WEB_TRANSLATED",
                    )
                except Exception as exc:
                    LOGGER.warning(
                        "Malayalam translation failed for %s: %s",
                        item["id"],
                        exc,
                    )
                    self.store.update_translation(
                        item["id"],
                        item.get("mal_title")
                        or fallback_title(item["title"]),
                        item.get("mal_summary") or "",
                        "RETRY",
                    )
                self.stop_event.wait(1.2)

            self.stop_event.wait(3)
