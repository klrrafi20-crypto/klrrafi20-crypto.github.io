from __future__ import annotations

import re
from typing import Any


HIGH_TERMS = {
    "fomc", "federal reserve", "fed rate", "interest rate decision",
    "powell", "cpi", "consumer price", "core pce", "pce price",
    "non-farm", "nonfarm", "nfp", "payroll", "unemployment rate",
    "ppi", "producer price", "gdp", "retail sales", "jobless claims",
    "war", "missile", "sanction", "tariff", "geopolitical",
    "treasury yield", "central bank", "rate cut", "rate hike",
}

MEDIUM_TERMS = {
    "gold", "xau", "bullion", "dollar", "dxy", "yield", "treasury",
    "inflation", "employment", "jobs", "manufacturing", "services pmi",
    "ism", "consumer confidence", "china", "etf", "central-bank",
}

BULLISH_TERMS = {
    "rate cut", "dovish", "weaker dollar", "dollar falls", "yields fall",
    "recession", "risk-off", "safe haven", "war", "sanctions",
    "gold demand", "central bank buying", "inflation fears",
}

BEARISH_TERMS = {
    "rate hike", "hawkish", "strong dollar", "dollar rises", "yields rise",
    "strong jobs", "hot inflation", "risk-on", "gold selling",
    "central bank selling", "higher rates",
}

EVENT_RULES = {
    "unemployment": "inverse",
    "jobless claims": "inverse",
    "non-farm": "positive_usd",
    "nonfarm": "positive_usd",
    "payroll": "positive_usd",
    "cpi": "positive_usd",
    "consumer price": "positive_usd",
    "ppi": "positive_usd",
    "producer price": "positive_usd",
    "pce": "positive_usd",
    "retail sales": "positive_usd",
    "gdp": "positive_usd",
    "interest rate": "positive_usd",
}


def clean_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def impact_level(title: str, summary: str = "", declared: str = "") -> str:
    declared_upper = declared.upper()
    if declared_upper == "HIGH":
        return "HIGH"
    if declared_upper in {"MEDIUM", "MED"}:
        return "MEDIUM"

    text = f"{title} {summary}".lower()
    if any(term in text for term in HIGH_TERMS):
        return "HIGH"
    if any(term in text for term in MEDIUM_TERMS):
        return "MEDIUM"
    return "LOW"


def parse_number(value: str) -> float | None:
    raw = clean_text(value).replace(",", "")
    if not raw:
        return None
    multiplier = 1.0
    if raw[-1:].upper() == "K":
        multiplier = 1_000.0
        raw = raw[:-1]
    elif raw[-1:].upper() == "M":
        multiplier = 1_000_000.0
        raw = raw[:-1]
    elif raw[-1:].upper() == "B":
        multiplier = 1_000_000_000.0
        raw = raw[:-1]
    percent = raw.endswith("%")
    if percent:
        raw = raw[:-1]
    try:
        return float(raw) * multiplier
    except ValueError:
        return None


def calendar_bias(
    title: str,
    actual: str,
    forecast: str,
) -> tuple[str, int]:
    actual_number = parse_number(actual)
    forecast_number = parse_number(forecast)
    if actual_number is None or forecast_number is None:
        return "WAIT", 35

    lowered = title.lower()
    rule = next(
        (value for key, value in EVENT_RULES.items() if key in lowered),
        None,
    )
    if not rule:
        return "MIXED", 40

    higher = actual_number > forecast_number
    if rule == "inverse":
        return ("BULLISH", 72) if higher else ("BEARISH", 72)

    return ("BEARISH", 72) if higher else ("BULLISH", 72)


def headline_bias(title: str, summary: str = "") -> tuple[str, int]:
    text = f"{title} {summary}".lower()
    bullish = sum(1 for term in BULLISH_TERMS if term in text)
    bearish = sum(1 for term in BEARISH_TERMS if term in text)

    if bullish > bearish:
        return "BULLISH", min(82, 50 + bullish * 8)
    if bearish > bullish:
        return "BEARISH", min(82, 50 + bearish * 8)
    return "MIXED", 38


def malayalam_explanation(
    title: str,
    impact: str,
    bias: str,
    kind: str,
    actual: str = "",
    forecast: str = "",
    previous: str = "",
) -> str:
    lowered = title.lower()

    if "cpi" in lowered or "consumer price" in lowered:
        base = (
            "CPI ഉപഭോക്തൃ വിലക്കയറ്റത്തിന്റെ വേഗം കാണിക്കുന്ന പ്രധാന ഡാറ്റയാണ്. "
            "Forecast-നെക്കാൾ ഉയർന്ന CPI പലിശനിരക്ക് ഉയർന്ന നിലയിൽ തുടരാമെന്ന "
            "പ്രതീക്ഷ കൂട്ടി USD/yields ശക്തമാക്കുകയും Gold-ന് സമ്മർദ്ദം നൽകുകയും ചെയ്യാം."
        )
    elif "ppi" in lowered or "producer price" in lowered:
        base = (
            "PPI നിർമ്മാതാക്കളുടെ വിലമാറ്റം കാണിക്കുന്നു. ഉയർന്ന PPI ഭാവിയിലെ "
            "inflation pressure സൂചിപ്പിക്കാം; ഇത് USD/yields ശക്തമാക്കി Gold-നെ "
            "താഴേക്ക് സമ്മർദ്ദത്തിലാക്കാം."
        )
    elif "nonfarm" in lowered or "non-farm" in lowered or "payroll" in lowered:
        base = (
            "NFP/Payrolls അമേരിക്കൻ തൊഴിൽ വിപണിയുടെ ശക്തി കാണിക്കുന്ന high-impact "
            "release ആണ്. ശക്തമായ jobs data സാധാരണ USD-നും yields-നും പിന്തുണയായി "
            "Gold-നെ താഴേക്ക് നയിക്കാം; ദുർബല data മറിച്ചായിരിക്കാം."
        )
    elif "unemployment" in lowered or "jobless claims" in lowered:
        base = (
            "തൊഴിലില്ലായ്മ/Jobless Claims തൊഴിൽ വിപണിയുടെ ദുർബലത അളക്കുന്നു. "
            "പ്രതീക്ഷിച്ചതിലും ദുർബല labour data rate-cut പ്രതീക്ഷ കൂട്ടി Gold-ന് "
            "പിന്തുണ നൽകാം."
        )
    elif "fomc" in lowered or "federal reserve" in lowered or "powell" in lowered:
        base = (
            "Federal Reserve/FOMC സന്ദേശങ്ങൾ പലിശനിരക്കും USD-നും നേരിട്ട് സ്വാധീനം "
            "ചെയ്യുന്നു. Hawkish tone Gold-ന് bearish ആയേക്കാം; dovish tone Gold-ന് "
            "bullish ആയേക്കാം."
        )
    elif "gdp" in lowered:
        base = (
            "GDP സാമ്പത്തിക വളർച്ച അളക്കുന്നു. ശക്തമായ US growth USD/yields ശക്തമാക്കി "
            "Gold-നെ സമ്മർദ്ദത്തിലാക്കാം; ദുർബല growth safe-haven demand കൂട്ടാം."
        )
    elif "gold" in lowered or "xau" in lowered or "bullion" in lowered:
        base = (
            "ഈ വാർത്ത Gold/XAUUSD-നെ നേരിട്ട് ബാധിക്കുന്നതാണ്. Headline മാത്രം നോക്കി "
            "trade എടുക്കാതെ USD, US yields, risk sentiment, live price reaction എന്നിവ "
            "ഒരുമിച്ച് പരിശോധിക്കുക."
        )
    elif "dollar" in lowered or "yield" in lowered or "treasury" in lowered:
        base = (
            "USD അല്ലെങ്കിൽ US Treasury yields മാറുന്നത് Gold-ന്റെ opportunity cost-നെ "
            "ബാധിക്കും. Dollar/yields ഉയർന്നാൽ സാധാരണ Gold-ന് സമ്മർദ്ദം; താഴെയെങ്കിൽ "
            "Gold-ന് പിന്തുണ ലഭിക്കാം."
        )
    else:
        base = (
            "ഈ വാർത്ത XAUUSD-നെ USD, പലിശനിരക്ക് പ്രതീക്ഷ, risk sentiment, central-bank "
            "demand, അല്ലെങ്കിൽ commodity flows വഴി ബാധിക്കാം. Source തുറന്ന് മുഴുവൻ "
            "context പരിശോധിച്ച് live market reaction സ്ഥിരീകരിക്കുക."
        )

    result = ""
    if kind == "calendar":
        result = (
            f" Actual: {actual or '—'}, Forecast: {forecast or '—'}, "
            f"Previous: {previous or '—'}."
        )

    bias_ml = {
        "BULLISH": "നിലവിലെ rule-based reading Gold-ന് bullish bias കാണിക്കുന്നു.",
        "BEARISH": "നിലവിലെ rule-based reading Gold-ന് bearish bias കാണിക്കുന്നു.",
        "MIXED": "Direction വ്യക്തമായിട്ടില്ല; market confirmation ആവശ്യമാണ്.",
        "WAIT": "Actual data അല്ലെങ്കിൽ live reaction ലഭിക്കുംവരെ WAIT ചെയ്യുക.",
    }.get(bias, "Direction സ്ഥിരീകരിച്ചിട്ടില്ല.")

    return f"{base}{result} {bias_ml} Impact level: {impact}."


def fallback_title(title: str) -> str:
    replacements = (
        ("Gold", "സ്വർണം"),
        ("gold", "സ്വർണം"),
        ("XAUUSD", "XAUUSD"),
        ("Federal Reserve", "ഫെഡറൽ റിസർവ്"),
        ("Fed", "ഫെഡ്"),
        ("interest rate", "പലിശനിരക്ക്"),
        ("inflation", "വിലക്കയറ്റം"),
        ("dollar", "ഡോളർ"),
        ("Dollar", "ഡോളർ"),
        ("yields", "ബോണ്ട് yields"),
        ("jobs", "തൊഴിൽ"),
        ("News", "വാർത്ത"),
    )
    result = title
    for source, target in replacements:
        result = result.replace(source, target)
    return result
