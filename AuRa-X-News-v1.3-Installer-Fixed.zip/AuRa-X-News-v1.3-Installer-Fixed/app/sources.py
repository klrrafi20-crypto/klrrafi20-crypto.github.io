from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class FeedSource:
    name: str
    group: str
    url: str
    home_url: str
    kind: str = "rss"
    attribution: str = ""
    enabled: bool = True
    poll_seconds: int = 120


SOURCES: tuple[FeedSource, ...] = (
    # Official CME upcoming economic-release calendar.
    FeedSource(
        name="CME Official Economic Release Calendar",
        group="cme_upcoming",
        url=(
            "https://www.cmegroup.com/education/events/"
            "economic-releases-calendar"
        ),
        home_url=(
            "https://www.cmegroup.com/education/events/"
            "economic-releases-calendar"
        ),
        kind="cme_calendar",
        attribution="CME Group official economic-release calendar",
        poll_seconds=300,
    ),

    # Official CME live / near-live RSS feeds.
    FeedSource(
        name="CME Economic Research",
        group="cme_live",
        url=(
            "https://www.cmegroup.com/rss/"
            "commentary-home-insights-analysis.rss"
        ),
        home_url="https://www.cmegroup.com/rss.html",
        attribution="CME Group official RSS",
        poll_seconds=60,
    ),
    FeedSource(
        name="CME Featured Reports",
        group="cme_live",
        url="https://feeds.feedburner.com/allfeaturedreports",
        home_url="https://www.cmegroup.com/rss.html",
        attribution="CME Group official RSS",
        poll_seconds=60,
    ),
    FeedSource(
        name="CME Financial Economic Releases",
        group="cme_live",
        url="https://feeds.feedburner.com/EconomicEventsInterestRates",
        home_url="https://www.cmegroup.com/rss.html",
        attribution="CME Group official RSS",
        poll_seconds=60,
    ),
    FeedSource(
        name="CME Daily Market Commentary",
        group="cme_live",
        url=(
            "https://www.cmegroup.com/rss/"
            "daily-market-commentary-videos.rss"
        ),
        home_url="https://www.cmegroup.com/rss.html",
        attribution="CME Group official RSS",
        poll_seconds=60,
    ),
    FeedSource(
        name="CME Metals Commentary",
        group="cme_live",
        url=(
            "https://www.cmegroup.com/rss/"
            "metals-video-commentary.rss"
        ),
        home_url="https://www.cmegroup.com/rss.html",
        attribution="CME Group official RSS",
        poll_seconds=60,
    ),
    FeedSource(
        name="CME FX Commentary",
        group="cme_live",
        url=(
            "https://www.cmegroup.com/rss/"
            "fx-video-commentary.rss"
        ),
        home_url="https://www.cmegroup.com/rss.html",
        attribution="CME Group official RSS",
        poll_seconds=60,
    ),
    FeedSource(
        name="CME Press Releases",
        group="cme_live",
        url="https://feeds.feedburner.com/mediaroom/CMsF",
        home_url="https://www.cmegroup.com/rss.html",
        attribution="CME Group official RSS",
        poll_seconds=60,
    ),

    FeedSource(
        name="Investing.com Forex News",
        group="investing",
        url="https://www.investing.com/rss/news_1.rss",
        home_url=(
            "https://www.investing.com/webmaster-tools/rss"
        ),
        attribution="Investing.com official RSS",
        poll_seconds=60,
    ),
    FeedSource(
        name="Investing.com Commodities News",
        group="investing",
        url="https://www.investing.com/rss/news_11.rss",
        home_url=(
            "https://www.investing.com/webmaster-tools/rss"
        ),
        attribution="Investing.com official RSS",
        poll_seconds=60,
    ),
    FeedSource(
        name="Investing.com Economic Indicators",
        group="investing",
        url="https://www.investing.com/rss/news_95.rss",
        home_url=(
            "https://www.investing.com/webmaster-tools/rss"
        ),
        attribution="Investing.com official RSS",
        poll_seconds=60,
    ),
    FeedSource(
        name="Investing.com Metals Analysis",
        group="investing",
        url=(
            "https://www.investing.com/rss/"
            "commodities_Metals.rss"
        ),
        home_url=(
            "https://www.investing.com/webmaster-tools/rss"
        ),
        attribution="Investing.com official RSS",
        poll_seconds=60,
    ),
    FeedSource(
        name="Forex Factory Calendar",
        group="forexfactory",
        url=(
            "https://nfs.faireconomy.media/"
            "ff_calendar_thisweek.json"
        ),
        home_url="https://www.forexfactory.com/calendar",
        kind="forex_factory_calendar",
        attribution="Forex Factory weekly JSON export",
        poll_seconds=180,
    ),
    FeedSource(
        name="Forex Factory News Index",
        group="forexfactory",
        url=(
            "https://news.google.com/rss/search?"
            "q=site%3Aforexfactory.com%2Fnews%20"
            "%28gold%20OR%20XAUUSD%20OR%20USD%20OR%20Fed%29"
            "&hl=en-IN&gl=IN&ceid=IN%3Aen"
        ),
        home_url="https://www.forexfactory.com/news",
        attribution="Links indexed by Google News",
    ),
    FeedSource(
        name="TradingView XAUUSD News Index",
        group="tradingview",
        url=(
            "https://news.google.com/rss/search?"
            "q=site%3Atradingview.com%2Fnews%20"
            "%28XAUUSD%20OR%20gold%20OR%20bullion%29"
            "&hl=en-IN&gl=IN&ceid=IN%3Aen"
        ),
        home_url=(
            "https://www.tradingview.com/"
            "symbols/XAUUSD/news/"
        ),
        attribution="Links indexed by Google News",
    ),
    FeedSource(
        name="Federal Reserve Monetary Policy",
        group="official",
        url=(
            "https://www.federalreserve.gov/"
            "feeds/press_monetary.xml"
        ),
        home_url=(
            "https://www.federalreserve.gov/"
            "feeds/feeds.htm"
        ),
        attribution="Federal Reserve official RSS",
    ),
    FeedSource(
        name="Federal Reserve Speeches",
        group="official",
        url=(
            "https://www.federalreserve.gov/"
            "feeds/speeches.xml"
        ),
        home_url=(
            "https://www.federalreserve.gov/"
            "feeds/feeds.htm"
        ),
        attribution="Federal Reserve official RSS",
    ),
    FeedSource(
        name="Federal Reserve Press Releases",
        group="official",
        url=(
            "https://www.federalreserve.gov/"
            "feeds/press_all.xml"
        ),
        home_url=(
            "https://www.federalreserve.gov/"
            "feeds/feeds.htm"
        ),
        attribution="Federal Reserve official RSS",
    ),
    FeedSource(
        name="World Gold Council Index",
        group="other",
        url=(
            "https://news.google.com/rss/search?"
            "q=site%3Agold.org%20"
            "%28gold%20OR%20central%20bank%20OR%20ETF%29"
            "&hl=en-IN&gl=IN&ceid=IN%3Aen"
        ),
        home_url="https://www.gold.org/goldhub",
        attribution="Links indexed by Google News",
    ),
    # Gold outlook and prediction sources. These are headline/link indexes;
    # the application keeps the original source link and does not copy full
    # copyrighted articles.
    FeedSource(
        name="CME Gold Outlook Index",
        group="cme_outlook",
        url=(
            "https://news.google.com/rss/search?"
            "q=site%3Acmegroup.com%20"
            "%28gold%20outlook%20OR%20gold%20forecast%20OR%20"
            "metals%20outlook%20OR%20gold%20target%29"
            "&hl=en-IN&gl=IN&ceid=IN%3Aen"
        ),
        home_url="https://www.cmegroup.com/markets/metals/precious/gold.html",
        kind="prediction_rss",
        attribution="CME Group links indexed by Google News",
        poll_seconds=180,
    ),
    FeedSource(
        name="World Gold Council Outlook",
        group="other",
        url=(
            "https://news.google.com/rss/search?"
            "q=site%3Agold.org%2Fgoldhub%20"
            "%28gold%20outlook%20OR%20gold%20forecast%20OR%20"
            "gold%20scenario%20OR%20gold%20target%29"
            "&hl=en-IN&gl=IN&ceid=IN%3Aen"
        ),
        home_url="https://www.gold.org/goldhub/research/market-commentary-and-outlook",
        kind="prediction_rss",
        attribution="World Gold Council links indexed by Google News",
        poll_seconds=180,
    ),
    FeedSource(
        name="TradingView Gold Forecasts",
        group="tradingview",
        url=(
            "https://news.google.com/rss/search?"
            "q=site%3Atradingview.com%20"
            "%28XAUUSD%20forecast%20OR%20gold%20outlook%20OR%20"
            "XAUUSD%20target%20OR%20gold%20prediction%29"
            "&hl=en-IN&gl=IN&ceid=IN%3Aen"
        ),
        home_url="https://www.tradingview.com/symbols/XAUUSD/ideas/",
        kind="prediction_rss",
        attribution="TradingView links indexed by Google News",
        poll_seconds=180,
    ),
    FeedSource(
        name="Investing.com Gold Forecasts",
        group="investing",
        url=(
            "https://news.google.com/rss/search?"
            "q=site%3Ainvesting.com%20"
            "%28gold%20forecast%20OR%20XAUUSD%20outlook%20OR%20"
            "gold%20target%29"
            "&hl=en-IN&gl=IN&ceid=IN%3Aen"
        ),
        home_url="https://www.investing.com/commodities/gold-analysis",
        kind="prediction_rss",
        attribution="Investing.com links indexed by Google News",
        poll_seconds=180,
    ),
    FeedSource(
        name="FXStreet Gold Forecasts",
        group="other",
        url=(
            "https://news.google.com/rss/search?"
            "q=site%3Afxstreet.com%20"
            "%28gold%20price%20forecast%20OR%20XAUUSD%20outlook%20OR%20"
            "gold%20target%29"
            "&hl=en-IN&gl=IN&ceid=IN%3Aen"
        ),
        home_url="https://www.fxstreet.com/markets/commodities/metals/gold",
        kind="prediction_rss",
        attribution="FXStreet links indexed by Google News",
        poll_seconds=180,
    ),
    FeedSource(
        name="Kitco Gold Outlooks",
        group="other",
        url=(
            "https://news.google.com/rss/search?"
            "q=site%3Akitco.com%20"
            "%28gold%20forecast%20OR%20gold%20outlook%20OR%20"
            "gold%20price%20target%29"
            "&hl=en-IN&gl=IN&ceid=IN%3Aen"
        ),
        home_url="https://www.kitco.com/news",
        kind="prediction_rss",
        attribution="Kitco links indexed by Google News",
        poll_seconds=180,
    ),

    # Additional CME indexes keep all CME-related material inside the
    # single CME News top-level section.
    FeedSource(
        name="CME Gold and Metals News Index",
        group="cme_live",
        url=(
            "https://news.google.com/rss/search?"
            "q=site%3Acmegroup.com%20"
            "%28gold%20OR%20XAUUSD%20OR%20bullion%20OR%20"
            "precious%20metals%20OR%20COMEX%29"
            "&hl=en-IN&gl=IN&ceid=IN%3Aen"
        ),
        home_url=(
            "https://www.cmegroup.com/"
            "markets/metals/precious/gold.html"
        ),
        attribution="CME Group links indexed by Google News",
        poll_seconds=120,
    ),
    FeedSource(
        name="CME Macro and Economic Research Index",
        group="cme_live",
        url=(
            "https://news.google.com/rss/search?"
            "q=site%3Acmegroup.com%20"
            "%28Federal%20Reserve%20OR%20FOMC%20OR%20CPI%20OR%20"
            "NFP%20OR%20inflation%20OR%20Treasury%20yields%29"
            "&hl=en-IN&gl=IN&ceid=IN%3Aen"
        ),
        home_url="https://www.cmegroup.com/news.html",
        attribution="CME Group links indexed by Google News",
        poll_seconds=120,
    ),
    FeedSource(
        name="CME Metals Update Index",
        group="cme_outlook",
        url=(
            "https://news.google.com/rss/search?"
            "q=site%3Acmegroup.com%2Fnewsletters%2Fmetals-update%20"
            "%28gold%20OR%20metals%20OR%20outlook%29"
            "&hl=en-IN&gl=IN&ceid=IN%3Aen"
        ),
        home_url=(
            "https://www.cmegroup.com/"
            "newsletters/metals-update.html"
        ),
        kind="prediction_rss",
        attribution="CME Group links indexed by Google News",
        poll_seconds=180,
    ),

    # More Investing.com coverage. Official RSS remains the primary feed;
    # these indexes add Gold/XAUUSD-specific links and keep attribution.
    FeedSource(
        name="Investing.com Gold Latest News Index",
        group="investing",
        url=(
            "https://news.google.com/rss/search?"
            "q=site%3Ainvesting.com%2Fnews%20"
            "%28gold%20OR%20XAUUSD%20OR%20bullion%20OR%20COMEX%29"
            "&hl=en-IN&gl=IN&ceid=IN%3Aen"
        ),
        home_url=(
            "https://www.investing.com/"
            "commodities/gold-news"
        ),
        attribution="Investing.com links indexed by Google News",
        poll_seconds=120,
    ),
    FeedSource(
        name="Investing.com Gold Analysis Index",
        group="investing",
        url=(
            "https://news.google.com/rss/search?"
            "q=site%3Ainvesting.com%2Fanalysis%20"
            "%28gold%20OR%20XAUUSD%20OR%20bullion%29"
            "&hl=en-IN&gl=IN&ceid=IN%3Aen"
        ),
        home_url=(
            "https://www.investing.com/"
            "commodities/gold-analysis"
        ),
        kind="prediction_rss",
        attribution="Investing.com links indexed by Google News",
        poll_seconds=120,
    ),
    FeedSource(
        name="Investing.com Dollar and Macro News Index",
        group="investing",
        url=(
            "https://news.google.com/rss/search?"
            "q=site%3Ainvesting.com%2Fnews%20"
            "%28Federal%20Reserve%20OR%20FOMC%20OR%20CPI%20OR%20"
            "NFP%20OR%20Dollar%20OR%20Treasury%20yields%29"
            "&hl=en-IN&gl=IN&ceid=IN%3Aen"
        ),
        home_url=(
            "https://www.investing.com/news/"
            "economic-indicators"
        ),
        attribution="Investing.com links indexed by Google News",
        poll_seconds=120,
    ),

)


SOURCE_GROUPS = {
    "all": "All XAU News",
    "high": "High Impact",
    "predictions": "Gold Outlook & Predictions",
    "cme": "CME News",
    "forexfactory": "Forex Factory",
    "investing": "Investing.com",
    "tradingview": "TradingView",
    "official": "Official Macro",
    "other": "Other Gold Sources",
    "saved": "Saved",
}
