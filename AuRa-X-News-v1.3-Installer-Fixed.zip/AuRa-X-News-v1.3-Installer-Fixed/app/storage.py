from __future__ import annotations

import json
import sqlite3
import threading
from pathlib import Path
from typing import Any


PREDICTION_COLUMNS: dict[str, str] = {
    "is_prediction": "INTEGER NOT NULL DEFAULT 0",
    "prediction_direction": "TEXT NOT NULL DEFAULT ''",
    "prediction_horizon": "TEXT NOT NULL DEFAULT ''",
    "prediction_target_low": "TEXT NOT NULL DEFAULT ''",
    "prediction_target_high": "TEXT NOT NULL DEFAULT ''",
    "prediction_percent_low": "TEXT NOT NULL DEFAULT ''",
    "prediction_percent_high": "TEXT NOT NULL DEFAULT ''",
    "prediction_basis": "TEXT NOT NULL DEFAULT ''",
    "prediction_strength": "INTEGER NOT NULL DEFAULT 0",
    "prediction_explanation_ml": "TEXT NOT NULL DEFAULT ''",
}


class NewsStore:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._initialize()

    def connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=30)
        connection.row_factory = sqlite3.Row
        return connection

    def _initialize(self) -> None:
        with self.connect() as connection:
            connection.executescript(
                """
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS news (
                    id TEXT PRIMARY KEY,
                    source TEXT NOT NULL,
                    source_group TEXT NOT NULL,
                    source_home TEXT NOT NULL DEFAULT '',
                    attribution TEXT NOT NULL DEFAULT '',
                    kind TEXT NOT NULL,
                    title TEXT NOT NULL,
                    summary TEXT NOT NULL DEFAULT '',
                    link TEXT NOT NULL DEFAULT '',
                    published_at TEXT NOT NULL,
                    event_time TEXT NOT NULL DEFAULT '',
                    impact_level TEXT NOT NULL DEFAULT 'LOW',
                    xau_bias TEXT NOT NULL DEFAULT 'MIXED',
                    confidence INTEGER NOT NULL DEFAULT 35,
                    mal_title TEXT NOT NULL DEFAULT '',
                    mal_summary TEXT NOT NULL DEFAULT '',
                    mal_explanation TEXT NOT NULL DEFAULT '',
                    translation_status TEXT NOT NULL DEFAULT 'FALLBACK',
                    status TEXT NOT NULL DEFAULT 'CURRENT',
                    currency TEXT NOT NULL DEFAULT '',
                    actual TEXT NOT NULL DEFAULT '',
                    forecast TEXT NOT NULL DEFAULT '',
                    previous TEXT NOT NULL DEFAULT '',
                    raw_json TEXT NOT NULL DEFAULT '{}',
                    saved INTEGER NOT NULL DEFAULT 0,
                    first_seen TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    is_prediction INTEGER NOT NULL DEFAULT 0,
                    prediction_direction TEXT NOT NULL DEFAULT '',
                    prediction_horizon TEXT NOT NULL DEFAULT '',
                    prediction_target_low TEXT NOT NULL DEFAULT '',
                    prediction_target_high TEXT NOT NULL DEFAULT '',
                    prediction_percent_low TEXT NOT NULL DEFAULT '',
                    prediction_percent_high TEXT NOT NULL DEFAULT '',
                    prediction_basis TEXT NOT NULL DEFAULT '',
                    prediction_strength INTEGER NOT NULL DEFAULT 0,
                    prediction_explanation_ml TEXT NOT NULL DEFAULT ''
                );

                CREATE INDEX IF NOT EXISTS idx_news_group_time
                ON news(source_group, published_at DESC);

                CREATE INDEX IF NOT EXISTS idx_news_impact
                ON news(impact_level, published_at DESC);


                CREATE TABLE IF NOT EXISTS source_status (
                    source TEXT PRIMARY KEY,
                    source_group TEXT NOT NULL,
                    ok INTEGER NOT NULL DEFAULT 0,
                    item_count INTEGER NOT NULL DEFAULT 0,
                    message TEXT NOT NULL DEFAULT '',
                    checked_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                """
            )
            existing = {
                row["name"]
                for row in connection.execute("PRAGMA table_info(news)")
            }
            for name, definition in PREDICTION_COLUMNS.items():
                if name not in existing:
                    connection.execute(
                        f"ALTER TABLE news ADD COLUMN {name} {definition}"
                    )
            connection.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_news_prediction
                ON news(is_prediction, prediction_direction, published_at DESC)
                """
            )

    def upsert_news(self, item: dict[str, Any]) -> None:
        columns = [
            "id", "source", "source_group", "source_home", "attribution",
            "kind", "title", "summary", "link", "published_at", "event_time",
            "impact_level", "xau_bias", "confidence", "mal_title",
            "mal_summary", "mal_explanation", "translation_status", "status",
            "currency", "actual", "forecast", "previous", "raw_json",
            "first_seen", "updated_at",
            "is_prediction", "prediction_direction", "prediction_horizon",
            "prediction_target_low", "prediction_target_high",
            "prediction_percent_low", "prediction_percent_high",
            "prediction_basis", "prediction_strength",
            "prediction_explanation_ml",
        ]
        defaults: dict[str, Any] = {
            "is_prediction": 0,
            "prediction_strength": 0,
        }
        values = [
            item.get(column, defaults.get(column, ""))
            for column in columns
        ]
        placeholders = ", ".join("?" for _ in columns)
        assignments = ", ".join(
            f"{column}=excluded.{column}"
            for column in columns
            if column not in {"id", "first_seen"}
        )

        with self._lock, self.connect() as connection:
            connection.execute(
                f"""
                INSERT INTO news ({", ".join(columns)})
                VALUES ({placeholders})
                ON CONFLICT(id) DO UPDATE SET {assignments}
                """,
                values,
            )

    def list_news(
        self,
        group: str = "all",
        search: str = "",
        timeline: str = "all",
        direction: str = "all",
        cme_section: str = "all",
        limit: int = 180,
    ) -> list[dict[str, Any]]:
        where: list[str] = []
        params: list[Any] = []

        if group == "high":
            where.append("impact_level = 'HIGH'")
        elif group == "predictions":
            where.append("is_prediction = 1")
        elif group == "saved":
            where.append("saved = 1")
        elif group == "cme":
            normalized_cme = cme_section.lower()

            if normalized_cme == "live":
                where.append("source_group = 'cme_live'")
            elif normalized_cme == "upcoming":
                where.append("source_group = 'cme_upcoming'")
            elif normalized_cme == "outlook":
                where.append(
                    "("
                    "source_group = 'cme_outlook' "
                    "OR (source_group = 'cme_live' AND is_prediction = 1)"
                    ")"
                )
            else:
                where.append(
                    "source_group IN ("
                    "'cme_live', 'cme_upcoming', 'cme_outlook'"
                    ")"
                )
        elif group != "all":
            where.append("source_group = ?")
            params.append(group)

        if direction.upper() in {
            "BULLISH", "BEARISH", "RANGEBOUND", "SCENARIO", "MIXED"
        }:
            where.append("prediction_direction = ?")
            params.append(direction.upper())

        if search:
            where.append(
                "(title LIKE ? OR summary LIKE ? OR mal_title LIKE ? "
                "OR mal_summary LIKE ? OR mal_explanation LIKE ? "
                "OR prediction_explanation_ml LIKE ? OR prediction_basis LIKE ?)"
            )
            token = f"%{search}%"
            params.extend([token] * 7)

        if timeline in {"upcoming", "current", "past"}:
            where.append("LOWER(status) = ?")
            params.append(timeline)

        clause = f"WHERE {' AND '.join(where)}" if where else ""
        params.append(max(1, min(limit, 500)))

        with self.connect() as connection:
            rows = connection.execute(
                f"""
                SELECT * FROM news
                {clause}
                ORDER BY
                    CASE status
                        WHEN 'UPCOMING' THEN 0
                        WHEN 'CURRENT' THEN 1
                        ELSE 2
                    END,
                    CASE
                        WHEN status='UPCOMING' THEN event_time
                        ELSE ''
                    END ASC,
                    published_at DESC
                LIMIT ?
                """,
                params,
            ).fetchall()

        return [dict(row) for row in rows]

    def set_saved(self, item_id: str, saved: bool) -> None:
        with self._lock, self.connect() as connection:
            connection.execute(
                "UPDATE news SET saved=? WHERE id=?",
                (1 if saved else 0, item_id),
            )

    def update_translation(
        self,
        item_id: str,
        mal_title: str,
        mal_summary: str,
        status: str,
    ) -> None:
        with self._lock, self.connect() as connection:
            connection.execute(
                """
                UPDATE news
                SET mal_title=?, mal_summary=?, translation_status=?
                WHERE id=?
                """,
                (mal_title, mal_summary, status, item_id),
            )

    def untranslated(self, limit: int = 20) -> list[dict[str, Any]]:
        with self.connect() as connection:
            rows = connection.execute(
                """
                SELECT * FROM news
                WHERE translation_status IN ('FALLBACK', 'RETRY')
                ORDER BY published_at DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [dict(row) for row in rows]

    def update_source_status(
        self,
        source: str,
        group: str,
        ok: bool,
        count: int,
        message: str,
        checked_at: str,
    ) -> None:
        with self._lock, self.connect() as connection:
            connection.execute(
                """
                INSERT INTO source_status(
                    source, source_group, ok, item_count, message, checked_at
                )
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(source) DO UPDATE SET
                    source_group=excluded.source_group,
                    ok=excluded.ok,
                    item_count=excluded.item_count,
                    message=excluded.message,
                    checked_at=excluded.checked_at
                """,
                (
                    source,
                    group,
                    1 if ok else 0,
                    count,
                    message,
                    checked_at,
                ),
            )

    def source_status(self) -> list[dict[str, Any]]:
        with self.connect() as connection:
            rows = connection.execute(
                "SELECT * FROM source_status ORDER BY source_group, source"
            ).fetchall()
        return [dict(row) for row in rows]

    def counts(self) -> dict[str, int]:
        with self.connect() as connection:
            row = connection.execute(
                """
                SELECT
                    COUNT(*) AS total,
                    SUM(CASE WHEN impact_level='HIGH' THEN 1 ELSE 0 END) AS high,
                    SUM(CASE WHEN status='UPCOMING' THEN 1 ELSE 0 END) AS upcoming,
                    SUM(CASE WHEN status='CURRENT' THEN 1 ELSE 0 END) AS current,
                    SUM(CASE WHEN status='PAST' THEN 1 ELSE 0 END) AS past,
                    SUM(CASE WHEN saved=1 THEN 1 ELSE 0 END) AS saved,
                    SUM(CASE WHEN is_prediction=1 THEN 1 ELSE 0 END) AS predictions,
                    SUM(
                        CASE WHEN is_prediction=1
                        AND prediction_direction='BULLISH'
                        THEN 1 ELSE 0 END
                    ) AS prediction_bullish,
                    SUM(
                        CASE WHEN is_prediction=1
                        AND prediction_direction='BEARISH'
                        THEN 1 ELSE 0 END
                    ) AS prediction_bearish,
                    SUM(
                        CASE WHEN is_prediction=1
                        AND prediction_direction='RANGEBOUND'
                        THEN 1 ELSE 0 END
                    ) AS prediction_rangebound,
                    SUM(
                        CASE WHEN is_prediction=1
                        AND prediction_direction='SCENARIO'
                        THEN 1 ELSE 0 END
                    ) AS prediction_scenario,
                    SUM(
                        CASE WHEN is_prediction=1
                        AND prediction_direction='MIXED'
                        THEN 1 ELSE 0 END
                    ) AS prediction_mixed,
                    SUM(
                        CASE WHEN source_group='cme_live'
                        THEN 1 ELSE 0 END
                    ) AS cme_live,
                    SUM(
                        CASE WHEN source_group='cme_upcoming'
                        THEN 1 ELSE 0 END
                    ) AS cme_upcoming,
                    SUM(
                        CASE WHEN source_group IN (
                            'cme_live', 'cme_upcoming', 'cme_outlook'
                        ) THEN 1 ELSE 0 END
                    ) AS cme,
                    SUM(
                        CASE WHEN source_group='cme_outlook'
                        THEN 1 ELSE 0 END
                    ) AS cme_outlook,
                    SUM(
                        CASE WHEN source_group='forexfactory'
                        THEN 1 ELSE 0 END
                    ) AS forexfactory,
                    SUM(
                        CASE WHEN source_group='investing'
                        THEN 1 ELSE 0 END
                    ) AS investing,
                    SUM(
                        CASE WHEN source_group='tradingview'
                        THEN 1 ELSE 0 END
                    ) AS tradingview,
                    SUM(
                        CASE WHEN source_group='official'
                        THEN 1 ELSE 0 END
                    ) AS official,
                    SUM(
                        CASE WHEN source_group='other'
                        THEN 1 ELSE 0 END
                    ) AS other
                FROM news
                """
            ).fetchone()
        return {key: int(row[key] or 0) for key in row.keys()}

    def set_setting(self, key: str, value: Any) -> None:
        serialized = json.dumps(value, ensure_ascii=False)
        with self._lock, self.connect() as connection:
            connection.execute(
                """
                INSERT INTO settings(key, value)
                VALUES (?, ?)
                ON CONFLICT(key) DO UPDATE SET value=excluded.value
                """,
                (key, serialized),
            )

    def get_setting(self, key: str, default: Any = None) -> Any:
        with self.connect() as connection:
            row = connection.execute(
                "SELECT value FROM settings WHERE key=?",
                (key,),
            ).fetchone()
        if not row:
            return default
        try:
            return json.loads(row["value"])
        except json.JSONDecodeError:
            return default
