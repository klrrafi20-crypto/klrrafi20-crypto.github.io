from __future__ import annotations

import logging
import os
import shutil
import socket
import threading
import time
import webbrowser
from pathlib import Path

from waitress import serve

from server import create_app


APP_NAME = "AuRa X News"
APP_VERSION = "1.3"
HOST = "127.0.0.1"
PORT = 8767


def user_data_dir() -> Path:
    base = Path(
        os.environ.get("LOCALAPPDATA", Path.home())
    )
    new_dir = base / "AuRaXNews"
    old_dir = base / "XAUNewsMalayalam"
    new_dir.mkdir(parents=True, exist_ok=True)

    new_database = new_dir / "aura_x_news.db"
    old_database = old_dir / "xau_news.db"

    if (
        not new_database.exists()
        and old_database.exists()
    ):
        try:
            shutil.copy2(
                old_database,
                new_database,
            )
            for suffix in ("-wal", "-shm"):
                old_sidecar = Path(
                    str(old_database) + suffix
                )
                new_sidecar = Path(
                    str(new_database) + suffix
                )
                if old_sidecar.exists():
                    shutil.copy2(
                        old_sidecar,
                        new_sidecar,
                    )
        except OSError:
            logging.exception(
                "Could not import the older cached news database."
            )

    return new_dir


def port_open(host: str, port: int) -> bool:
    try:
        with socket.create_connection(
            (host, port),
            timeout=1,
        ):
            return True
    except OSError:
        return False


def main() -> int:
    logging.basicConfig(
        level=logging.INFO,
        format=(
            "%(asctime)s | %(levelname)s | "
            "%(name)s | %(message)s"
        ),
    )

    data_dir = user_data_dir()
    application, _store, collector, translator = create_app(
        data_dir
    )
    collector.start()
    translator.start()

    if not port_open(HOST, PORT):
        server_thread = threading.Thread(
            target=lambda: serve(
                application,
                host=HOST,
                port=PORT,
                threads=8,
                channel_timeout=60,
            ),
            name="aura-x-news-server",
            daemon=True,
        )
        server_thread.start()

    deadline = time.time() + 20
    while (
        time.time() < deadline
        and not port_open(HOST, PORT)
    ):
        time.sleep(0.2)

    url = f"http://{HOST}:{PORT}"

    try:
        import webview

        webview.create_window(
            f"{APP_NAME} v{APP_VERSION}",
            url,
            width=1380,
            height=880,
            min_size=(920, 620),
            background_color="#ffffff",
            text_select=True,
        )
        webview.start(
            debug=False,
            private_mode=False,
        )
    except Exception:
        webbrowser.open(url)
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass
    finally:
        collector.stop()
        translator.stop()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
