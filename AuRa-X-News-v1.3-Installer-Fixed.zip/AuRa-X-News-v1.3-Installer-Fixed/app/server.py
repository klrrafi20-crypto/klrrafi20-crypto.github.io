from __future__ import annotations

from pathlib import Path
from typing import Any

from flask import Flask, jsonify, render_template, request

from collector import NewsCollector
from sources import SOURCE_GROUPS
from storage import NewsStore
from translator import MalayalamTranslator


def create_app(
    data_dir: Path,
) -> tuple[Flask, NewsStore, NewsCollector, MalayalamTranslator]:
    application = Flask(
        __name__,
        template_folder="templates",
        static_folder="static",
    )

    store = NewsStore(data_dir / "aura_x_news.db")
    collector = NewsCollector(store)
    translator = MalayalamTranslator(store)

    @application.get("/")
    def index() -> str:
        return render_template(
            "index.html",
            source_groups=SOURCE_GROUPS,
        )

    @application.get("/api/news")
    def api_news() -> Any:
        group = request.args.get("group", "all")
        search = request.args.get("search", "").strip()
        timeline = request.args.get("timeline", "all")
        direction = request.args.get("direction", "all")
        cme_section = request.args.get("cme_section", "all")
        limit = request.args.get("limit", "180")

        try:
            parsed_limit = int(limit)
        except ValueError:
            parsed_limit = 180

        items = store.list_news(
            group=group,
            search=search,
            timeline=timeline,
            direction=direction,
            cme_section=cme_section,
            limit=parsed_limit,
        )
        return jsonify(
            {
                "items": items,
                "counts": store.counts(),
                "source_status": store.source_status(),
            }
        )

    @application.post("/api/refresh")
    def api_refresh() -> Any:
        collector.refresh_now()
        return jsonify(
            {"ok": True, "message": "Refresh requested."}
        )

    @application.post("/api/save/<item_id>")
    def api_save(item_id: str) -> Any:
        body = request.get_json(silent=True) or {}
        store.set_saved(
            item_id,
            bool(body.get("saved")),
        )
        return jsonify({"ok": True})

    @application.get("/api/health")
    def api_health() -> Any:
        statuses = store.source_status()
        connected = sum(
            1 for item in statuses if item["ok"]
        )
        return jsonify(
            {
                "ok": True,
                "connected_sources": connected,
                "total_sources": len(statuses),
                "counts": store.counts(),
            }
        )

    return application, store, collector, translator
