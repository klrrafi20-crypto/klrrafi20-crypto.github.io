param(
    [string]$InstallRoot = ""
)

$ErrorActionPreference = "SilentlyContinue"

if ([string]::IsNullOrWhiteSpace($InstallRoot)) {
    $InstallRoot = Join-Path $env:LOCALAPPDATA "Programs\AuRaXNews"
}

Add-Type -AssemblyName System.Windows.Forms

$message = "Uninstall AuRa X News? Cached news and saved stories will also be removed."
$title = "AuRa X News"
$buttons = [System.Windows.Forms.MessageBoxButtons]::YesNo
$icon = [System.Windows.Forms.MessageBoxIcon]::Question

$answer = [System.Windows.Forms.MessageBox]::Show($message, $title, $buttons, $icon)

if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
    exit 0
}

$desktop = [Environment]::GetFolderPath("Desktop")
$desktopLink = Join-Path $desktop "AuRa X News.lnk"
$startMenu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\AuRa X News"
$dataFolder = Join-Path $env:LOCALAPPDATA "AuRaXNews"

Remove-Item $desktopLink -Force -ErrorAction SilentlyContinue
Remove-Item $startMenu -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item $dataFolder -Recurse -Force -ErrorAction SilentlyContinue

$removeName = "aura-x-news-remove-" + [guid]::NewGuid().ToString("N") + ".cmd"
$removeScript = Join-Path $env:TEMP $removeName

$removeContent = '@echo off' + [Environment]::NewLine
$removeContent += 'timeout /t 2 /nobreak >nul' + [Environment]::NewLine
$removeContent += 'rmdir /s /q "' + $InstallRoot + '"' + [Environment]::NewLine
$removeContent += 'del "%~f0"' + [Environment]::NewLine

[System.IO.File]::WriteAllText($removeScript, $removeContent, [System.Text.Encoding]::ASCII)
Start-Process -FilePath $removeScript -WindowStyle Hidden
