from __future__ import annotations

import re
from typing import Any


PREDICTION_MARKERS = {
    "outlook", "forecast", "prediction", "predicts", "price target",
    "target price", "target", "could rise", "could fall", "may rise",
    "may fall", "likely to rise", "likely to fall", "expected to rise",
    "expected to fall", "set to rise", "set to fall", "sees gold",
    "technical analysis", "support", "resistance", "breakout",
    "breakdown", "upside", "downside", "rally", "pullback",
    "correction", "rangebound", "range-bound", "scenario",
    "what to expect", "bullish", "bearish", "higher", "lower",
}

GOLD_TERMS = {
    "gold", "xau", "xauusd", "bullion", "comex gold",
    "precious metal", "yellow metal",
}

BULLISH_PREDICTION_TERMS = {
    "bullish", "rise", "rises", "rising", "higher", "upside",
    "rally", "surge", "gain", "gains", "advance", "breakout",
    "rebound", "recover", "supportive", "push higher", "climb",
    "record high", "new high", "positive outlook",
}

BEARISH_PREDICTION_TERMS = {
    "bearish", "fall", "falls", "falling", "lower", "downside",
    "drop", "decline", "slip", "selloff", "sell-off", "correction",
    "pullback", "breakdown", "pressure", "weakness", "negative outlook",
}

RANGE_TERMS = {
    "rangebound", "range-bound", "sideways", "consolidation",
    "remain flat", "little changed", "neutral outlook", "±",
}

SCENARIO_TERMS = {
    "scenario", "if ", "could either", "bull case", "bear case",
    "upside case", "downside case", "hypothetical",
}

DIRECT_BULLISH_PATTERN = re.compile(
    r"\b(?:gold|xauusd|xau|bullion)(?:\s+price)?\b"
    r"(?:\s+(?:outlook|forecast))?[\s:,-]{0,8}"
    r"(?:could|may|might|likely|expected|set\s+to|forecast\s+to|"
    r"projected\s+to)?\s*"
    r"(?:rise|rally|surge|climb|gain|advance|rebound|recover|"
    r"move\s+higher|push\s+higher|break\s+higher)\b",
    re.IGNORECASE,
)

DIRECT_BEARISH_PATTERN = re.compile(
    r"\b(?:gold|xauusd|xau|bullion)(?:\s+price)?\b"
    r"(?:\s+(?:outlook|forecast))?[\s:,-]{0,8}"
    r"(?:could|may|might|likely|expected|set\s+to|forecast\s+to|"
    r"projected\s+to)?\s*"
    r"(?:fall|drop|decline|slip|correct|pull\s+back|"
    r"move\s+lower|push\s+lower|break\s+lower)\b",
    re.IGNORECASE,
)

HORIZON_RULES = (
    ("INTRADAY", ("intraday", "today", "session", "next hours")),
    ("THIS WEEK", ("this week", "weekly", "week ahead", "next week")),
    ("SHORT TERM", ("short term", "short-term", "near term", "near-term")),
    ("THIS MONTH", ("this month", "monthly", "month ahead")),
    ("QUARTER", ("quarter", "q1", "q2", "q3", "q4")),
    ("YEAR", ("this year", "year-end", "year end", "2025", "2026", "2027")),
    ("LONG TERM", ("long term", "long-term", "multi-year", "structural")),
)

PRICE_NUMBER = (
    r"(?:\d{1,3}(?:,\d{3})+|\d{3,5})(?:\.\d+)?"
)

PRICE_RANGE_PATTERNS = (
    re.compile(
        rf"(?:US\$|\$)\s*({PRICE_NUMBER})"
        rf"\s*(?:-|–|—|to)\s*(?:US\$|\$)?\s*"
        rf"({PRICE_NUMBER})",
        re.IGNORECASE,
    ),
    re.compile(
        rf"(?:target|range|towards?|between)\s*(?:US\$|\$)?\s*"
        rf"({PRICE_NUMBER})"
        rf"\s*(?:-|–|—|to|and)\s*(?:US\$|\$)?\s*"
        rf"({PRICE_NUMBER})",
        re.IGNORECASE,
    ),
)

SINGLE_PRICE_PATTERNS = (
    re.compile(
        rf"(?:target(?:ing)?|towards?|reach(?:ing)?|above|below|at)\s*"
        rf"(?:US\$|\$)\s*({PRICE_NUMBER})",
        re.IGNORECASE,
    ),
    re.compile(
        rf"(?:US\$|\$)\s*({PRICE_NUMBER})"
        rf"\s*(?:target|forecast|objective)",
        re.IGNORECASE,
    ),
)

PERCENT_RANGE_PATTERN = re.compile(
    r"([+-]?\d+(?:\.\d+)?)\s*%\s*(?:-|–|—|to)\s*"
    r"([+-]?\d+(?:\.\d+)?)\s*%",
    re.IGNORECASE,
)

SINGLE_PERCENT_PATTERN = re.compile(
    r"(?:rise|gain|upside|fall|drop|downside|decline|correction)"
    r"(?:\s+of|\s+by|\s+around|\s+about)?\s*"
    r"([+-]?\d+(?:\.\d+)?)\s*%",
    re.IGNORECASE,
)


def _clean_number(value: str) -> str:
    return value.replace(",", "").strip()


def _count_terms(text: str, terms: set[str]) -> int:
    return sum(1 for term in terms if term in text)


def _horizon(text: str) -> str:
    for label, terms in HORIZON_RULES:
        if any(term in text for term in terms):
            return label
    return "UNSPECIFIED"


def _targets(text: str) -> tuple[str, str, str, str]:
    target_low = ""
    target_high = ""
    percent_low = ""
    percent_high = ""

    for pattern in PRICE_RANGE_PATTERNS:
        match = pattern.search(text)
        if match:
            target_low = _clean_number(match.group(1))
            target_high = _clean_number(match.group(2))
            break

    if not target_low:
        for pattern in SINGLE_PRICE_PATTERNS:
            match = pattern.search(text)
            if match:
                target_low = _clean_number(match.group(1))
                target_high = target_low
                break

    percent_range = PERCENT_RANGE_PATTERN.search(text)
    if percent_range:
        percent_low = percent_range.group(1)
        percent_high = percent_range.group(2)
    else:
        percent = SINGLE_PERCENT_PATTERN.search(text)
        if percent:
            percent_low = percent.group(1)
            percent_high = percent_low

    return target_low, target_high, percent_low, percent_high


def _basis(text: str) -> str:
    if any(term in text for term in ("technical analysis", "support", "resistance", "breakout", "breakdown")):
        return "TECHNICAL ANALYSIS"
    if any(term in text for term in ("scenario", "hypothetical", "bull case", "bear case")):
        return "SCENARIO ANALYSIS"
    if any(term in text for term in ("fed", "rate", "yield", "dollar", "inflation", "growth", "geopolitical")):
        return "MACRO OUTLOOK"
    if any(term in text for term in ("demand", "etf", "central bank", "flows", "positioning")):
        return "FLOW / DEMAND OUTLOOK"
    return "SOURCE FORECAST"


def prediction_analysis(
    title: str,
    summary: str = "",
    source_name: str = "",
    force: bool = False,
) -> dict[str, Any]:
    title_text = title.lower()
    text = f"{title} {summary}".lower()
    has_gold = any(term in text for term in GOLD_TERMS)
    has_marker = any(term in text for term in PREDICTION_MARKERS)
    is_prediction = bool(force or (has_gold and has_marker))

    if not is_prediction:
        return no_prediction_fields()

    bullish = _count_terms(text, BULLISH_PREDICTION_TERMS)
    bearish = _count_terms(text, BEARISH_PREDICTION_TERMS)
    range_score = _count_terms(text, RANGE_TERMS)
    scenario_score = _count_terms(text, SCENARIO_TERMS)
    # Direct direction must come from the headline/title itself.
    # This prevents a bullish headline from being reclassified because the
    # summary mentions a bearish macro driver such as "rates fall".
    direct_bullish = bool(DIRECT_BULLISH_PATTERN.search(title_text))
    direct_bearish = bool(DIRECT_BEARISH_PATTERN.search(title_text))

    if direct_bullish and direct_bearish:
        direction = "SCENARIO"
    elif direct_bullish:
        direction = "BULLISH"
    elif direct_bearish:
        direction = "BEARISH"
    elif range_score > max(bullish, bearish):
        direction = "RANGEBOUND"
    elif scenario_score and bullish and bearish:
        direction = "SCENARIO"
    elif bullish > bearish:
        direction = "BULLISH"
    elif bearish > bullish:
        direction = "BEARISH"
    elif scenario_score:
        direction = "SCENARIO"
    else:
        direction = "MIXED"

    target_low, target_high, percent_low, percent_high = _targets(text)
    explicit = bool(
        target_low
        or percent_low
        or direction in {"BULLISH", "BEARISH", "RANGEBOUND"}
    )
    extraction_confidence = min(
        90,
        48
        + (18 if force else 0)
        + (12 if target_low else 0)
        + (8 if percent_low else 0)
        + (10 if explicit else 0),
    )

    horizon = _horizon(text)
    basis = _basis(text)

    target_text = ""
    if target_low:
        if target_high and target_high != target_low:
            target_text = f"US${target_low} – US${target_high}"
        else:
            target_text = f"US${target_low}"

    percent_text = ""
    if percent_low:
        if percent_high and percent_high != percent_low:
            percent_text = f"{percent_low}% – {percent_high}%"
        else:
            percent_text = f"{percent_low}%"

    direction_ml = {
        "BULLISH": "source Gold ഉയരാൻ സാധ്യത കാണിക്കുന്നു",
        "BEARISH": "source Gold താഴെയാകാൻ സാധ്യത കാണിക്കുന്നു",
        "RANGEBOUND": "source Gold range-bound/sideways ആയേക്കാമെന്ന് പറയുന്നു",
        "SCENARIO": "source bullish-വും bearish-വും ആയ വിവിധ scenarios നൽകുന്നു",
        "MIXED": "source direction വ്യക്തമായി സ്ഥിരീകരിക്കുന്നില്ല",
    }[direction]

    details: list[str] = [
        f"ഇത് {source_name or 'original source'} പ്രസിദ്ധീകരിച്ച outlook/prediction ആണ്; AuRa X News-ന്റെ സ്വന്തം guaranteed prediction അല്ല.",
        f"Extracted view: {direction_ml}.",
        f"Horizon: {horizon}.",
        f"Basis: {basis}.",
    ]
    if target_text:
        details.append(f"Article-ൽ കണ്ട explicit price target/range: {target_text}.")
    if percent_text:
        details.append(f"Article-ൽ കണ്ട expected percentage move: {percent_text}.")
    if not target_text and not percent_text:
        details.append("Headline/summary-ൽ explicit price target കണ്ടെത്തിയിട്ടില്ല.")
    details.append(
        "Original article തുറന്ന് assumptions, date, full context, support/resistance, USD, yields എന്നിവ പരിശോധിക്കണം."
    )

    return {
        "is_prediction": 1,
        "prediction_direction": direction,
        "prediction_horizon": horizon,
        "prediction_target_low": target_low,
        "prediction_target_high": target_high,
        "prediction_percent_low": percent_low,
        "prediction_percent_high": percent_high,
        "prediction_basis": basis,
        "prediction_strength": extraction_confidence,
        "prediction_explanation_ml": " ".join(details),
    }


def no_prediction_fields() -> dict[str, Any]:
    return {
        "is_prediction": 0,
        "prediction_direction": "",
        "prediction_horizon": "",
        "prediction_target_low": "",
        "prediction_target_high": "",
        "prediction_percent_low": "",
        "prediction_percent_high": "",
        "prediction_basis": "",
        "prediction_strength": 0,
        "prediction_explanation_ml": "",
    }
