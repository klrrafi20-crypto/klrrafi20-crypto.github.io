"""RC - AI Powered Cloud Security Platform."""

from __future__ import annotations

import json
from collections import deque
from datetime import datetime
from io import BytesIO
from pathlib import Path
from typing import Any, Iterable

import joblib
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
import streamlit as st
from botocore.exceptions import ClientError, NoCredentialsError
from PIL import Image
from sklearn.ensemble import IsolationForest
from streamlit_autorefresh import st_autorefresh

from aws_connection import (
    DEFAULT_PROFILE_LABEL,
    DEFAULT_REGION,
    available_profiles,
    client_for,
    create_access_key_session,
    create_session,
    friendly_aws_error,
    load_settings,
    save_settings,
    test_connection,
)
from credential_vault import (
    delete_credentials,
    delete_gemini_key,
    load_credentials,
    load_gemini_key,
    save_credentials,
    save_gemini_key,
    validate_label,
)


BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "assets" / "threat_model.pkl"
SAMPLE_CSV = BASE_DIR / "sample_data" / "login_events.csv"
RC_ICON_PATH = BASE_DIR / "assets" / "rc_icon.png"
REMEDIATION_POLICY_PATH = BASE_DIR / "aws" / "RCCloudSecRemediationPolicy.json"
HIGH_RISK_POLICIES = {"AdministratorAccess", "IAMFullAccess", "PowerUserAccess"}
ESCALATION_ACTIONS = {
    "iam:CreatePolicyVersion",
    "iam:SetDefaultPolicyVersion",
    "iam:PassRole",
    "iam:CreateAccessKey",
    "iam:AttachUserPolicy",
    "iam:AttachRolePolicy",
    "iam:PutUserPolicy",
    "iam:PutRolePolicy",
    "iam:AddUserToGroup",
    "iam:UpdateAssumeRolePolicy",
    "iam:CreateLoginProfile",
    "iam:UpdateLoginProfile",
}
DANGEROUS_PORTS = {
    22: "SSH",
    23: "Telnet",
    3389: "RDP",
    3306: "MySQL",
    5432: "PostgreSQL",
    27017: "MongoDB",
    6379: "Redis",
}
S3_RESULT_COLUMNS = [
    "bucket_name",
    "block_public_access",
    "public_bucket_policy",
    "public_acl",
    "risk_level",
    "notes",
]
SG_RESULT_COLUMNS = [
    "security_group",
    "group_id",
    "ip_protocol",
    "from_port",
    "to_port",
    "port",
    "service",
    "open_to",
    "risk_level",
]
ZERO_TRUST_COLUMNS = [
    "user_name",
    "high_risk_policy",
    "mfa_enabled",
    "recent_bruteforce_activity",
    "shadow_admin_indicator",
    "trust_score",
    "trust_level",
    "reasons",
]
RESULT_SCHEMAS = {
    "cloudtrail_data": {"User name", "Event name", "brute_force_detected", "anomaly_score"},
    "cloudtrail_alerts": {"User name", "Event name", "brute_force_detected", "anomaly_score"},
    "iam_results": {
        "user_name",
        "mfa_enabled",
        "risky_policies",
        "shadow_admin_heuristic",
        "escalation_actions",
        "risk_level",
        "trust_score",
    },
    "s3_results": set(S3_RESULT_COLUMNS),
    "sg_results": set(SG_RESULT_COLUMNS),
    "flow_results": {"src_ip", "dst_ip", "src_port", "dst_port", "action"},
    "zt_results": set(ZERO_TRUST_COLUMNS),
}


st.set_page_config(
    page_title="RC | AI Powered Cloud Security Platform",
    page_icon=Image.open(RC_ICON_PATH),
    layout="wide",
)


def apply_design() -> None:
    st.markdown(
        """
        <style>
        :root { --navy:#081120; --panel:#101d31; --line:#24344d; --cyan:#35c7f0; --text:#e8f0fa; }
        .stApp { background: radial-gradient(circle at 80% 0%, #132945 0%, #081120 40%, #070d17 100%); }
        [data-testid="stSidebar"] { background: #091423; border-right: 1px solid #1d314b; }
        [data-testid="stHeader"] { background: rgba(7,13,23,.82); }
        [data-testid="stToolbar"], #MainMenu, footer { visibility: hidden; }
        [data-testid="stDecoration"] { display: none; }
        .block-container { max-width: 1500px; padding-top: 1.2rem; padding-bottom: 3rem; }
        h1, h2, h3, p, label, [data-testid="stMarkdownContainer"] { color: var(--text); }
        .hero { padding: 1.3rem 1.5rem; border: 1px solid #284663; border-radius: 18px;
                background: linear-gradient(120deg, rgba(20,49,78,.95), rgba(8,20,35,.92));
                box-shadow: 0 14px 40px rgba(0,0,0,.28); margin-bottom: 1rem; }
        .hero-title { font-size: 2rem; font-weight: 750; letter-spacing: -.02em; color: #f2f7ff; }
        .hero-sub { color: #a9bad0; margin-top: .35rem; }
        .brand-lockup { display:flex; align-items:center; gap:.8rem; margin-bottom:.3rem; }
        .rc-logo { width:3.2rem; height:3.2rem; border-radius:1rem; display:flex; align-items:center;
                justify-content:center; color:#fff; font-size:1.15rem; font-weight:850; letter-spacing:-.04em;
                background:linear-gradient(145deg,#35c7f0,#1679a5 55%,#0b1f35); border:2px solid #83e3f8;
                box-shadow:0 8px 22px rgba(19,156,201,.25); }
        .remediation-card { border:1px solid #6d5420; border-radius:14px; padding:1rem 1.1rem;
                background:linear-gradient(145deg,rgba(63,45,14,.85),rgba(17,28,43,.95)); margin-top:1rem; }
        .status-ok, .status-off { display:inline-block; border-radius:999px; padding:.28rem .65rem; font-size:.78rem; font-weight:700; }
        .status-ok { color:#73f1b7; background:#0d3a31; border:1px solid #16634f; }
        .status-off { color:#ffd08a; background:#3a2b11; border:1px solid #6c4f19; }
        [data-testid="stMetric"] { background: linear-gradient(145deg, rgba(18,34,56,.96), rgba(11,24,41,.96));
                border:1px solid #243c59; padding:1rem 1.05rem; border-radius:14px; min-height:112px; }
        [data-testid="stMetricValue"] { color:#eef7ff; }
        .stButton > button, .stDownloadButton > button { border-radius:10px; border:1px solid #278eb1;
                background:linear-gradient(135deg,#1679a5,#1ba7c7); color:white; font-weight:650; }
        .stButton > button:hover, .stDownloadButton > button:hover { border-color:#66d7f1; color:white; }
        [data-baseweb="tab-list"] { gap:.45rem; background:#0b1727; border:1px solid #203754; border-radius:12px; padding:.35rem; }
        [data-baseweb="tab"] { border-radius:8px; padding:.65rem .9rem; }
        [aria-selected="true"] { background:#183655 !important; }
        [data-testid="stDataFrame"] { border:1px solid #233a56; border-radius:12px; overflow:hidden; }
        div[data-testid="stExpander"] { border:1px solid #233a56; border-radius:12px; background:#0c1829; }
        .small-note { color:#94a9c1; font-size:.86rem; }
        </style>
        """,
        unsafe_allow_html=True,
    )


def now_text() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def valid_frame(value: Any, required_columns: Iterable[str] = ()) -> bool:
    """Return True only for a DataFrame with the result schema the UI expects."""
    return isinstance(value, pd.DataFrame) and set(required_columns).issubset(value.columns)


def state_frame(key: str, required_columns: Iterable[str] = ()) -> pd.DataFrame | None:
    value = st.session_state.get(key)
    return value if valid_frame(value, required_columns) else None


def count_value(frame: pd.DataFrame | None, column: str, value: Any) -> int:
    if frame is None or column not in frame.columns:
        return 0
    return int(frame[column].eq(value).sum())


def validate_credential_set(access_key: str, secret_key: str, session_token: str = "") -> dict[str, str]:
    """Validate the credential shape before sending it to AWS STS."""
    access = access_key.strip()
    secret = secret_key.strip()
    token = session_token.strip()
    if not access or not secret:
        raise ValueError("Both Access Key ID and Secret Access Key are required.")
    prefix = access[:4].upper()
    if prefix not in {"AKIA", "ASIA"}:
        raise ValueError(
            "AWS Access Key ID should start with AKIA (long-term) or ASIA (temporary). "
            "Do not enter an account ID, console user name, or password."
        )
    if prefix == "ASIA" and not token:
        raise ValueError("ASIA temporary credentials require the matching AWS Session Token.")
    if prefix == "AKIA" and token:
        raise ValueError("AKIA long-term credentials do not use a Session Token. Clear the Session Token field.")
    return {"access_key": access, "secret_key": secret, "session_token": token}


def show_credential_recovery(access_key: str = "") -> None:
    prefix = access_key.strip()[:4].upper()
    with st.expander("Correct this AWS credential", expanded=True):
        if prefix == "ASIA":
            st.error("This is an ASIA temporary credential. Paste a fresh Access Key, Secret Key, and Session Token from the same session.")
        elif prefix == "AKIA":
            st.error("This is an AKIA long-term credential. Leave Session Token empty and confirm the IAM access key is Active.")
        else:
            st.error("Use an AWS Access Key ID beginning with AKIA or ASIA—not your account ID, console user name, or password.")
        st.markdown(
            "1. Click **Delete saved credential** below to remove an invalid cached key.  \n"
            "2. For **AKIA**, create or verify an active IAM-user access key and leave Session Token empty.  \n"
            "3. For **ASIA**, obtain a fresh three-part temporary credential set and paste all three matching values.  \n"
            "4. Never mix the Access Key ID from one credential with the Secret Key or Session Token from another."
        )
        st.warning("Never paste AWS secrets into chat, screenshots, source code, or email.")


def discard_incompatible_result_state() -> list[str]:
    """Remove incomplete results left by an older build or an interrupted scan."""
    removed = []
    for key, required_columns in RESULT_SCHEMAS.items():
        if key in st.session_state and not valid_frame(st.session_state.get(key), required_columns):
            st.session_state.pop(key, None)
            removed.append(key)
    if "cloudtrail_data" not in st.session_state:
        st.session_state.pop("cloudtrail_alerts", None)
        st.session_state.pop("last_bruteforce_users", None)
    if "iam_results" not in st.session_state:
        st.session_state.pop("iam_edges", None)
        st.session_state.pop("iam_ai_explanations", None)
    return removed


def show_error(exc: Exception) -> None:
    st.error(friendly_aws_error(exc))
    with st.expander("Technical details"):
        st.code(str(exc))
    if isinstance(exc, ClientError):
        error_code = str(exc.response.get("Error", {}).get("Code", ""))
        if error_code in {
            "InvalidClientTokenId",
            "InvalidAccessKeyId",
            "ExpiredToken",
            "ExpiredTokenException",
            "SignatureDoesNotMatch",
        }:
            attempted_prefix = str(st.session_state.pop("credential_error_prefix", ""))
            credentials = st.session_state.get("runtime_aws_credentials")
            if not credentials:
                try:
                    credentials = load_credentials(st.session_state.get("credential_label", "rc-cloudsec"))
                except Exception:
                    credentials = None
            show_credential_recovery(attempted_prefix or (credentials or {}).get("access_key", ""))


def get_scan_session():
    if "aws_identity" not in st.session_state:
        raise NoCredentialsError()
    if st.session_state.connection_mode == "Access keys inside app":
        credentials = st.session_state.get("runtime_aws_credentials")
        if not credentials:
            credentials = load_credentials(st.session_state.credential_label)
        if not credentials:
            raise NoCredentialsError()
        return create_access_key_session(
            credentials["access_key"],
            credentials["secret_key"],
            credentials.get("session_token", ""),
            st.session_state.selected_region,
        )
    return create_session(st.session_state.selected_profile, st.session_state.selected_region)


def remember_scan(name: str, count: int) -> None:
    st.session_state.setdefault("scan_times", {})[name] = now_text()
    st.session_state.setdefault("scan_counts", {})[name] = int(count)
    st.session_state.pop("report_exec_summary", None)


def remember_remediation(service: str, resource: str, action: str, status: str, details: str) -> None:
    history = st.session_state.get("remediation_history", [])
    if not isinstance(history, list):
        history = []
    history.append(
        {
            "Time": now_text(),
            "Service": service,
            "Resource": resource,
            "Action": action,
            "Status": status,
            "Details": details,
        }
    )
    st.session_state.remediation_history = history[-100:]
    st.session_state.pop("report_exec_summary", None)


def paginate(client: Any, operation: str, result_key: str, **kwargs: Any) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    paginator = client.get_paginator(operation)
    for page in paginator.paginate(**kwargs):
        results.extend(page.get(result_key, []))
    return results


def scan_cloudtrail(session: Any, max_events: int = 1000) -> pd.DataFrame:
    cloudtrail = client_for(session, "cloudtrail", read_timeout=30)
    paginator = cloudtrail.get_paginator("lookup_events")
    events: list[dict[str, Any]] = []
    for page in paginator.paginate(PaginationConfig={"MaxItems": max_events, "PageSize": 50}):
        events.extend(page.get("Events", []))

    rows = []
    for event in events:
        try:
            detail = json.loads(event.get("CloudTrailEvent", "{}"))
        except (TypeError, json.JSONDecodeError):
            detail = {}
        identity = detail.get("userIdentity", {}) or {}
        username = event.get("Username") or identity.get("userName") or identity.get("type") or "Unknown"
        rows.append(
            {
                "Event time": event.get("EventTime"),
                "User name": username,
                "Event source": event.get("EventSource"),
                "Event name": event.get("EventName"),
                "Source IP address": detail.get("sourceIPAddress", "Unknown"),
                "Error code": detail.get("errorCode"),
                "Read-only": detail.get("readOnly", False),
            }
        )
    columns = [
        "Event time",
        "User name",
        "Event source",
        "Event name",
        "Source IP address",
        "Error code",
        "Read-only",
    ]
    return pd.DataFrame(rows, columns=columns)


def analyze_cloudtrail(data: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    if data.empty:
        frame = data.copy()
        derived_columns = {
            "hour_of_day": pd.Series(dtype="int64"),
            "is_error": pd.Series(dtype="int64"),
            "is_readonly": pd.Series(dtype="int64"),
            "event_rarity": pd.Series(dtype="float64"),
            "recent_failed_count": pd.Series(dtype="float64"),
            "brute_force_detected": pd.Series(dtype="bool"),
            "anomaly": pd.Series(dtype="int64"),
            "anomaly_score": pd.Series(dtype="float64"),
        }
        for column, empty_series in derived_columns.items():
            if column not in frame.columns:
                frame[column] = empty_series
        return frame, frame.copy()
    frame = data.copy()
    frame["Event time"] = pd.to_datetime(frame["Event time"], errors="coerce", utc=True)
    frame = frame.dropna(subset=["Event time"]).sort_values("Event time").reset_index(drop=True)
    frame["hour_of_day"] = frame["Event time"].dt.hour
    frame["is_error"] = frame["Error code"].notna().astype(int)
    frame["is_readonly"] = frame["Read-only"].astype(str).str.lower().isin({"true", "1"}).astype(int)
    counts = frame["Event name"].fillna("Unknown").value_counts()
    frame["event_rarity"] = frame["Event name"].fillna("Unknown").map(lambda x: 1 / counts[x])
    frame["recent_failed_count"] = 0.0
    for _, indices in frame.groupby("User name", dropna=False).groups.items():
        failures = frame.loc[indices, "is_error"].rolling(5, min_periods=1).sum()
        frame.loc[indices, "recent_failed_count"] = failures.to_numpy()

    frame["brute_force_detected"] = False
    failed_login = frame[
        frame["Event name"].eq("ConsoleLogin") & frame["is_error"].eq(1)
    ]
    for _, group in failed_login.groupby(["User name", "Source IP address"], dropna=False):
        recent: deque[tuple[int, pd.Timestamp]] = deque()
        for index, timestamp in zip(group.index, group["Event time"]):
            while recent and (timestamp - recent[0][1]).total_seconds() > 300:
                recent.popleft()
            recent.append((index, timestamp))
            if len(recent) >= 3:
                frame.loc[[item[0] for item in recent], "brute_force_detected"] = True

    features = frame[["hour_of_day", "is_error", "is_readonly", "event_rarity", "recent_failed_count"]]
    if len(frame) >= 10:
        contamination = min(0.05, max(1 / len(frame), 0.01))
        detector = IsolationForest(contamination=contamination, random_state=42)
        frame["anomaly"] = detector.fit_predict(features)
        frame["anomaly_score"] = detector.decision_function(features)
    else:
        frame["anomaly"] = 1
        frame["anomaly_score"] = 0.0
    anomalies = frame[frame["anomaly"].eq(-1) | frame["brute_force_detected"]].sort_values("anomaly_score")
    return frame, anomalies


@st.cache_resource
def load_demo_model():
    return joblib.load(MODEL_PATH)


def analyze_synthetic(data: pd.DataFrame) -> pd.DataFrame:
    required = [
        "hour_of_day",
        "failed_attempts",
        "is_new_country",
        "data_transferred_mb",
        "session_duration_min",
    ]
    missing = [column for column in required if column not in data.columns]
    if missing:
        raise ValueError("Missing columns: " + ", ".join(missing))
    model = load_demo_model()
    features = data[required]
    result = data.copy()
    result["prediction"] = np.where(model.predict(features) == 1, "ATTACK", "Normal")
    result["attack_probability"] = (model.predict_proba(features)[:, 1] * 100).round(1)
    return result.sort_values("attack_probability", ascending=False)


def allowed_actions(document: dict[str, Any]) -> set[str]:
    actions: set[str] = set()
    statements = document.get("Statement", [])
    if isinstance(statements, dict):
        statements = [statements]
    for statement in statements:
        if str(statement.get("Effect", "Allow")).lower() != "allow":
            continue
        value = statement.get("Action", [])
        if isinstance(value, str):
            actions.add(value)
        else:
            actions.update(str(item) for item in value)
    return actions


def managed_policy_actions(iam: Any, arn: str) -> set[str]:
    metadata = iam.get_policy(PolicyArn=arn)["Policy"]
    version = iam.get_policy_version(PolicyArn=arn, VersionId=metadata["DefaultVersionId"])
    return allowed_actions(version["PolicyVersion"]["Document"])


def escalation_matches(actions: Iterable[str]) -> list[str]:
    matches: set[str] = set()
    for action in actions:
        lower = action.lower()
        if lower in {"*", "iam:*"}:
            matches.add(action)
            continue
        for risky in ESCALATION_ACTIONS:
            if lower == risky.lower():
                matches.add(risky)
    return sorted(matches)


def scan_iam(session: Any) -> tuple[pd.DataFrame, list[tuple[str, str]]]:
    iam = client_for(session, "iam", read_timeout=30)
    users = paginate(iam, "list_users", "Users")
    findings: list[dict[str, Any]] = []
    edges: list[tuple[str, str]] = []

    for user in users:
        username = user["UserName"]
        attached = paginate(iam, "list_attached_user_policies", "AttachedPolicies", UserName=username)
        inline_names = paginate(iam, "list_user_policies", "PolicyNames", UserName=username)
        groups = paginate(iam, "list_groups_for_user", "Groups", UserName=username)
        mfa_devices = paginate(iam, "list_mfa_devices", "MFADevices", UserName=username)
        all_attached = list(attached)
        policy_names = [item["PolicyName"] for item in attached]
        all_actions: set[str] = set()

        for item in attached:
            edges.append((username, item["PolicyName"]))
        for name in inline_names:
            edges.append((username, f"inline:{name}"))
            try:
                document = iam.get_user_policy(UserName=username, PolicyName=name)["PolicyDocument"]
                all_actions.update(allowed_actions(document))
            except ClientError:
                pass

        group_names = []
        for group in groups:
            group_name = group["GroupName"]
            group_names.append(group_name)
            edges.append((username, f"group:{group_name}"))
            group_attached = paginate(
                iam, "list_attached_group_policies", "AttachedPolicies", GroupName=group_name
            )
            group_inline = paginate(iam, "list_group_policies", "PolicyNames", GroupName=group_name)
            all_attached.extend(group_attached)
            policy_names.extend(item["PolicyName"] for item in group_attached)
            for item in group_attached:
                edges.append((f"group:{group_name}", item["PolicyName"]))
            for name in group_inline:
                edges.append((f"group:{group_name}", f"inline:{name}"))
                try:
                    document = iam.get_group_policy(GroupName=group_name, PolicyName=name)["PolicyDocument"]
                    all_actions.update(allowed_actions(document))
                except ClientError:
                    pass

        seen_arns = set()
        for item in all_attached:
            arn = item["PolicyArn"]
            if arn in seen_arns:
                continue
            seen_arns.add(arn)
            try:
                all_actions.update(managed_policy_actions(iam, arn))
            except ClientError:
                pass

        risky = sorted(HIGH_RISK_POLICIES.intersection(policy_names))
        escalation = [] if risky else escalation_matches(all_actions)
        trust_score = 100 - (40 if risky else 0) - (30 if not mfa_devices else 0) - (25 if escalation else 0)
        trust_score = max(0, trust_score)
        trust_level = "Trusted" if trust_score >= 70 else ("Caution" if trust_score >= 40 else "Untrusted")
        findings.append(
            {
                "user_name": username,
                "groups": ", ".join(group_names) if group_names else "None",
                "mfa_enabled": "Yes" if mfa_devices else "No",
                "effective_managed_policies": ", ".join(sorted(set(policy_names))) if policy_names else "None",
                "risky_policies": ", ".join(risky) if risky else "None",
                "shadow_admin_heuristic": "Potential path" if escalation else "No",
                "escalation_actions": ", ".join(escalation) if escalation else "None",
                "risk_level": "HIGH" if risky or escalation else "LOW",
                "trust_score": trust_score,
                "trust_level": trust_level,
            }
        )
    columns = [
        "user_name", "groups", "mfa_enabled", "effective_managed_policies",
        "risky_policies", "shadow_admin_heuristic", "escalation_actions",
        "risk_level", "trust_score", "trust_level",
    ]
    return pd.DataFrame(findings, columns=columns), edges


def scan_s3(session: Any) -> pd.DataFrame:
    s3 = client_for(session, "s3", read_timeout=30)
    buckets = s3.list_buckets().get("Buckets", [])
    findings = []
    for bucket in buckets:
        name = bucket["Name"]
        blocked = "Unknown"
        policy_public = "Unknown"
        public_acl = False
        errors = []
        try:
            config = s3.get_public_access_block(Bucket=name)["PublicAccessBlockConfiguration"]
            blocked = "Fully blocked" if all(config.values()) else "Partially open"
        except ClientError as exc:
            code = exc.response.get("Error", {}).get("Code", "")
            if code in {"NoSuchPublicAccessBlockConfiguration", "NoSuchPublicAccessBlock"}:
                blocked = "Not configured"
            else:
                errors.append(f"public-access-block:{code}")
        try:
            policy_public = "YES" if s3.get_bucket_policy_status(Bucket=name)["PolicyStatus"]["IsPublic"] else "No"
        except ClientError as exc:
            code = exc.response.get("Error", {}).get("Code", "")
            if code in {"NoSuchBucketPolicy", "NoSuchPolicy"}:
                policy_public = "No policy"
            else:
                errors.append(f"policy-status:{code}")
        try:
            acl = s3.get_bucket_acl(Bucket=name)
            public_acl = any(
                "AllUsers" in grant.get("Grantee", {}).get("URI", "")
                or "AuthenticatedUsers" in grant.get("Grantee", {}).get("URI", "")
                for grant in acl.get("Grants", [])
            )
        except ClientError as exc:
            errors.append(f"acl:{exc.response.get('Error', {}).get('Code', '')}")

        declared_public = policy_public == "YES" or public_acl
        confirmed_public = declared_public and blocked != "Fully blocked"
        possible = blocked in {"Partially open", "Not configured"}
        if confirmed_public:
            risk = "HIGH"
        elif declared_public and blocked == "Fully blocked":
            risk = "MITIGATED"
            errors.append("public policy/ACL is currently blocked; remove the stale grant after application-owner review")
        elif errors:
            risk = "UNKNOWN"
        elif possible:
            risk = "REVIEW"
        else:
            risk = "LOW"
        findings.append(
            {
                "bucket_name": name,
                "block_public_access": blocked,
                "public_bucket_policy": policy_public,
                "public_acl": "YES" if public_acl else "No",
                "risk_level": risk,
                "notes": ", ".join(errors) if errors else "Complete",
            }
        )
    return pd.DataFrame(findings, columns=S3_RESULT_COLUMNS)


def remediate_s3_public_access(session: Any, bucket_name: str) -> None:
    """Enable every bucket-level S3 Block Public Access control."""
    s3 = client_for(session, "s3", read_timeout=30)
    s3.put_public_access_block(
        Bucket=bucket_name,
        PublicAccessBlockConfiguration={
            "BlockPublicAcls": True,
            "IgnorePublicAcls": True,
            "BlockPublicPolicy": True,
            "RestrictPublicBuckets": True,
        },
    )


def scan_security_groups(session: Any) -> tuple[pd.DataFrame, int]:
    ec2 = client_for(session, "ec2", read_timeout=30)
    groups = paginate(ec2, "describe_security_groups", "SecurityGroups")
    findings = []
    for group in groups:
        label = f"{group.get('GroupName', 'Unnamed')} ({group['GroupId']})"
        for rule in group.get("IpPermissions", []):
            from_port = rule.get("FromPort")
            to_port = rule.get("ToPort")
            public_ranges = [
                item.get("CidrIp") for item in rule.get("IpRanges", []) if item.get("CidrIp") == "0.0.0.0/0"
            ] + [
                item.get("CidrIpv6") for item in rule.get("Ipv6Ranges", []) if item.get("CidrIpv6") == "::/0"
            ]
            for cidr in public_ranges:
                if from_port is None or to_port is None:
                    findings.append(
                        {
                            "security_group": label,
                            "group_id": group["GroupId"],
                            "ip_protocol": str(rule.get("IpProtocol", "-1")),
                            "from_port": None,
                            "to_port": None,
                            "port": "ALL",
                            "service": "ALL",
                            "open_to": cidr,
                            "risk_level": "HIGH",
                        }
                    )
                    continue
                for port, service in DANGEROUS_PORTS.items():
                    if from_port <= port <= to_port:
                        findings.append(
                            {
                                "security_group": label,
                                "group_id": group["GroupId"],
                                "ip_protocol": str(rule.get("IpProtocol", "-1")),
                                "from_port": from_port,
                                "to_port": to_port,
                                "port": port,
                                "service": service,
                                "open_to": cidr,
                                "risk_level": "HIGH",
                            }
                        )
    return pd.DataFrame(findings, columns=SG_RESULT_COLUMNS), len(groups)


def security_group_remediation_candidates(findings: pd.DataFrame) -> pd.DataFrame:
    columns = ["security_group", "group_id", "ip_protocol", "from_port", "to_port", "open_to"]
    if findings.empty or not set(columns).issubset(findings.columns):
        return pd.DataFrame(columns=columns)
    return findings[columns].drop_duplicates().reset_index(drop=True)


def remediate_security_group_ingress(session: Any, finding: dict[str, Any]) -> None:
    """Revoke only the exact public IPv4 or IPv6 source from one ingress rule."""
    cidr = str(finding["open_to"])
    permission: dict[str, Any] = {"IpProtocol": str(finding["ip_protocol"])}
    from_port = finding.get("from_port")
    to_port = finding.get("to_port")
    if pd.notna(from_port) and pd.notna(to_port):
        permission["FromPort"] = int(from_port)
        permission["ToPort"] = int(to_port)
    if cidr == "::/0":
        permission["Ipv6Ranges"] = [{"CidrIpv6": cidr}]
    else:
        permission["IpRanges"] = [{"CidrIp": cidr}]
    ec2 = client_for(session, "ec2", read_timeout=30)
    ec2.revoke_security_group_ingress(GroupId=str(finding["group_id"]), IpPermissions=[permission])


def scan_flow_logs(session: Any, log_group: str) -> pd.DataFrame:
    logs = client_for(session, "logs", read_timeout=30)
    streams = logs.describe_log_streams(
        logGroupName=log_group, orderBy="LastEventTime", descending=True, limit=5
    ).get("logStreams", [])
    parsed = []
    for stream in streams:
        events = logs.get_log_events(
            logGroupName=log_group, logStreamName=stream["logStreamName"], limit=500
        ).get("events", [])
        for event in events:
            parts = event.get("message", "").split()
            if len(parts) < 14:
                continue
            parsed.append(
                {
                    "src_ip": parts[3],
                    "dst_ip": parts[4],
                    "src_port": parts[5],
                    "dst_port": parts[6],
                    "protocol": parts[7],
                    "action": parts[12],
                }
            )
    columns = ["src_ip", "dst_ip", "src_port", "dst_port", "protocol", "action"]
    return pd.DataFrame(parsed, columns=columns)


def load_csv_from_s3(session: Any, bucket: str, object_key: str) -> pd.DataFrame:
    bucket = bucket.strip()
    object_key = object_key.strip()
    if not bucket or not object_key:
        raise ValueError("Both S3 bucket name and object key are required.")
    s3 = client_for(session, "s3", read_timeout=30)
    response = s3.get_object(Bucket=bucket, Key=object_key)
    body = response["Body"]
    try:
        content = body.read(50 * 1024 * 1024 + 1)
    finally:
        body.close()
    if len(content) > 50 * 1024 * 1024:
        raise ValueError("The S3 CSV is larger than the 50 MB safety limit.")
    return pd.read_csv(BytesIO(content))


def scan_zero_trust(
    session: Any,
    brute_force_users: set[str] | None = None,
    shadow_admin_users: set[str] | None = None,
) -> pd.DataFrame:
    iam = client_for(session, "iam", read_timeout=30)
    users = paginate(iam, "list_users", "Users")
    brute_force_users = brute_force_users or set()
    shadow_admin_users = shadow_admin_users or set()
    group_policy_cache: dict[str, set[str]] = {}
    findings = []

    for user in users:
        username = user["UserName"]
        attached = paginate(iam, "list_attached_user_policies", "AttachedPolicies", UserName=username)
        policy_names = {item["PolicyName"] for item in attached}
        groups = paginate(iam, "list_groups_for_user", "Groups", UserName=username)
        for group in groups:
            group_name = group["GroupName"]
            if group_name not in group_policy_cache:
                group_attached = paginate(
                    iam, "list_attached_group_policies", "AttachedPolicies", GroupName=group_name
                )
                group_policy_cache[group_name] = {item["PolicyName"] for item in group_attached}
            policy_names.update(group_policy_cache[group_name])

        mfa_devices = paginate(iam, "list_mfa_devices", "MFADevices", UserName=username)
        has_risky_policy = bool(HIGH_RISK_POLICIES.intersection(policy_names))
        no_mfa = not bool(mfa_devices)
        brute_force = username in brute_force_users
        shadow_admin = username in shadow_admin_users

        score = 100
        reasons = []
        if has_risky_policy:
            score -= 40
            reasons.append("High-risk policy")
        if no_mfa:
            score -= 30
            reasons.append("MFA not enabled")
        if brute_force:
            score -= 20
            reasons.append("Recent brute-force involvement")
        if shadow_admin:
            score -= 25
            reasons.append("Potential shadow-admin path")
        score = max(0, score)
        trust_level = "Trusted" if score >= 70 else ("Caution" if score >= 40 else "Untrusted")
        findings.append(
            {
                "user_name": username,
                "high_risk_policy": "Yes" if has_risky_policy else "No",
                "mfa_enabled": "No" if no_mfa else "Yes",
                "recent_bruteforce_activity": "Yes" if brute_force else "No",
                "shadow_admin_indicator": "Yes" if shadow_admin else "No",
                "trust_score": score,
                "trust_level": trust_level,
                "reasons": ", ".join(reasons) if reasons else "No issues found",
            }
        )
    return pd.DataFrame(findings, columns=ZERO_TRUST_COLUMNS)


def create_iam_graph(results: pd.DataFrame, edges: list[tuple[str, str]]) -> plt.Figure:
    graph = nx.Graph()
    graph.add_edges_from(edges)
    users = set(results["user_name"]) if not results.empty and "user_name" in results else set()
    graph.add_nodes_from(users)
    colors = []
    sizes = []
    for node in graph.nodes:
        if node in HIGH_RISK_POLICIES:
            colors.append("#ef5b67")
            sizes.append(1900)
        elif str(node).startswith("group:"):
            colors.append("#f2b84b")
            sizes.append(1500)
        elif str(node).startswith("inline:"):
            colors.append("#a37cf0")
            sizes.append(1400)
        elif node in users:
            colors.append("#3d9df2")
            sizes.append(1800)
        else:
            colors.append("#66d19e")
            sizes.append(1500)

    fig, ax = plt.subplots(figsize=(15, 9), facecolor="#081120")
    ax.set_facecolor("#081120")
    if graph.number_of_nodes():
        node_count = graph.number_of_nodes()
        positions = nx.spring_layout(
            graph,
            seed=42,
            k=max(0.65, 3.2 / max(node_count ** 0.5, 1)),
            iterations=250,
        )
        nx.draw_networkx_edges(graph, positions, ax=ax, edge_color="#58708b", width=1.1, alpha=0.72)
        nx.draw_networkx_nodes(
            graph,
            positions,
            ax=ax,
            node_color=colors,
            node_size=sizes,
            edgecolors="#d8e7f7",
            linewidths=0.6,
        )
        nx.draw_networkx_labels(
            graph,
            positions,
            ax=ax,
            font_size=8,
            font_weight="bold",
            font_color="white",
        )
    ax.set_title("IAM User, Group and Policy Relationship Graph", color="white", fontsize=17, pad=18)
    ax.axis("off")
    fig.tight_layout()
    return fig


def graph_png_bytes(fig: plt.Figure) -> bytes:
    buffer = BytesIO()
    fig.savefig(buffer, format="png", dpi=180, bbox_inches="tight", facecolor=fig.get_facecolor())
    return buffer.getvalue()


def generate_gemini_text(api_key: str, prompt: str) -> str:
    value = api_key.strip()
    if not value:
        raise ValueError("Enter a Gemini API key or save one first.")
    from google import genai

    client = genai.Client(api_key=value)
    response = client.models.generate_content(model="gemini-3.5-flash", contents=prompt)
    text = (response.text or "").strip()
    if not text:
        raise RuntimeError("Gemini returned an empty response.")
    return text


def risk_summary() -> dict[str, int]:
    alerts = state_frame("cloudtrail_alerts")
    anomalies = len(alerts) if alerts is not None else 0
    cloud = state_frame("cloudtrail_data", RESULT_SCHEMAS["cloudtrail_data"])
    brute_force = int(cloud["brute_force_detected"].fillna(False).astype(bool).sum()) if cloud is not None else 0
    iam = state_frame("iam_results", RESULT_SCHEMAS["iam_results"])
    iam_high = count_value(iam, "risk_level", "HIGH")
    s3 = state_frame("s3_results", RESULT_SCHEMAS["s3_results"])
    s3_high = count_value(s3, "risk_level", "HIGH")
    sg = state_frame("sg_results", RESULT_SCHEMAS["sg_results"])
    sg_high = len(sg) if sg is not None else 0
    zt = state_frame("zt_results", RESULT_SCHEMAS["zt_results"])
    untrusted = count_value(zt, "trust_level", "Untrusted")
    no_mfa = count_value(zt, "mfa_enabled", "No")
    remediation_history = st.session_state.get("remediation_history", [])
    if not isinstance(remediation_history, list):
        remediation_history = []
    remediations = sum(
        1 for item in remediation_history if isinstance(item, dict) and item.get("Status") == "SUCCESS"
    )
    score = min(
        100,
        anomalies * 3
        + brute_force * 12
        + iam_high * 18
        + s3_high * 18
        + sg_high * 8
        + untrusted * 12
        + no_mfa * 3,
    )
    return {
        "score": score,
        "alerts": anomalies,
        "brute_force": brute_force,
        "iam": iam_high,
        "s3": s3_high,
        "network": sg_high,
        "untrusted": untrusted,
        "no_mfa": no_mfa,
        "remediations": remediations,
    }


def build_report() -> str:
    summary = risk_summary()
    lines = [
        "RC - AI POWERED CLOUD SECURITY PLATFORM",
        "AWS SECURITY ASSESSMENT",
        "=" * 55,
        f"Generated: {now_text()}",
        f"AWS account: {st.session_state.get('aws_identity', {}).get('account', 'Not confirmed')}",
        f"Region: {st.session_state.selected_region}",
        f"Overall heuristic risk score: {summary['score']}/100",
        "",
        "SUMMARY",
        f"- CloudTrail alerts: {summary['alerts']}",
        f"- Brute-force events: {summary['brute_force']}",
        f"- High-risk IAM users: {summary['iam']}",
        f"- Confirmed public S3 buckets: {summary['s3']}",
        f"- Dangerous public network rules: {summary['network']}",
        f"- Untrusted identities: {summary['untrusted']}",
        f"- IAM users without MFA: {summary['no_mfa']}",
        f"- Successful in-tool remediations: {summary['remediations']}",
        "",
        "1. THREAT DETECTION",
    ]

    cloud = state_frame("cloudtrail_data", RESULT_SCHEMAS["cloudtrail_data"])
    if cloud is not None:
        alerts = state_frame("cloudtrail_alerts")
        if alerts is None:
            alerts = pd.DataFrame()
        lines.extend(
            [
                f"Events analyzed: {len(cloud)}",
                f"Flagged unusual/brute-force events: {len(alerts)}",
                f"Brute-force events: {summary['brute_force']}",
            ]
        )
        if not alerts.empty:
            lines.append("Top flagged events:")
            for _, row in alerts.head(10).iterrows():
                lines.append(
                    f"  - {row.get('Event time')} | {row.get('User name')} | "
                    f"{row.get('Event name')} | {row.get('Source IP address')}"
                )
    else:
        lines.append("Not run in this session.")

    lines.extend(["", "2. IAM SECURITY AUDIT"])
    iam = state_frame("iam_results", RESULT_SCHEMAS["iam_results"])
    if iam is not None:
        high = iam[iam["risk_level"].eq("HIGH")]
        shadow = iam[iam["shadow_admin_heuristic"].ne("No")]
        lines.extend(
            [
                f"IAM users scanned: {len(iam)}",
                f"High-risk users: {len(high)}",
                f"Shadow-admin indicators: {len(shadow)}",
            ]
        )
        for _, row in high.head(15).iterrows():
            lines.append(
                f"  - {row['user_name']}: risky={row['risky_policies']}; "
                f"escalation={row['escalation_actions']}; MFA={row['mfa_enabled']}"
            )
    else:
        lines.append("Not run in this session.")

    lines.extend(["", "3. IAM RELATIONSHIP GRAPH"])
    if "iam_edges" in st.session_state:
        lines.append(f"Relationships mapped: {len(st.session_state.iam_edges)}")
    else:
        lines.append("Not generated in this session.")

    lines.extend(["", "4. S3 EXPOSURE"])
    s3 = state_frame("s3_results", RESULT_SCHEMAS["s3_results"])
    if s3 is not None:
        lines.append(f"Buckets scanned: {len(s3)}")
        noteworthy = s3[s3["risk_level"].isin(["HIGH", "REVIEW", "UNKNOWN"])]
        for _, row in noteworthy.head(20).iterrows():
            lines.append(f"  - {row['bucket_name']}: {row['risk_level']} ({row['notes']})")
    else:
        lines.append("Not run in this session.")

    lines.extend(["", "5. SECURITY GROUPS"])
    sg = state_frame("sg_results", RESULT_SCHEMAS["sg_results"])
    if sg is not None:
        lines.extend(
            [
                f"Security groups checked: {st.session_state.get('sg_total', 0)}",
                f"Dangerous public rules: {len(sg)}",
            ]
        )
        for _, row in sg.head(20).iterrows():
            lines.append(f"  - {row['security_group']}: {row['service']} / {row['port']} open to {row['open_to']}")
    else:
        lines.append("Not run in this session.")

    lines.extend(["", "6. VPC FLOW LOGS"])
    flow = state_frame("flow_results", RESULT_SCHEMAS["flow_results"])
    if flow is not None:
        rejected = flow[flow["action"].eq("REJECT")]
        suspects = rejected["src_ip"].value_counts() if not rejected.empty else pd.Series(dtype=int)
        lines.extend(
            [
                f"Flow entries analyzed: {len(flow)}",
                f"Rejected connections: {len(rejected)}",
                f"Possible scanners (5+ rejects): {int((suspects >= 5).sum())}",
            ]
        )
    else:
        lines.append("Not run in this session.")

    lines.extend(["", "7. ZERO TRUST IDENTITY VERIFICATION"])
    zt = state_frame("zt_results", RESULT_SCHEMAS["zt_results"])
    if zt is not None:
        average = round(float(zt["trust_score"].mean()), 1) if not zt.empty else 0
        lines.extend([f"Identities verified: {len(zt)}", f"Average trust score: {average}/100"])
        for _, row in zt[zt["trust_level"].ne("Trusted")].head(20).iterrows():
            lines.append(f"  - {row['user_name']}: {row['trust_level']} {row['trust_score']}/100 ({row['reasons']})")
    else:
        lines.append("Not run in this session.")

    lines.extend(["", "8. REMEDIATION HISTORY"])
    remediation_history = st.session_state.get("remediation_history", [])
    if not isinstance(remediation_history, list):
        remediation_history = []
    if remediation_history:
        for item in remediation_history[-25:]:
            if not isinstance(item, dict):
                continue
            lines.append(
                f"- {item.get('Time')} | {item.get('Status')} | {item.get('Service')} | "
                f"{item.get('Resource')} | {item.get('Action')} | {item.get('Details')}"
            )
    else:
        lines.append("No cloud changes were made from the tool in this session.")

    lines.extend(["", "SCAN HISTORY"])
    scan_times = st.session_state.get("scan_times", {})
    if scan_times:
        for name, timestamp in scan_times.items():
            lines.append(f"- {name}: {timestamp}")
    else:
        lines.append("- No live scans have been run in this session.")
    lines.extend(
        [
            "",
            "IMPORTANT",
            "This is a read-only assessment aid. Findings require analyst review.",
            "The risk score is a prioritization heuristic, not a compliance certification.",
        ]
    )
    return "\n".join(lines)


apply_design()

settings = load_settings()
if "selected_profile" not in st.session_state:
    st.session_state.selected_profile = settings.get("profile", "")
if "selected_region" not in st.session_state:
    st.session_state.selected_region = settings.get("region", DEFAULT_REGION)
if "connection_mode" not in st.session_state:
    st.session_state.connection_mode = settings.get("connection_mode", "Access keys inside app")
if "credential_label" not in st.session_state:
    st.session_state.credential_label = settings.get("credential_label", "rc-cloudsec")

discarded_result_state = discard_incompatible_result_state()

with st.sidebar:
    st.markdown(
        '<div class="brand-lockup"><div class="rc-logo">RC</div><div><strong>AI Powered</strong><br><span class="small-note">Cloud Security Platform</span></div></div>',
        unsafe_allow_html=True,
    )
    st.caption("Complete Desktop v1.3.1 • Scan, investigate, remediate")
    st.divider()
    if "aws_identity" in st.session_state:
        identity = st.session_state.aws_identity
        st.markdown('<span class="status-ok">● AWS CONNECTED</span>', unsafe_allow_html=True)
        st.caption(f"Account {identity['account']}")
        st.caption(identity["arn"])
        st.caption(f"Region {identity['region']}")
    else:
        st.markdown('<span class="status-off">● AWS NOT CONNECTED</span>', unsafe_allow_html=True)
        st.caption("Open the AWS tab to connect.")
    st.divider()
    st.markdown("**Connection method**")
    st.caption(st.session_state.connection_mode)
    st.markdown("**Region**")
    st.caption(st.session_state.selected_region)
    st.divider()
    st.caption("Read-only scans • Optional Windows Credential Manager storage • No cloud database")
    if discarded_result_state:
        st.warning("An incomplete result from the previous build was cleared. Rerun the affected scan.")

connected = "aws_identity" in st.session_state
badge = '<span class="status-ok">AWS connected</span>' if connected else '<span class="status-off">AWS setup required</span>'
st.markdown(
    f"""
    <div class="hero">
      <div class="brand-lockup"><div class="rc-logo">RC</div><div class="hero-title">AI Powered Cloud Security Platform</div></div>
      <div class="hero-sub">Detect AWS threats, map IAM exposure, investigate evidence, and apply selected guarded remediations from one desktop workspace. &nbsp; {badge}</div>
    </div>
    """,
    unsafe_allow_html=True,
)

connection_tab, overview_tab, trail_tab, sg_tab, vpc_tab, storage_tab, iam_tab, graph_tab, zt_tab, report_tab = st.tabs(
    ["AWS", "Overview", "Threats", "SG", "VPC", "S3", "IAM", "Graph", "Zero Trust", "Report"]
)

with connection_tab:
    st.markdown("### Connect RC AI Cloud Security to AWS")
    st.write("Enter a dedicated read-only AWS identity here. The secret field supports **Ctrl+V** and right-click paste.")
    method_options = ["Access keys inside app", "Existing AWS profile / SSO"]
    current_method = st.session_state.connection_mode
    if current_method not in method_options:
        current_method = method_options[0]
    method = st.radio(
        "Connection method",
        method_options,
        index=method_options.index(current_method),
        horizontal=True,
        help="Access keys can be kept only for this app session or saved in Windows Credential Manager.",
    )
    if method != st.session_state.connection_mode:
        st.session_state.pop("aws_identity", None)
    st.session_state.connection_mode = method

    if method == "Access keys inside app":
        saved_available = False
        try:
            saved_available = load_credentials(st.session_state.credential_label) is not None
        except Exception:
            saved_available = False

        with st.container(border=True):
            with st.form("direct_aws_connection"):
                left, right = st.columns(2)
                with left:
                    label = st.text_input(
                        "Credential name",
                        value=st.session_state.credential_label,
                        help="This is only a local label, for example rc-cloudsec. It is not your AWS account name.",
                    )
                    access_key = st.text_input(
                        "AWS Access Key ID",
                        placeholder="AKIA...",
                        help="Use a dedicated read-only IAM user. Never use the AWS root user.",
                    )
                    region = st.text_input("AWS Region", value=st.session_state.selected_region, placeholder=DEFAULT_REGION)
                with right:
                    secret_key = st.text_input(
                        "AWS Secret Access Key",
                        type="password",
                        placeholder="Paste with Ctrl+V",
                    )
                    session_token = st.text_input(
                        "AWS Session Token — optional",
                        type="password",
                        help="Required only when AWS supplied temporary three-part credentials.",
                    )
                    remember = st.checkbox(
                        "Remember securely on this computer",
                        value=True,
                        help="Saved only after AWS validates the credentials. Windows stores it in Credential Manager.",
                    )
                if saved_available:
                    st.info("A saved credential exists for this name. Leave the key fields empty and click Connect to use it.")
                connect_direct = st.form_submit_button("Connect to AWS", type="primary", use_container_width=True)

            if connect_direct:
                credentials = None
                try:
                    clean_label = validate_label(label)
                    clean_region = region.strip() or DEFAULT_REGION
                    if access_key.strip() or secret_key.strip() or session_token.strip():
                        credentials = validate_credential_set(access_key, secret_key, session_token)
                    else:
                        credentials = load_credentials(clean_label)
                        if not credentials:
                            raise ValueError("Enter the access key and secret key, or use a credential name already saved on this computer.")
                        credentials = validate_credential_set(
                            credentials["access_key"],
                            credentials["secret_key"],
                            credentials.get("session_token", ""),
                        )

                    with st.spinner("Validating credentials with AWS..."):
                        session = create_access_key_session(
                            credentials["access_key"],
                            credentials["secret_key"],
                            credentials.get("session_token", ""),
                            clean_region,
                        )
                        identity = test_connection(session)
                    if remember:
                        save_credentials(clean_label, credentials)
                    st.session_state.runtime_aws_credentials = credentials
                    st.session_state.aws_identity = identity
                    st.session_state.credential_label = clean_label
                    st.session_state.selected_region = clean_region
                    st.session_state.selected_profile = ""
                    st.session_state.connection_mode = method
                    save_settings("", clean_region, method, clean_label)
                    st.toast(f"Connected to AWS account {identity['account']}", icon="✅")
                    st.rerun()
                except Exception as exc:
                    st.session_state.pop("aws_identity", None)
                    if credentials:
                        st.session_state.credential_error_prefix = credentials.get("access_key", "")[:4]
                    show_error(exc)

        with st.expander("AKIA or ASIA? AWS credential help", expanded=False):
            credential_help = pd.DataFrame(
                [
                    {
                        "Access Key prefix": "AKIA",
                        "Credential type": "Long-term IAM-user key",
                        "Required fields": "Access Key + Secret Key",
                        "Session Token": "Leave empty",
                    },
                    {
                        "Access Key prefix": "ASIA",
                        "Credential type": "Temporary STS / role / SSO key",
                        "Required fields": "Access Key + Secret Key + Session Token",
                        "Session Token": "Required; expires with the session",
                    },
                ]
            )
            st.dataframe(credential_help, hide_index=True, use_container_width=True)
            st.info("If AWS reports InvalidClientTokenId, delete the saved credential and reconnect with one complete matching set.")

        action_one, action_two = st.columns(2)
        if action_one.button("Disconnect this session", use_container_width=True):
            st.session_state.pop("aws_identity", None)
            st.session_state.pop("runtime_aws_credentials", None)
            st.rerun()
        if action_two.button("Delete saved credential", use_container_width=True):
            try:
                target = st.session_state.get("credential_label", "rc-cloudsec")
                removed = delete_credentials(target)
                st.session_state.pop("runtime_aws_credentials", None)
                st.session_state.pop("aws_identity", None)
                st.toast("Saved credential deleted" if removed else "No saved credential was found", icon="🗑️")
                st.rerun()
            except Exception as exc:
                show_error(exc)

    else:
        profiles = available_profiles()
        options = [DEFAULT_PROFILE_LABEL] + profiles
        saved_label = st.session_state.selected_profile or DEFAULT_PROFILE_LABEL
        if saved_label not in options:
            options.append(saved_label)
        with st.container(border=True):
            with st.form("profile_aws_connection"):
                profile_label = st.selectbox("AWS profile / SSO profile", options, index=options.index(saved_label))
                profile_region = st.text_input("AWS Region", value=st.session_state.selected_region)
                connect_profile = st.form_submit_button("Connect to AWS", type="primary", use_container_width=True)
            if connect_profile:
                try:
                    profile_value = "" if profile_label == DEFAULT_PROFILE_LABEL else profile_label
                    clean_region = profile_region.strip() or DEFAULT_REGION
                    session = create_session(profile_value, clean_region)
                    with st.spinner("Validating AWS profile..."):
                        identity = test_connection(session)
                    st.session_state.selected_profile = profile_value
                    st.session_state.selected_region = clean_region
                    st.session_state.connection_mode = method
                    st.session_state.aws_identity = identity
                    st.session_state.pop("runtime_aws_credentials", None)
                    save_settings(profile_value, clean_region, method, st.session_state.credential_label)
                    st.toast(f"Connected to AWS account {identity['account']}", icon="✅")
                    st.rerun()
                except Exception as exc:
                    st.session_state.pop("aws_identity", None)
                    show_error(exc)

    if "aws_identity" in st.session_state:
        identity = st.session_state.aws_identity
        st.success(f"Connected to AWS account {identity['account']} in {identity['region']}")
        st.code(identity["arn"])
    st.warning("Never enter your AWS website password, root credentials, or account ID here. This form requires an IAM/temporary Access Key ID and Secret Access Key.")
    with st.expander("Optional guarded remediation permissions", expanded=False):
        st.write(
            "Scanning remains read-only. To use the one-button fixes, an AWS administrator must separately attach "
            "the included narrow remediation policy. It permits only S3 bucket Block Public Access updates and "
            "removal of selected Security Group ingress rules."
        )
        st.download_button(
            "Download optional remediation IAM policy",
            data=REMEDIATION_POLICY_PATH.read_bytes(),
            file_name="RCCloudSecRemediationPolicy.json",
            mime="application/json",
        )
        st.warning("Do not attach the remediation policy if this identity should remain strictly read-only.")

with overview_tab:
    summary = risk_summary()
    st.markdown("### Unified cloud security overview")
    cols = st.columns(7)
    cols[0].metric("Risk score", f"{summary['score']}/100")
    cols[1].metric("CloudTrail alerts", summary["alerts"])
    cols[2].metric("IAM high risk", summary["iam"])
    cols[3].metric("Public S3", summary["s3"])
    cols[4].metric("Open network rules", summary["network"])
    cols[5].metric("Untrusted identities", summary["untrusted"])
    cols[6].metric("Fixes applied", summary["remediations"])
    st.markdown("### Quick start")
    one, two, three = st.columns(3)
    with one:
        with st.container(border=True):
            st.markdown("#### 1. Connect")
            st.write("Open **AWS**, paste the read-only access key and secret key, select the Region, then connect.")
    with two:
        with st.container(border=True):
            st.markdown("#### 2. Scan")
            st.write("Run the read-only scan buttons in each module. No AWS configuration is modified.")
    with three:
        with st.container(border=True):
            st.markdown("#### 3. Report")
            st.write("Review the evidence and download a session report from the Report tab.")
    st.markdown("### Latest activity")
    scan_times = st.session_state.get("scan_times", {})
    if scan_times:
        activity = pd.DataFrame(
            [
                {
                    "Module": name,
                    "Last scan": time,
                    "Items": st.session_state.get("scan_counts", {}).get(name, 0),
                }
                for name, time in scan_times.items()
            ]
        )
        st.dataframe(activity, hide_index=True, use_container_width=True)
    else:
        st.info("No scans have been run in this session yet.")
    st.markdown("### Module status")
    module_status = pd.DataFrame(
        [
            {"Module": "Live CloudTrail", "Ready": "Yes" if state_frame("cloudtrail_data", RESULT_SCHEMAS["cloudtrail_data"]) is not None else "Not scanned"},
            {"Module": "Synthetic ML model", "Ready": "Included" if MODEL_PATH.exists() else "Missing model"},
            {"Module": "IAM audit", "Ready": "Yes" if state_frame("iam_results", RESULT_SCHEMAS["iam_results"]) is not None else "Not scanned"},
            {"Module": "IAM graph", "Ready": "Yes" if "iam_edges" in st.session_state else "Not generated"},
            {"Module": "S3 exposure", "Ready": "Yes" if state_frame("s3_results", RESULT_SCHEMAS["s3_results"]) is not None else "Not scanned"},
            {"Module": "Security Groups", "Ready": "Yes" if state_frame("sg_results", RESULT_SCHEMAS["sg_results"]) is not None else "Not scanned"},
            {"Module": "VPC Flow Logs", "Ready": "Yes" if state_frame("flow_results", RESULT_SCHEMAS["flow_results"]) is not None else "Not analyzed"},
            {"Module": "Zero Trust", "Ready": "Yes" if state_frame("zt_results", RESULT_SCHEMAS["zt_results"]) is not None else "Not verified"},
        ]
    )
    st.dataframe(module_status, hide_index=True, use_container_width=True)
    st.caption("Risk score is a prioritization heuristic. It is not a guarantee of compromise or a compliance result.")

with trail_tab:
    st.markdown("### Threat detection — real AWS and ML demonstration")
    st.write("Live CloudTrail uses real AWS activity with Isolation Forest and brute-force rules. Synthetic CSV uses your trained Random Forest model.")
    source = st.radio(
        "Data source",
        ["Live AWS CloudTrail", "Upload CSV (auto-detect)", "Import CSV from S3", "Included synthetic sample"],
        horizontal=True,
    )
    source_data = None
    if source == "Live AWS CloudTrail":
        auto = st.checkbox("Auto-refresh every 10 minutes while this page stays open")
        if auto:
            st_autorefresh(interval=600_000, key="cloudtrail_refresh")
        run = st.button("Run CloudTrail scan", type="primary") or auto
        if run:
            try:
                with st.spinner("Reading up to 1,000 recent CloudTrail events..."):
                    raw = scan_cloudtrail(get_scan_session())
                    analyzed, alerts = analyze_cloudtrail(raw)
                    known_users = set(st.session_state.iam_results["user_name"]) if "iam_results" in st.session_state else set()
                    if not alerts.empty:
                        alerts = alerts.copy()
                        alerts["threat_type"] = alerts["User name"].apply(
                            lambda name: "Insider Threat Indicator" if name in known_users else "Anomaly / External or Unclassified"
                        )
                    st.session_state.cloudtrail_data = analyzed
                    st.session_state.cloudtrail_alerts = alerts
                    st.session_state.last_bruteforce_users = set(
                        analyzed.loc[analyzed["brute_force_detected"], "User name"].dropna().astype(str)
                    )
                    remember_scan("CloudTrail", len(raw))
                st.success(f"Analyzed {len(raw)} events.")
            except Exception as exc:
                show_error(exc)
    elif source == "Upload CSV (auto-detect)":
        uploaded = st.file_uploader("CloudTrail export or synthetic login CSV", type=["csv"])
        if uploaded is not None:
            try:
                source_data = pd.read_csv(uploaded)
            except Exception as exc:
                st.error(f"Could not read the CSV: {exc}")
    elif source == "Import CSV from S3":
        with st.container(border=True):
            bucket_col, key_col = st.columns(2)
            bucket = bucket_col.text_input("S3 bucket", value="rafi-cloudsecurity-2026")
            object_key = key_col.text_input("Object key", value="login_events.csv")
            if st.button("Load CSV from S3", type="primary"):
                try:
                    with st.spinner("Downloading the CSV through the connected AWS identity..."):
                        st.session_state.s3_dataset = load_csv_from_s3(get_scan_session(), bucket, object_key)
                    st.success(f"Loaded {len(st.session_state.s3_dataset)} rows from S3.")
                    remember_scan("S3 Dataset Import", len(st.session_state.s3_dataset))
                except Exception as exc:
                    show_error(exc)
        source_data = st.session_state.get("s3_dataset")
    elif SAMPLE_CSV.exists():
        source_data = pd.read_csv(SAMPLE_CSV)

    if source_data is not None:
        synthetic_columns = {
            "hour_of_day",
            "failed_attempts",
            "is_new_country",
            "data_transferred_mb",
            "session_duration_min",
        }
        cloudtrail_columns = {
            "Event time", "Event name", "User name", "Event source",
            "Source IP address", "Error code", "Read-only",
        }
        try:
            if synthetic_columns.issubset(source_data.columns):
                result = analyze_synthetic(source_data)
                st.session_state.synthetic_results = result
                attack_count = int(result["prediction"].eq("ATTACK").sum())
                normal_count = len(result) - attack_count
                st.info("Detected synthetic login schema — using the trained Random Forest model.")
                x, y, z = st.columns(3)
                x.metric("Rows", len(result))
                y.metric("Normal", normal_count)
                z.metric("Flagged attacks", attack_count)
                st.bar_chart(pd.Series({"Normal": normal_count, "Flagged attack": attack_count}))
                st.markdown("#### Highest model scores")
                st.dataframe(result.head(100), hide_index=True, use_container_width=True)
                st.download_button(
                    "Download synthetic detection results CSV",
                    data=result.to_csv(index=False).encode("utf-8"),
                    file_name=f"synthetic_detection_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv",
                )
                st.warning("The Random Forest was trained on synthetic patterns. Its percentage is a demonstration score, not real-world attack certainty.")
            elif cloudtrail_columns.issubset(source_data.columns):
                analyzed, alerts = analyze_cloudtrail(source_data)
                known_users = set(st.session_state.iam_results["user_name"]) if "iam_results" in st.session_state else set()
                if not alerts.empty:
                    alerts = alerts.copy()
                    alerts["threat_type"] = alerts["User name"].apply(
                        lambda name: "Insider Threat Indicator" if name in known_users else "Anomaly / External or Unclassified"
                    )
                st.session_state.cloudtrail_data = analyzed
                st.session_state.cloudtrail_alerts = alerts
                st.session_state.last_bruteforce_users = set(
                    analyzed.loc[analyzed["brute_force_detected"], "User name"].dropna().astype(str)
                )
                remember_scan("Uploaded CloudTrail", len(analyzed))
                st.info("Detected real CloudTrail schema — using anomaly and brute-force detection.")
            else:
                st.error("CSV schema not recognized. Use either the five synthetic feature columns or the CloudTrail export columns.")
        except Exception as exc:
            st.error(f"Could not analyze the CSV: {exc}")

    analyzed = state_frame("cloudtrail_data", RESULT_SCHEMAS["cloudtrail_data"])
    if analyzed is not None:
        alerts = state_frame("cloudtrail_alerts", RESULT_SCHEMAS["cloudtrail_alerts"])
        if alerts is None:
            alerts = analyzed.iloc[0:0].copy()
        brute_count = int(analyzed["brute_force_detected"].sum()) if not analyzed.empty else 0
        a, b, c = st.columns(3)
        a.metric("Real events analyzed", len(analyzed))
        b.metric("Flagged unusual", len(alerts))
        c.metric("Brute-force events", brute_count)
        categories = pd.Series(
            {
                "Normal": max(0, len(analyzed) - len(alerts)),
                "Unusual / ML": len(alerts),
                "Brute force": brute_count,
            }
        )
        st.bar_chart(categories)
        st.markdown("#### Highest-priority real events")
        if alerts.empty:
            st.success("No event crossed the current anomaly or brute-force rules.")
        else:
            display_columns = [
                "Event time", "User name", "Event name", "Event source", "Source IP address",
                "Error code", "brute_force_detected", "anomaly_score",
            ]
            if "threat_type" in alerts.columns:
                display_columns.append("threat_type")
            st.dataframe(alerts[display_columns].head(50), hide_index=True, use_container_width=True)
        download_col, _ = st.columns([1, 3])
        download_col.download_button(
            "Download analyzed CloudTrail CSV",
            data=analyzed.to_csv(index=False).encode("utf-8"),
            file_name=f"cloudtrail_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv",
            use_container_width=True,
        )
        with st.expander("All analyzed real events"):
            st.dataframe(analyzed, hide_index=True, use_container_width=True)

with iam_tab:
    st.markdown("### IAM security audit, CIEM and AI explanations")
    st.write("Reviews users, direct and group-managed policies, MFA, over-privilege, and common shadow-admin escalation paths.")
    if st.button("Run IAM audit", type="primary"):
        try:
            with st.spinner("Reviewing IAM users and policy documents..."):
                results, edges = scan_iam(get_scan_session())
                st.session_state.iam_results = results
                st.session_state.iam_edges = edges
                st.session_state.pop("iam_ai_explanations", None)
                remember_scan("IAM", len(results))
            st.success(f"Audited {len(results)} IAM users.")
        except Exception as exc:
            show_error(exc)
    if "iam_results" in st.session_state:
        results = st.session_state.iam_results
        high = int(results["risk_level"].eq("HIGH").sum()) if not results.empty else 0
        no_mfa = int(results["mfa_enabled"].eq("No").sum()) if not results.empty else 0
        avg_trust = round(float(results["trust_score"].mean()), 1) if not results.empty else 0
        x, y, z, q = st.columns(4)
        x.metric("IAM users", len(results))
        y.metric("High-risk review", high)
        z.metric("Without MFA", no_mfa)
        q.metric("Average trust", f"{avg_trust}/100")
        st.dataframe(results, hide_index=True, use_container_width=True)
        st.download_button(
            "Download IAM audit CSV",
            data=results.to_csv(index=False).encode("utf-8"),
            file_name=f"iam_audit_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv",
        )

        shadow_admins = results[results["shadow_admin_heuristic"].ne("No")] if not results.empty else results
        st.markdown("#### Shadow-admin detection")
        if shadow_admins.empty:
            st.success("No potential privilege-escalation action was found in the reviewed policy documents.")
        else:
            st.warning(f"{len(shadow_admins)} user(s) have a possible indirect privilege-escalation path.")
            st.dataframe(
                shadow_admins[["user_name", "groups", "escalation_actions", "mfa_enabled"]],
                hide_index=True,
                use_container_width=True,
            )

        with st.expander("Gemini risk explanations (optional)", expanded=False):
            st.write("Generate beginner-friendly explanations from the IAM findings. This sends only the displayed IAM findings to Google Gemini.")
            gemini_key = st.text_input("Gemini API key", type="password", placeholder="Paste API key or leave empty to use the saved key", key="iam_gemini_key")
            remember_gemini = st.checkbox("Remember Gemini key in Windows Credential Manager", value=True, key="iam_remember_gemini")
            ai_one, ai_two = st.columns(2)
            if ai_one.button("Generate IAM explanations", type="primary", use_container_width=True):
                try:
                    api_key = gemini_key.strip() or load_gemini_key()
                    if not api_key:
                        raise ValueError("Paste a Gemini API key first.")
                    prompt = f"""You are a cloud security analyst. Explain the important risks in these AWS IAM audit findings.
Write one short section per risky user, using plain English for a cybersecurity student. Mention over-privilege,
MFA, and shadow-admin paths when present, and give a practical least-privilege fix. Do not invent facts.

IAM FINDINGS CSV:
{results.to_csv(index=False)[:30000]}
"""
                    with st.spinner("Gemini is reviewing the IAM findings..."):
                        explanation = generate_gemini_text(api_key, prompt)
                    if remember_gemini:
                        save_gemini_key(api_key)
                    st.session_state.iam_ai_explanations = explanation
                    st.success("AI explanations generated.")
                except Exception as exc:
                    st.error(f"Gemini explanation failed: {exc}")
            if ai_two.button("Delete saved Gemini key", use_container_width=True):
                try:
                    removed = delete_gemini_key()
                    st.toast("Saved Gemini key deleted" if removed else "No saved Gemini key found", icon="🗑️")
                except Exception as exc:
                    st.error(str(exc))
            if "iam_ai_explanations" in st.session_state:
                st.markdown(st.session_state.iam_ai_explanations)
        st.caption("Shadow-admin detection is a heuristic. Conditions, permission boundaries, SCPs, and explicit denies can change effective access.")

with graph_tab:
    st.markdown("### IAM relationship graph")
    st.write("A dedicated visual map of IAM users, groups, inline policies, and managed policies. This restores the graph as a full module rather than hiding it inside the audit table.")
    if st.button("Build / refresh IAM graph", type="primary"):
        try:
            with st.spinner("Reading IAM relationships and laying out the graph..."):
                graph_results, graph_edges = scan_iam(get_scan_session())
                st.session_state.iam_results = graph_results
                st.session_state.iam_edges = graph_edges
                st.session_state.pop("iam_ai_explanations", None)
                remember_scan("IAM Graph", len(graph_edges))
            st.success(f"Mapped {len(graph_edges)} IAM relationships.")
        except Exception as exc:
            show_error(exc)

    if "iam_results" in st.session_state and "iam_edges" in st.session_state:
        legend = st.columns(5)
        legend[0].markdown("🔵 **User**")
        legend[1].markdown("🟠 **Group**")
        legend[2].markdown("🟣 **Inline policy**")
        legend[3].markdown("🟢 **Managed policy**")
        legend[4].markdown("🔴 **High-risk policy**")
        figure = create_iam_graph(st.session_state.iam_results, st.session_state.iam_edges)
        png = graph_png_bytes(figure)
        st.pyplot(figure, use_container_width=True)
        plt.close(figure)
        graph_col, table_col = st.columns([1, 2])
        graph_col.download_button(
            "Download graph PNG",
            data=png,
            file_name=f"iam_relationship_graph_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png",
            mime="image/png",
            use_container_width=True,
        )
        with table_col.expander("Relationship edge list"):
            edge_table = pd.DataFrame(st.session_state.iam_edges, columns=["From", "To"])
            st.dataframe(edge_table, hide_index=True, use_container_width=True)
    else:
        st.info("Click Build / refresh IAM graph. The tool will scan IAM live and draw the graph.")

with storage_tab:
    st.markdown("### S3 exposure scan")
    st.write("Checks Block Public Access, bucket policy status, and bucket ACLs. Permission errors are shown as Unknown—not falsely marked public.")
    if st.button("Run S3 scan", type="primary"):
        try:
            with st.spinner("Checking S3 bucket exposure..."):
                results = scan_s3(get_scan_session())
                st.session_state.s3_results = results
                remember_scan("S3", len(results))
            st.success(f"Checked {len(results)} buckets.")
        except Exception as exc:
            show_error(exc)
    if "s3_results" in st.session_state:
        results = st.session_state.s3_results
        high = int(results["risk_level"].eq("HIGH").sum()) if not results.empty else 0
        unknown = int(results["risk_level"].eq("UNKNOWN").sum()) if not results.empty else 0
        mitigated = int(results["risk_level"].eq("MITIGATED").sum()) if not results.empty else 0
        x, y, z, q = st.columns(4)
        x.metric("Buckets", len(results))
        y.metric("Confirmed public", high)
        z.metric("Could not assess", unknown)
        q.metric("Blocked / mitigated", mitigated)
        st.dataframe(results, hide_index=True, use_container_width=True)
        st.download_button(
            "Download S3 exposure results CSV",
            data=results.to_csv(index=False).encode("utf-8"),
            file_name=f"s3_exposure_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv",
        )

        eligible_buckets = results.loc[
            results["risk_level"].isin(["HIGH", "REVIEW"]), "bucket_name"
        ].dropna().astype(str).tolist()
        if eligible_buckets:
            st.markdown('<div class="remediation-card">', unsafe_allow_html=True)
            st.markdown("#### 🛠️ Guarded one-button S3 fix")
            st.write(
                "Select one bucket. The fix enables all four bucket-level Block Public Access controls. "
                "It does not delete objects, bucket policies, or ACLs."
            )
            selected_bucket = st.selectbox(
                "Bucket to protect",
                eligible_buckets,
                key="s3_fix_bucket",
            )
            confirm_s3_fix = st.checkbox(
                "I confirm this bucket is not intentionally public and I authorize RC to change its Block Public Access configuration.",
                key="confirm_s3_fix",
            )
            if st.button(
                "Fix selected S3 exposure in AWS",
                type="primary",
                disabled=not confirm_s3_fix,
                key="apply_s3_fix",
            ):
                try:
                    session = get_scan_session()
                    with st.spinner("Applying all S3 Block Public Access controls..."):
                        remediate_s3_public_access(session, selected_bucket)
                    remember_remediation(
                        "S3",
                        selected_bucket,
                        "Enable all bucket-level Block Public Access controls",
                        "SUCCESS",
                        "AWS accepted the requested configuration change.",
                    )
                except Exception as exc:
                    remember_remediation(
                        "S3",
                        selected_bucket,
                        "Enable all bucket-level Block Public Access controls",
                        "FAILED",
                        friendly_aws_error(exc),
                    )
                    show_error(exc)
                else:
                    try:
                        with st.spinner("Verifying the S3 change..."):
                            verified_results = scan_s3(session)
                        st.session_state.s3_results = verified_results
                        remember_scan("S3 post-fix verification", len(verified_results))
                        st.toast(f"Protected and rescanned {selected_bucket}", icon="✅")
                        st.rerun()
                    except Exception as verify_exc:
                        st.warning(
                            "AWS accepted the S3 change, but the verification scan failed. "
                            "Run the S3 scan again before treating the finding as closed."
                        )
                        show_error(verify_exc)
            st.caption("Requires the optional `s3:PutBucketPublicAccessBlock` remediation permission.")
            st.markdown("</div>", unsafe_allow_html=True)

with sg_tab:
    st.markdown("### Security Group exposure scanner")
    st.write("Scans every Security Group for dangerous IPv4 or IPv6 ingress rules exposed to the entire internet.")
    if st.button("Scan Security Groups", type="primary"):
        try:
            with st.spinner("Checking all Security Group ingress rules..."):
                findings, total = scan_security_groups(get_scan_session())
                st.session_state.sg_results = findings
                st.session_state.sg_total = total
                remember_scan("Security Groups", total)
            st.success(f"Checked {total} security groups.")
        except Exception as exc:
            show_error(exc)
    if "sg_results" in st.session_state:
        findings = st.session_state.sg_results
        total = st.session_state.get("sg_total", 0)
        a, b, c = st.columns(3)
        a.metric("Groups checked", total)
        b.metric("Dangerous public rules", len(findings))
        c.metric("Status", "Review required" if len(findings) else "No listed exposure")
        if findings.empty:
            st.success("No listed dangerous ports were found open to 0.0.0.0/0 or ::/0.")
        else:
            st.warning("Public exposure does not always mean compromise, but each rule should be justified and restricted where possible.")
            st.dataframe(findings, hide_index=True, use_container_width=True)
            st.bar_chart(findings["service"].value_counts())
        st.download_button(
            "Download Security Group results CSV",
            data=findings.to_csv(index=False).encode("utf-8"),
            file_name=f"security_groups_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv",
        )

        candidates = security_group_remediation_candidates(findings)
        if not candidates.empty:
            st.markdown('<div class="remediation-card">', unsafe_allow_html=True)
            st.markdown("#### 🛠️ Guarded one-button Security Group fix")
            st.write(
                "This revokes only the selected public IPv4/IPv6 source from the exact inbound rule. "
                "Private CIDRs and other rules remain unchanged."
            )
            candidate_records = candidates.to_dict("records")

            def candidate_label(index: int) -> str:
                item = candidate_records[index]
                start = item.get("from_port")
                end = item.get("to_port")
                port_range = "ALL ports" if pd.isna(start) or pd.isna(end) else f"ports {int(start)}-{int(end)}"
                return (
                    f"{item['security_group']} | {item['ip_protocol']} {port_range} | "
                    f"source {item['open_to']}"
                )

            selected_rule_index = st.selectbox(
                "Public ingress rule to remove",
                options=list(range(len(candidate_records))),
                format_func=candidate_label,
                key="sg_fix_rule",
            )
            selected_rule = candidate_records[selected_rule_index]
            confirm_sg_fix = st.checkbox(
                "I understand this can interrupt traffic that currently depends on this public rule, and I authorize RC to revoke it.",
                key="confirm_sg_fix",
            )
            if st.button(
                "Fix selected Security Group exposure in AWS",
                type="primary",
                disabled=not confirm_sg_fix,
                key="apply_sg_fix",
            ):
                resource = str(selected_rule["group_id"])
                try:
                    session = get_scan_session()
                    with st.spinner("Revoking the selected public ingress source..."):
                        remediate_security_group_ingress(session, selected_rule)
                    remember_remediation(
                        "EC2",
                        resource,
                        f"Revoke public ingress {selected_rule['open_to']}",
                        "SUCCESS",
                        "AWS accepted the requested ingress-rule change.",
                    )
                except Exception as exc:
                    remember_remediation(
                        "EC2",
                        resource,
                        f"Revoke public ingress {selected_rule['open_to']}",
                        "FAILED",
                        friendly_aws_error(exc),
                    )
                    show_error(exc)
                else:
                    try:
                        with st.spinner("Verifying the Security Group change..."):
                            verified_findings, verified_total = scan_security_groups(session)
                        st.session_state.sg_results = verified_findings
                        st.session_state.sg_total = verified_total
                        remember_scan("Security Groups post-fix verification", verified_total)
                        st.toast(f"Updated and rescanned {resource}", icon="✅")
                        st.rerun()
                    except Exception as verify_exc:
                        st.warning(
                            "AWS accepted the Security Group change, but the verification scan failed. "
                            "Run the Security Group scan again before treating the finding as closed."
                        )
                        show_error(verify_exc)
            st.caption("Requires the optional `ec2:RevokeSecurityGroupIngress` remediation permission.")
            st.markdown("</div>", unsafe_allow_html=True)

with vpc_tab:
    st.markdown("### VPC Flow Log analyzer")
    st.write("Reads recent CloudWatch VPC Flow Logs and looks for rejected-connection bursts that can indicate port scanning.")
    log_group = st.text_input("CloudWatch log group", value="vpc-flow-logs", key="vpc_log_group")
    if st.button("Analyze VPC Flow Logs", type="primary"):
        try:
            with st.spinner("Reading the five most recent log streams..."):
                flow = scan_flow_logs(get_scan_session(), log_group)
                st.session_state.flow_results = flow
                remember_scan("VPC Flow Logs", len(flow))
            st.success(f"Parsed {len(flow)} flow entries.")
        except Exception as exc:
            show_error(exc)
    if "flow_results" in st.session_state:
        flow = st.session_state.flow_results
        rejected = flow[flow["action"].eq("REJECT")] if not flow.empty else flow
        accepted = flow[flow["action"].eq("ACCEPT")] if not flow.empty else flow
        counts = rejected["src_ip"].value_counts() if not rejected.empty else pd.Series(dtype=int)
        suspects = counts[counts >= 5]
        a, b, c, d = st.columns(4)
        a.metric("Flow entries", len(flow))
        b.metric("Accepted", len(accepted))
        c.metric("Rejected", len(rejected))
        d.metric("Possible scanners", len(suspects))
        if flow.empty:
            st.info("No flow entries were available. Confirm that VPC Flow Logs are enabled, the log-group name is correct, and network traffic exists.")
        else:
            st.markdown("#### Traffic action breakdown")
            st.bar_chart(flow["action"].value_counts())
            left, right = st.columns(2)
            with left:
                st.markdown("#### Top source IPs")
                st.dataframe(flow["src_ip"].value_counts().head(15).rename("connections"), use_container_width=True)
            with right:
                st.markdown("#### Possible port scanners")
                if suspects.empty:
                    st.success("No source reached the current threshold of five rejected connections.")
                else:
                    st.dataframe(suspects.rename("rejected_attempts"), use_container_width=True)
            sensitive = flow[flow["dst_port"].isin({str(port) for port in DANGEROUS_PORTS})]
            with st.expander(f"Sensitive destination-port traffic ({len(sensitive)})"):
                st.dataframe(sensitive, hide_index=True, use_container_width=True)
            st.download_button(
                "Download parsed flow logs CSV",
                data=flow.to_csv(index=False).encode("utf-8"),
                file_name=f"vpc_flow_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv",
            )
            with st.expander("All parsed flow entries"):
                st.dataframe(flow, hide_index=True, use_container_width=True)

with zt_tab:
    st.markdown("### Zero Trust identity engine")
    st.write("Continuously verifies each IAM identity using effective high-risk policies, MFA, brute-force involvement, and shadow-admin indicators.")
    auto_verify = st.checkbox("Continuous verification every 60 seconds while the application remains open")
    if auto_verify:
        st_autorefresh(interval=60_000, key="zero_trust_refresh")
        st.caption("Continuous verification is active. This is local monitoring while the desktop application is open—not a 24/7 hosted service.")
    run_zt = st.button("Verify identities now", type="primary") or auto_verify
    if run_zt:
        try:
            brute_users = set(st.session_state.get("last_bruteforce_users", set()))
            shadow_users = set()
            if "iam_results" in st.session_state and not st.session_state.iam_results.empty:
                shadow_users = set(
                    st.session_state.iam_results.loc[
                        st.session_state.iam_results["shadow_admin_heuristic"].ne("No"), "user_name"
                    ]
                )
            with st.spinner("Re-verifying live IAM identity signals..."):
                zt_results = scan_zero_trust(get_scan_session(), brute_users, shadow_users)
                st.session_state.zt_results = zt_results
                st.session_state.zt_last_verified = now_text()
                remember_scan("Zero Trust", len(zt_results))
            st.success(f"Verified {len(zt_results)} identities.")
        except Exception as exc:
            show_error(exc)
    if "zt_results" in st.session_state:
        zt = st.session_state.zt_results
        average = round(float(zt["trust_score"].mean()), 1) if not zt.empty else 0
        untrusted = int(zt["trust_level"].eq("Untrusted").sum()) if not zt.empty else 0
        no_mfa = int(zt["mfa_enabled"].eq("No").sum()) if not zt.empty else 0
        a, b, c, d = st.columns(4)
        a.metric("Average trust", f"{average}/100")
        b.metric("Untrusted", untrusted)
        c.metric("Without MFA", no_mfa)
        d.metric("Last verified", st.session_state.get("zt_last_verified", "Never"))
        st.dataframe(zt, hide_index=True, use_container_width=True)
        if not zt.empty:
            st.markdown("#### Trust score distribution")
            st.bar_chart(zt.set_index("user_name")["trust_score"])
        st.download_button(
            "Download Zero Trust results CSV",
            data=zt.to_csv(index=False).encode("utf-8"),
            file_name=f"zero_trust_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv",
        )

with report_tab:
    st.markdown("### AI Powered Cloud Security assessment report")
    st.write("Combines evidence from Threat Detection, IAM, IAM Graph, S3, Security Groups, VPC Flow Logs, and Zero Trust.")
    report = build_report()
    summary = risk_summary()
    deterministic_summary = (
        f"The current session risk score is {summary['score']}/100. "
        f"The scans identified {summary['alerts']} CloudTrail alert(s), {summary['iam']} high-risk IAM user(s), "
        f"{summary['s3']} confirmed public S3 bucket(s), {summary['network']} dangerous public network rule(s), "
        f"{summary['untrusted']} untrusted identity/identities, and {summary['remediations']} successful in-tool remediation(s). "
        "Findings and cloud changes require analyst validation."
    )

    with st.container(border=True):
        st.markdown("#### Executive summary")
        st.write(st.session_state.get("report_exec_summary", deterministic_summary))
        with st.expander("Generate the executive summary with Gemini (optional)"):
            st.write("This sends the generated text report to Google Gemini. AWS secret keys and Gemini keys are never included in the prompt.")
            report_gemini_key = st.text_input(
                "Gemini API key",
                type="password",
                placeholder="Paste API key or leave empty to use saved key",
                key="report_gemini_key",
            )
            remember_report_key = st.checkbox(
                "Remember Gemini key in Windows Credential Manager",
                value=True,
                key="report_remember_gemini",
            )
            if st.button("Generate AI executive summary", type="primary"):
                try:
                    api_key = report_gemini_key.strip() or load_gemini_key()
                    if not api_key:
                        raise ValueError("Paste a Gemini API key first.")
                    prompt = f"""You are a senior cloud security analyst. Write a professional 5-7 sentence executive summary
for a non-technical reader from this RC AI Powered Cloud Security Platform report. Prioritize confirmed high-risk findings, distinguish
anomalies from confirmed attacks, and state that analyst validation is required. Do not invent facts.

REPORT:
{report[:35000]}
"""
                    with st.spinner("Gemini is preparing the executive summary..."):
                        generated = generate_gemini_text(api_key, prompt)
                    if remember_report_key:
                        save_gemini_key(api_key)
                    st.session_state.report_exec_summary = generated
                    st.success("Executive summary generated.")
                    st.rerun()
                except Exception as exc:
                    st.error(f"Gemini summary failed: {exc}")

    st.markdown("#### Full report")
    st.text_area("Report preview", report, height=520)
    executive = st.session_state.get("report_exec_summary", deterministic_summary)
    full_report = f"EXECUTIVE SUMMARY\n{'-' * 55}\n{executive}\n\n{report}"
    st.download_button(
        "Download full report (.txt)",
        data=full_report.encode("utf-8"),
        file_name=f"rc_ai_cloud_security_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
        mime="text/plain",
        type="primary",
    )
    remediation_history = st.session_state.get("remediation_history", [])
    if not isinstance(remediation_history, list):
        remediation_history = []
    remediation_history = [item for item in remediation_history if isinstance(item, dict)]
    if remediation_history:
        st.markdown("#### Cloud change audit trail")
        st.dataframe(pd.DataFrame(remediation_history), hide_index=True, use_container_width=True)
    st.caption("By default the report stays local. It is sent to Google only when you explicitly press Generate AI executive summary.")
