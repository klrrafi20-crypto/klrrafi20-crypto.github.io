"""Secure storage for AWS credentials using the operating-system keyring.

On Windows this uses Windows Credential Manager through the ``keyring``
package. Secret values are never written to RC CloudSec's settings JSON.
"""

from __future__ import annotations

import json
import re
from typing import TypedDict

import keyring
from keyring.errors import KeyringError


SERVICE_NAME = "RC CloudSec AWS"
GEMINI_SERVICE_NAME = "RC CloudSec Gemini"
GEMINI_USERNAME = "api-key"
LABEL_PATTERN = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")


class AwsCredentials(TypedDict):
    access_key: str
    secret_key: str
    session_token: str


def validate_label(label: str) -> str:
    cleaned = label.strip()
    if not LABEL_PATTERN.fullmatch(cleaned):
        raise ValueError("Credential name must use 1-64 letters, numbers, dots, hyphens, or underscores.")
    return cleaned


def save_credentials(label: str, credentials: AwsCredentials) -> None:
    username = validate_label(label)
    payload = json.dumps(credentials, separators=(",", ":"))
    try:
        keyring.set_password(SERVICE_NAME, username, payload)
    except KeyringError as exc:
        raise RuntimeError(f"Windows Credential Manager could not save the credentials: {exc}") from exc


def load_credentials(label: str) -> AwsCredentials | None:
    username = validate_label(label)
    try:
        payload = keyring.get_password(SERVICE_NAME, username)
    except KeyringError as exc:
        raise RuntimeError(f"Windows Credential Manager could not read the credentials: {exc}") from exc
    if not payload:
        return None
    try:
        data = json.loads(payload)
        access_key = str(data["access_key"]).strip()
        secret_key = str(data["secret_key"]).strip()
        session_token = str(data.get("session_token", "")).strip()
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
        raise RuntimeError("The saved RC credential entry is damaged. Delete it and reconnect.") from exc
    if not access_key or not secret_key:
        raise RuntimeError("The saved RC credential entry is incomplete. Delete it and reconnect.")
    return {"access_key": access_key, "secret_key": secret_key, "session_token": session_token}


def delete_credentials(label: str) -> bool:
    username = validate_label(label)
    try:
        if keyring.get_password(SERVICE_NAME, username) is None:
            return False
        keyring.delete_password(SERVICE_NAME, username)
        return True
    except KeyringError as exc:
        raise RuntimeError(f"Windows Credential Manager could not delete the credentials: {exc}") from exc


def save_gemini_key(api_key: str) -> None:
    value = api_key.strip()
    if not value:
        raise ValueError("Gemini API key is empty.")
    try:
        keyring.set_password(GEMINI_SERVICE_NAME, GEMINI_USERNAME, value)
    except KeyringError as exc:
        raise RuntimeError(f"Windows Credential Manager could not save the Gemini key: {exc}") from exc


def load_gemini_key() -> str:
    try:
        return (keyring.get_password(GEMINI_SERVICE_NAME, GEMINI_USERNAME) or "").strip()
    except KeyringError as exc:
        raise RuntimeError(f"Windows Credential Manager could not read the Gemini key: {exc}") from exc


def delete_gemini_key() -> bool:
    try:
        if keyring.get_password(GEMINI_SERVICE_NAME, GEMINI_USERNAME) is None:
            return False
        keyring.delete_password(GEMINI_SERVICE_NAME, GEMINI_USERNAME)
        return True
    except KeyringError as exc:
        raise RuntimeError(f"Windows Credential Manager could not delete the Gemini key: {exc}") from exc
