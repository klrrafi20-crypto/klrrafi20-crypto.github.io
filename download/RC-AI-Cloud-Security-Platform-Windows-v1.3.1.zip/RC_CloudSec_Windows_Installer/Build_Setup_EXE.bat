@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Build RC AI Cloud Security Setup EXE

set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" (
    echo Inno Setup 6 is required to build Setup.exe.
    echo Download: https://jrsoftware.org/isdl.php
    pause
    exit /b 1
)
py -3.12 -c "import sys" >nul 2>&1
if errorlevel 1 (
    echo Python 3.12 is required to prepare the offline dependency bundle.
    pause
    exit /b 1
)

if not exist "wheelhouse" mkdir "wheelhouse"
echo Downloading Windows dependency wheels for an offline installer...
py -3.12 -m pip download --only-binary=:all: -r requirements.txt -d wheelhouse
if errorlevel 1 exit /b 1

echo Building Setup.exe...
"%ISCC%" "installer\RC_CloudSec.iss"
if errorlevel 1 exit /b 1
echo.
echo Finished. See the dist folder.
pause
