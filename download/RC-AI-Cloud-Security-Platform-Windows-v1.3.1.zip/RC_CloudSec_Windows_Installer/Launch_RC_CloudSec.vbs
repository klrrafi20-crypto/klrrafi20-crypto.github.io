Option Explicit
Dim shell, fso, appDir, command
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
appDir = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = appDir
command = Chr(34) & appDir & "\.venv\Scripts\pythonw.exe" & Chr(34) & " " & Chr(34) & appDir & "\run_app.py" & Chr(34)
shell.Run command, 0, False

