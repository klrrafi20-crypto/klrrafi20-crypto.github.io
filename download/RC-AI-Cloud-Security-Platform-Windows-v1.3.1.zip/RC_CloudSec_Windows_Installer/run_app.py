"""Start RC AI Powered Cloud Security Platform as a native desktop window."""

from __future__ import annotations

import os
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

import webview


BASE_DIR = Path(__file__).resolve().parent
APP_PATH = BASE_DIR / "app.py"


def app_data_dir() -> Path:
    root = Path(os.environ.get("LOCALAPPDATA", Path.home())) if os.name == "nt" else Path.home() / ".local" / "share"
    path = root / "RCCloudSec"
    path.mkdir(parents=True, exist_ok=True)
    return path


def free_port(start: int = 8501, end: int = 8520) -> int:
    for port in range(start, end + 1):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            try:
                sock.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise RuntimeError("No free local port was found between 8501 and 8520.")


def wait_until_ready(url: str) -> bool:
    for _ in range(60):
        try:
            with urllib.request.urlopen(url + "/_stcore/health", timeout=1) as response:
                if response.status == 200:
                    return True
        except Exception:
            time.sleep(0.5)
    return False


def show_startup_error(message: str) -> None:
    if os.name == "nt":
        try:
            import ctypes

            ctypes.windll.user32.MessageBoxW(0, message, "RC AI Cloud Security", 0x10)
            return
        except Exception:
            pass
    print(message, file=sys.stderr)


def main() -> int:
    os.chdir(BASE_DIR)
    data_dir = app_data_dir()
    log_path = data_dir / "launcher.log"
    process: subprocess.Popen | None = None
    log_handle = None
    try:
        port = free_port()
        url = f"http://127.0.0.1:{port}"
        command = [
            sys.executable,
            "-m",
            "streamlit",
            "run",
            str(APP_PATH),
            "--server.address",
            "127.0.0.1",
            "--server.port",
            str(port),
            "--server.headless",
            "true",
            "--browser.gatherUsageStats",
            "false",
        ]
        log_handle = log_path.open("a", encoding="utf-8")
        creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
        process = subprocess.Popen(
            command,
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            creationflags=creation_flags,
        )
        if not wait_until_ready(url):
            raise RuntimeError(f"The dashboard did not start. Diagnostic log: {log_path}")

        webview.create_window(
            "RC — AI Powered Cloud Security Platform",
            url,
            width=1366,
            height=768,
            min_size=(1024, 680),
            resizable=True,
            maximized=True,
            background_color="#081120",
            text_select=True,
        )
        webview.start(debug=False)
        return 0
    except Exception as exc:
        show_startup_error(f"RC AI Cloud Security could not start.\n\n{exc}\n\nSee: {log_path}")
        return 1
    finally:
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
        if log_handle is not None:
            log_handle.close()


if __name__ == "__main__":
    raise SystemExit(main())
