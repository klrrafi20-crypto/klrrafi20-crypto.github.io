@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PYTHON_CMD="
py -3.12 -c "import sys" >nul 2>&1 && set "PYTHON_CMD=py -3.12"
if not defined PYTHON_CMD py -3.11 -c "import sys" >nul 2>&1 && set "PYTHON_CMD=py -3.11"
if not defined PYTHON_CMD (
    echo Python 3.11 or 3.12 is required.
    echo Install Python 3.12 from https://www.python.org/downloads/
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    %PYTHON_CMD% -m venv ".venv" || exit /b 1
)

".venv\Scripts\python.exe" -m pip install --upgrade pip setuptools wheel || exit /b 1
if exist "wheelhouse\*.whl" (
    ".venv\Scripts\python.exe" -m pip install --no-index --find-links "wheelhouse" -r "requirements.txt" || exit /b 1
) else (
    ".venv\Scripts\python.exe" -m pip install -r "requirements.txt" || exit /b 1
)
".venv\Scripts\python.exe" -m pip check || exit /b 1
exit /b 0

