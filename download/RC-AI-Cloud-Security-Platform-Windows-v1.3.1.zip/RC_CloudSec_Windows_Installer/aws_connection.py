"""AWS profile, session, and error helpers for RC CloudSec.

This module deliberately stores only non-secret preferences (profile name and
region). Credentials remain in the standard AWS shared credential/config files
or another provider in boto3's default credential chain.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import boto3
from botocore.config import Config
from botocore.exceptions import (
    BotoCoreError,
    ClientError,
    EndpointConnectionError,
    NoCredentialsError,
    NoRegionError,
    ProfileNotFound,
)


APP_NAME = "RCCloudSec"
DEFAULT_REGION = "ap-south-1"
DEFAULT_PROFILE_LABEL = "Default credential chain"


def _settings_dir() -> Path:
    if os.name == "nt":
        root = Path(os.environ.get("APPDATA", Path.home()))
    else:
        root = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    return root / APP_NAME


SETTINGS_FILE = _settings_dir() / "settings.json"


def load_settings() -> dict[str, str]:
    defaults = {
        "profile": "",
        "region": DEFAULT_REGION,
        "connection_mode": "Access keys inside app",
        "credential_label": "rc-cloudsec",
    }
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        profile = str(data.get("profile", "")).strip()
        region = str(data.get("region", DEFAULT_REGION)).strip() or DEFAULT_REGION
        connection_mode = str(data.get("connection_mode", defaults["connection_mode"]))
        credential_label = str(data.get("credential_label", "rc-cloudsec")).strip() or "rc-cloudsec"
        return {
            "profile": profile,
            "region": region,
            "connection_mode": connection_mode,
            "credential_label": credential_label,
        }
    except (OSError, ValueError, TypeError):
        return defaults


def save_settings(
    profile: str,
    region: str,
    connection_mode: str = "Access keys inside app",
    credential_label: str = "rc-cloudsec",
) -> None:
    SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "profile": profile.strip(),
        "region": region.strip() or DEFAULT_REGION,
        "connection_mode": connection_mode,
        "credential_label": credential_label.strip() or "rc-cloudsec",
    }
    temporary = SETTINGS_FILE.with_suffix(".tmp")
    temporary.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    temporary.replace(SETTINGS_FILE)


def available_profiles() -> list[str]:
    try:
        return sorted(set(boto3.Session().available_profiles), key=str.lower)
    except BotoCoreError:
        return []


def create_session(profile: str = "", region: str = DEFAULT_REGION) -> boto3.Session:
    kwargs: dict[str, str] = {"region_name": region or DEFAULT_REGION}
    if profile and profile != DEFAULT_PROFILE_LABEL:
        kwargs["profile_name"] = profile
    return boto3.Session(**kwargs)


def create_access_key_session(
    access_key: str,
    secret_key: str,
    session_token: str = "",
    region: str = DEFAULT_REGION,
) -> boto3.Session:
    if not access_key.strip() or not secret_key.strip():
        raise NoCredentialsError()
    return boto3.Session(
        aws_access_key_id=access_key.strip(),
        aws_secret_access_key=secret_key.strip(),
        aws_session_token=session_token.strip() or None,
        region_name=region.strip() or DEFAULT_REGION,
    )


def client_for(session: boto3.Session, service: str, *, read_timeout: int = 20) -> Any:
    config = Config(
        region_name=session.region_name or DEFAULT_REGION,
        connect_timeout=6,
        read_timeout=read_timeout,
        retries={"max_attempts": 3, "mode": "standard"},
        user_agent_extra="RCCloudSec/1.0",
    )
    return session.client(service, config=config)


def test_connection(session: boto3.Session) -> dict[str, str]:
    response = client_for(session, "sts").get_caller_identity()
    return {
        "account": str(response.get("Account", "Unknown")),
        "arn": str(response.get("Arn", "Unknown")),
        "user_id": str(response.get("UserId", "Unknown")),
        "region": session.region_name or DEFAULT_REGION,
    }


def friendly_aws_error(exc: Exception) -> str:
    if isinstance(exc, ProfileNotFound):
        return "The selected AWS profile does not exist. Open the AWS tab and choose another profile."
    if isinstance(exc, NoCredentialsError):
        return "AWS is not connected. Open the AWS tab, enter the read-only credentials, and click Connect to AWS."
    if isinstance(exc, NoRegionError):
        return "No AWS Region is configured. Select a Region in the sidebar."
    if isinstance(exc, EndpointConnectionError):
        return "AWS could not be reached. Check the internet connection, Region, VPN, and firewall."
    if isinstance(exc, ClientError):
        error = exc.response.get("Error", {})
        code = str(error.get("Code", "AWS error"))
        message = str(error.get("Message", "The request failed."))
        if code in {"AccessDenied", "AccessDeniedException", "UnauthorizedOperation"}:
            return f"AWS denied this scan ({code}). Attach the included read-only policy to the connected identity."
        if code in {"InvalidClientTokenId", "InvalidAccessKeyId"}:
            return (
                f"AWS rejected this credential set ({code}). Delete the saved credential, then reconnect with "
                "a matching AKIA key and secret, or a complete ASIA key, secret, and session token."
            )
        if code in {"ExpiredToken", "ExpiredTokenException"}:
            return "The temporary AWS credential has expired. Obtain a fresh ASIA key, secret, and session token, then reconnect."
        if code == "SignatureDoesNotMatch":
            return "AWS rejected the request signature. Check the secret key and the computer's date/time."
        if code == "ThrottlingException" or code.startswith("Throttl"):
            return "AWS temporarily rate-limited the scan. Wait briefly and try again."
        return f"AWS returned {code}: {message}"
    if isinstance(exc, BotoCoreError):
        return f"AWS SDK error: {exc}"
    return f"Unexpected error: {exc}"
