"""Regression tests for dashboard result schemas and stale Streamlit state."""

from __future__ import annotations

import ast
from collections import deque
from pathlib import Path
from typing import Any, Iterable
import unittest

import pandas as pd


APP_PATH = Path(__file__).resolve().parents[1] / "app.py"


class SessionState(dict):
    def __getattr__(self, name: str) -> Any:
        try:
            return self[name]
        except KeyError as exc:
            raise AttributeError(name) from exc

    def __setattr__(self, name: str, value: Any) -> None:
        self[name] = value


class FakeStreamlit:
    def __init__(self) -> None:
        self.session_state = SessionState(selected_region="ap-south-1")


class FakeClientError(Exception):
    def __init__(self, code: str) -> None:
        self.response = {"Error": {"Code": code}}


def load_app_functions() -> dict[str, Any]:
    tree = ast.parse(APP_PATH.read_text(encoding="utf-8"), filename=str(APP_PATH))
    wanted_assignments = {
        "DANGEROUS_PORTS",
        "S3_RESULT_COLUMNS",
        "SG_RESULT_COLUMNS",
        "ZERO_TRUST_COLUMNS",
        "RESULT_SCHEMAS",
    }
    wanted_functions = {
        "now_text",
        "valid_frame",
        "state_frame",
        "count_value",
        "validate_credential_set",
        "discard_incompatible_result_state",
        "analyze_cloudtrail",
        "scan_s3",
        "remediate_s3_public_access",
        "scan_security_groups",
        "security_group_remediation_candidates",
        "remediate_security_group_ingress",
        "scan_zero_trust",
        "risk_summary",
        "build_report",
    }
    nodes: list[ast.stmt] = []
    for node in tree.body:
        if isinstance(node, ast.Assign):
            names = {target.id for target in node.targets if isinstance(target, ast.Name)}
            if names.intersection(wanted_assignments):
                nodes.append(node)
        elif isinstance(node, ast.FunctionDef) and node.name in wanted_functions:
            nodes.append(node)

    st = FakeStreamlit()
    namespace: dict[str, Any] = {
        "Any": Any,
        "Iterable": Iterable,
        "ClientError": FakeClientError,
        "IsolationForest": object,
        "deque": deque,
        "datetime": __import__("datetime").datetime,
        "pd": pd,
        "st": st,
    }
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(APP_PATH), "exec"), namespace)
    return namespace


class ResultSchemaTests(unittest.TestCase):
    def setUp(self) -> None:
        self.app = load_app_functions()
        self.state = self.app["st"].session_state

    def test_risk_summary_ignores_malformed_old_s3_results(self) -> None:
        self.state["s3_results"] = pd.DataFrame({"bucket_name": ["legacy-bucket"]})
        summary = self.app["risk_summary"]()
        self.assertEqual(summary["s3"], 0)

    def test_akia_credentials_require_no_session_token(self) -> None:
        credentials = self.app["validate_credential_set"]("AKIAEXAMPLE", "secret", "")
        self.assertEqual(credentials["session_token"], "")
        with self.assertRaisesRegex(ValueError, "do not use a Session Token"):
            self.app["validate_credential_set"]("AKIAEXAMPLE", "secret", "unexpected-token")

    def test_asia_credentials_require_matching_session_token(self) -> None:
        with self.assertRaisesRegex(ValueError, "require the matching AWS Session Token"):
            self.app["validate_credential_set"]("ASIAEXAMPLE", "secret", "")
        credentials = self.app["validate_credential_set"]("ASIAEXAMPLE", "secret", "token")
        self.assertEqual(credentials["session_token"], "token")

    def test_invalid_access_key_prefix_is_rejected_before_aws(self) -> None:
        with self.assertRaisesRegex(ValueError, "should start with AKIA"):
            self.app["validate_credential_set"]("123456789012", "console-password", "")

    def test_risk_summary_counts_valid_high_risk_s3_result(self) -> None:
        self.state["s3_results"] = pd.DataFrame(
            [
                {
                    "bucket_name": "public-bucket",
                    "block_public_access": "Partially open",
                    "public_bucket_policy": "YES",
                    "public_acl": "No",
                    "risk_level": "HIGH",
                    "notes": "Complete",
                }
            ],
            columns=self.app["S3_RESULT_COLUMNS"],
        )
        self.assertEqual(self.app["risk_summary"]()["s3"], 1)

    def test_scan_s3_always_returns_the_bucket_schema(self) -> None:
        class S3:
            def list_buckets(self) -> dict[str, Any]:
                return {"Buckets": [{"Name": "private-bucket"}]}

            def get_public_access_block(self, **_: Any) -> dict[str, Any]:
                return {"PublicAccessBlockConfiguration": {"a": True, "b": True}}

            def get_bucket_policy_status(self, **_: Any) -> dict[str, Any]:
                return {"PolicyStatus": {"IsPublic": False}}

            def get_bucket_acl(self, **_: Any) -> dict[str, Any]:
                return {"Grants": []}

        self.app["client_for"] = lambda *_args, **_kwargs: S3()
        result = self.app["scan_s3"](object())
        self.assertEqual(list(result.columns), self.app["S3_RESULT_COLUMNS"])
        self.assertEqual(result.iloc[0]["risk_level"], "LOW")

    def test_s3_public_grant_is_mitigated_when_fully_blocked(self) -> None:
        class S3:
            def list_buckets(self) -> dict[str, Any]:
                return {"Buckets": [{"Name": "legacy-public-policy"}]}

            def get_public_access_block(self, **_: Any) -> dict[str, Any]:
                return {"PublicAccessBlockConfiguration": {"a": True, "b": True, "c": True, "d": True}}

            def get_bucket_policy_status(self, **_: Any) -> dict[str, Any]:
                return {"PolicyStatus": {"IsPublic": True}}

            def get_bucket_acl(self, **_: Any) -> dict[str, Any]:
                return {"Grants": []}

        self.app["client_for"] = lambda *_args, **_kwargs: S3()
        result = self.app["scan_s3"](object())
        self.assertEqual(result.iloc[0]["risk_level"], "MITIGATED")

    def test_s3_remediation_enables_all_four_controls(self) -> None:
        class S3:
            request: dict[str, Any] | None = None

            def put_public_access_block(self, **kwargs: Any) -> None:
                self.request = kwargs

        client = S3()
        self.app["client_for"] = lambda *_args, **_kwargs: client
        self.app["remediate_s3_public_access"](object(), "important-bucket")
        self.assertEqual(client.request["Bucket"], "important-bucket")
        self.assertTrue(all(client.request["PublicAccessBlockConfiguration"].values()))

    def test_security_group_scan_keeps_exact_rule_metadata(self) -> None:
        groups = [
            {
                "GroupId": "sg-123",
                "GroupName": "admin",
                "IpPermissions": [
                    {
                        "IpProtocol": "tcp",
                        "FromPort": 22,
                        "ToPort": 22,
                        "IpRanges": [{"CidrIp": "0.0.0.0/0"}],
                        "Ipv6Ranges": [],
                    }
                ],
            }
        ]
        self.app["client_for"] = lambda *_args, **_kwargs: object()
        self.app["paginate"] = lambda *_args, **_kwargs: groups
        result, total = self.app["scan_security_groups"](object())
        self.assertEqual(total, 1)
        self.assertEqual(list(result.columns), self.app["SG_RESULT_COLUMNS"])
        self.assertEqual(result.iloc[0]["group_id"], "sg-123")
        self.assertEqual(result.iloc[0]["from_port"], 22)

    def test_security_group_remediation_revokes_only_selected_source(self) -> None:
        class EC2:
            request: dict[str, Any] | None = None

            def revoke_security_group_ingress(self, **kwargs: Any) -> None:
                self.request = kwargs

        client = EC2()
        self.app["client_for"] = lambda *_args, **_kwargs: client
        self.app["remediate_security_group_ingress"](
            object(),
            {
                "group_id": "sg-123",
                "ip_protocol": "tcp",
                "from_port": 3389,
                "to_port": 3389,
                "open_to": "::/0",
            },
        )
        permission = client.request["IpPermissions"][0]
        self.assertEqual(client.request["GroupId"], "sg-123")
        self.assertEqual(permission["FromPort"], 3389)
        self.assertEqual(permission["Ipv6Ranges"], [{"CidrIpv6": "::/0"}])
        self.assertNotIn("IpRanges", permission)

    def test_duplicate_dangerous_ports_create_one_remediation_candidate(self) -> None:
        columns = self.app["SG_RESULT_COLUMNS"]
        rows = [
            ["wide (sg-1)", "sg-1", "tcp", 1, 65535, 22, "SSH", "0.0.0.0/0", "HIGH"],
            ["wide (sg-1)", "sg-1", "tcp", 1, 65535, 3389, "RDP", "0.0.0.0/0", "HIGH"],
        ]
        candidates = self.app["security_group_remediation_candidates"](pd.DataFrame(rows, columns=columns))
        self.assertEqual(len(candidates), 1)

    def test_empty_s3_and_zero_trust_scans_keep_their_columns(self) -> None:
        class S3:
            def list_buckets(self) -> dict[str, Any]:
                return {"Buckets": []}

        self.app["client_for"] = lambda *_args, **_kwargs: S3()
        s3 = self.app["scan_s3"](object())
        self.assertTrue(s3.empty)
        self.assertEqual(list(s3.columns), self.app["S3_RESULT_COLUMNS"])

        self.app["client_for"] = lambda *_args, **_kwargs: object()
        self.app["paginate"] = lambda *_args, **_kwargs: []
        zt = self.app["scan_zero_trust"](object())
        self.assertTrue(zt.empty)
        self.assertEqual(list(zt.columns), self.app["ZERO_TRUST_COLUMNS"])

    def test_empty_cloudtrail_analysis_keeps_dashboard_columns(self) -> None:
        source = pd.DataFrame(
            columns=[
                "Event time",
                "User name",
                "Event source",
                "Event name",
                "Source IP address",
                "Error code",
                "Read-only",
            ]
        )
        analyzed, alerts = self.app["analyze_cloudtrail"](source)
        self.assertIn("brute_force_detected", analyzed.columns)
        self.assertIn("anomaly_score", alerts.columns)

    def test_stale_results_are_discarded_and_report_still_builds(self) -> None:
        self.state["s3_results"] = pd.DataFrame({"wrong": [1]})
        self.state["iam_results"] = "interrupted"
        removed = self.app["discard_incompatible_result_state"]()
        self.assertIn("s3_results", removed)
        self.assertIn("iam_results", removed)
        report = self.app["build_report"]()
        self.assertIn("4. S3 EXPOSURE", report)
        self.assertIn("Not run in this session.", report)

    def test_risk_summary_counts_successful_remediations(self) -> None:
        self.state["remediation_history"] = [
            {"Status": "SUCCESS"},
            {"Status": "FAILED"},
        ]
        self.assertEqual(self.app["risk_summary"]()["remediations"], 1)


if __name__ == "__main__":
    unittest.main()
