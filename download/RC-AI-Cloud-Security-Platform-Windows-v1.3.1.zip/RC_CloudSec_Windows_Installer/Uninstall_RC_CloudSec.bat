@echo off
setlocal
set "INSTALL_DIR=%LOCALAPPDATA%\Programs\RCCloudSec"
echo This removes RC AI Cloud Security and its local Python environment.
echo AWS credentials in %%USERPROFILE%%\.aws are NOT removed.
choice /C YN /M "Continue"
if errorlevel 2 exit /b 0
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
 "Remove-Item -Force -ErrorAction SilentlyContinue ([Environment]::GetFolderPath('Desktop')+'\RC CloudSec.lnk');" ^
 "Remove-Item -Force -ErrorAction SilentlyContinue ([Environment]::GetFolderPath('Desktop')+'\RC AI Cloud Security.lnk');" ^
 "Remove-Item -Recurse -Force -ErrorAction SilentlyContinue ([Environment]::GetFolderPath('StartMenu')+'\Programs\RC CloudSec');" ^
 "Remove-Item -Recurse -Force -ErrorAction SilentlyContinue ([Environment]::GetFolderPath('StartMenu')+'\Programs\RC AI Cloud Security');" ^
 "Start-Process cmd.exe -ArgumentList '/c ping 127.0.0.1 -n 3 ^>nul ^& rmdir /s /q ""%INSTALL_DIR%""' -WindowStyle Hidden"
echo Uninstall started. This window can be closed.
