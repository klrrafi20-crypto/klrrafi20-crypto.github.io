@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo RC AI Cloud Security is not installed correctly.
    echo Run Install_RC_CloudSec.bat again.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" "run_app.py"
if errorlevel 1 pause
