#define MyAppName "RC AI Powered Cloud Security Platform"
#define MyAppVersion "1.3.1"
#define MyAppPublisher "Muhammed Rafi"
#define MyAppExeName "Launch_RC_CloudSec.bat"

[Setup]
AppId={{87F5E8EC-0E7F-40D0-9E80-FAE9C34E655A}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Programs\RCCloudSec
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=..\dist
OutputBaseFilename=RC_AI_Cloud_Security_Setup_1.3.1
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
UninstallDisplayName={#MyAppName}
UninstallDisplayIcon={app}\assets\rc_icon.ico
SetupIconFile=..\assets\rc_icon.ico
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Files]
Source: "..\app.py"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\aws_connection.py"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\credential_vault.py"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\run_app.py"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\requirements.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\Launch_RC_CloudSec.bat"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\Launch_RC_CloudSec.vbs"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\Post_Install.bat"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\README_INSTALLATION.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\.streamlit\*"; DestDir: "{app}\.streamlit"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\aws\*"; DestDir: "{app}\aws"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\assets\*"; DestDir: "{app}\assets"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\sample_data\*"; DestDir: "{app}\sample_data"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\wheelhouse\*"; DestDir: "{app}\wheelhouse"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\RC AI Cloud Security"; Filename: "{sys}\wscript.exe"; Parameters: """{app}\Launch_RC_CloudSec.vbs"""; WorkingDir: "{app}"; IconFilename: "{app}\assets\rc_icon.ico"
Name: "{autodesktop}\RC AI Cloud Security"; Filename: "{sys}\wscript.exe"; Parameters: """{app}\Launch_RC_CloudSec.vbs"""; WorkingDir: "{app}"; IconFilename: "{app}\assets\rc_icon.ico"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Shortcuts:"; Flags: checkedonce

[Run]
Filename: "{app}\Post_Install.bat"; Description: "Install application dependencies"; Flags: runhidden waituntilterminated; StatusMsg: "Creating the secure local environment..."
Filename: "{sys}\wscript.exe"; Parameters: """{app}\Launch_RC_CloudSec.vbs"""; Description: "Launch RC AI Cloud Security"; Flags: postinstall nowait skipifsilent

[UninstallDelete]
Type: filesandordirs; Name: "{app}\.venv"
Type: filesandordirs; Name: "{app}\wheelhouse"

[Code]
function PrepareToInstall(var NeedsRestart: Boolean): String;
var
  ResultCode: Integer;
  PythonFound: Boolean;
begin
  PythonFound := Exec(ExpandConstant('{cmd}'), '/C py -3.12 -c "import sys"', '',
    SW_HIDE, ewWaitUntilTerminated, ResultCode) and (ResultCode = 0);
  if not PythonFound then
    PythonFound := Exec(ExpandConstant('{cmd}'), '/C py -3.11 -c "import sys"', '',
      SW_HIDE, ewWaitUntilTerminated, ResultCode) and (ResultCode = 0);

  if not PythonFound then
    Result := 'RC AI Cloud Security requires 64-bit Python 3.11 or 3.12. Install Python 3.12, then run Setup again.'
  else
    Result := '';
end;
