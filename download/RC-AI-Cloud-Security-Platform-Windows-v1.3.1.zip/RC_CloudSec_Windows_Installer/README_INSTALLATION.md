# RC — AI Powered Cloud Security Platform

RC is a local AWS security desktop application for scanning, investigation, IAM visualization, AI-assisted explanation, reporting, and guarded remediation. It opens in a maximized native window—not a browser tab. Its internal interface is bound only to the private `127.0.0.1` address and is not an internet-facing server.

All scanners are read-only. Cloud changes are available only when an administrator separately attaches the optional remediation policy, the operator selects one finding, and the operator confirms and presses its fix button.

## Complete modules included

| Module | Data and behavior |
|---|---|
| Overview | Unified session risk score, findings summary, successful-fix count, scan history, and module readiness. |
| Threat Detection | Live AWS CloudTrail collection, Isolation Forest anomaly detection, failed ConsoleLogin brute-force rules, insider/unclassified labeling, uploaded CloudTrail CSV, included synthetic Random Forest demo, and S3 CSV import. |
| Security Groups | Live IPv4 and IPv6 public-ingress review plus a guarded fix that revokes only one selected public source from the exact rule. |
| VPC Flow Logs | Live CloudWatch log-stream collection, ACCEPT/REJECT breakdown, sensitive destination ports, and possible port-scanner detection. |
| S3 Exposure | Live exposure review plus a guarded fix that enables all four bucket-level Block Public Access settings for one selected bucket. |
| IAM Audit / CIEM | Direct and group policy review, MFA, high-risk managed policies, effective action inspection, and shadow-admin heuristics. |
| IAM Graph | Full-size user → group → inline/managed-policy relationship graph with isolated users, risk colors, PNG download, and edge table. |
| Gemini Explanations | Optional IAM risk explanations using the current Google Gen AI SDK. The Gemini key can be kept in Windows Credential Manager. |
| Zero Trust | Manual or 60-second continuous verification using high-risk policy, MFA, brute-force history, and shadow-admin signals. |
| Incident Report | Module-by-module evidence, deterministic summary, optional Gemini executive summary, remediation audit trail, and TXT download. |

## Recommended installation

1. Extract the complete `RC_CloudSec_Windows_Installer.zip` file. Do not run the installer from inside the ZIP preview.
2. Open the extracted folder and double-click `Install_RC_CloudSec.bat`.
3. If Python is missing, accept the Python 3.12 installation or install 64-bit Python 3.12 manually, then run the installer again.
4. Wait while the private Python environment and dependencies are installed. Keep the internet connected for this first installation.
5. Open **RC AI Cloud Security** from the Desktop or Start Menu. The RC icon opens a maximized desktop window with no server terminal.
6. Open the first tab, **AWS**.
7. Keep **Access keys inside app** selected, then complete:
   - **Credential name:** `rc-cloudsec` (only a local label)
   - **AWS Access Key ID:** begins with values such as `AKIA...`
   - **AWS Secret Access Key:** paste with `Ctrl+V`
   - **AWS Region:** normally `ap-south-1` for Mumbai
   - **Session Token:** leave empty unless AWS gave you temporary three-part credentials
8. Keep **Remember securely on this computer** selected only on your own trusted Windows computer, then click **Connect to AWS**.
9. The application validates the identity with AWS before storing anything. If Remember is selected, Windows Credential Manager protects the credential; otherwise it stays only in the current app session.

The alternative **Existing AWS profile / SSO** option remains available for an AWS profile already configured on the computer.

Gemini is optional. AWS scanning works without a Gemini API key. If you use Gemini explanations or the AI executive summary, the displayed findings/report are sent to Google only after you press the corresponding Generate button.

## Update an existing 1.2.x installation

1. Close the RC AI Cloud Security desktop window completely.
2. Extract the new 1.3.1 ZIP to a normal folder such as Downloads. Do not run it inside the ZIP preview.
3. Double-click `Install_RC_CloudSec.bat`. It safely replaces the program files in `%LOCALAPPDATA%\Programs\RCCloudSec` and reuses the existing private Python environment.
4. Open the new **RC AI Cloud Security** desktop shortcut. The sidebar must show **Complete Desktop v1.3.1**.
5. If the old S3 result had the incorrect schema, the app clears only that incompatible scan result and asks you to rerun it. Open **S3** and click **Run S3 scan**.

Saved AWS secrets remain in Windows Credential Manager and are not included in the program folder. Reinstalling does not delete them. You may still need to reconnect if the access key was rotated, disabled, or expired.

## Create the AWS read-only identity

For a personal learning account using access keys:

1. Sign in to the AWS console with an administrator identity.
2. Open **IAM → Policies → Create policy → JSON**.
3. Paste the contents of `aws\RCCloudSecReadOnlyPolicy.json` and create a policy named `RCCloudSecReadOnlyPolicy`.
4. Create or choose a dedicated IAM user for the dashboard and attach only this policy.
5. Create an access key for that user, selecting the local/third-party application use case.
6. Open RC AI Cloud Security, select **AWS**, and paste the access key and secret key into the interface.
7. Disable or delete the key when it is no longer required.

Do not paste AWS keys into `app.py`, a screenshot, GitHub, email, or chat. With **Remember securely** enabled, RC saves the validated secret in Windows Credential Manager. Its normal settings file contains only the credential label, connection method, profile name, and Region—never the secret key.

The included policy permits `s3:GetObject` only for the original project bucket `rafi-cloudsecurity-2026`. If your dataset bucket has another name, replace that bucket ARN in `RCCloudSecReadOnlyPolicy.json` before creating the policy.

## Enable guarded one-button fixes — optional

Keep the platform read-only unless you explicitly need remediation. To enable the two included fixes:

1. Review `aws\RCCloudSecRemediationPolicy.json` with the AWS account owner.
2. In AWS IAM, create a separate customer-managed policy named `RCCloudSecRemediationPolicy` from that JSON.
3. Attach it to the same dedicated RC user or role only after approval.
4. Reconnect the platform, run the S3 or Security Group scan, select one finding, read the impact warning, tick the authorization checkbox, and press the fix button.
5. RC records the accepted AWS change in the session audit trail and automatically rescans the affected service.

The optional policy permits only `s3:PutBucketPublicAccessBlock` on S3 buckets and `ec2:RevokeSecurityGroupIngress` on Security Groups. It does not grant object deletion, bucket deletion, instance termination, IAM modification, or new firewall-rule creation.

The S3 fix can block an intentionally public website or cross-account access. The Security Group fix can interrupt users or services that depend on public access. Always confirm application ownership and maintenance approval first. IAM findings are explanation-only because automatically detaching policies can cause account lockout.

## Normal use

- No browser or black launcher window needs to remain open. The desktop window owns and stops the local engine.
- Start in **AWS**, then run only the module scans you need.
- CloudTrail lookup examines recent management events available through `LookupEvents`; it is not a replacement for a long-term trail/SIEM.
- VPC Flow Logs analysis needs an existing CloudWatch Logs group and active flow logging.
- Close the RC AI Cloud Security desktop window to stop the application.

## Common errors

| Error | Correction |
|---|---|
| Secret key does not paste | Click the Secret Access Key box and press `Ctrl+V`. Do not expect hidden password characters to show the real text. |
| No AWS credentials found | Open **AWS** and enter both the Access Key ID and Secret Access Key, or use a saved credential name. |
| AWS profile does not exist | Select an available profile or configure it again. |
| No Region configured | Set the Region in **AWS**, such as `ap-south-1`, and reconnect. |
| AccessDenied during a scan | Attach `RCCloudSecReadOnlyPolicy.json` to the connected IAM user/role. Check SCPs and permission boundaries too. |
| AccessDenied from a fix button | If remediation is approved, attach `RCCloudSecRemediationPolicy.json`. Otherwise keep the platform read-only. |
| Invalid or expired token | Run `aws sso login --profile PROFILE` for SSO, or configure a fresh access key/session token. |
| `InvalidClientTokenId` | In the AWS tab, open **AKIA or ASIA?**, delete the saved credential, and reconnect with one matching set. AKIA uses key + secret with no token; ASIA requires key + secret + session token. |
| SignatureDoesNotMatch | Re-enter the secret key and make sure Windows date/time is correct. |
| VPC log group missing | Enable VPC Flow Logs to CloudWatch Logs or enter the correct log-group name. |
| `KeyError: 'risk_level'` after an older S3 scan | Install version 1.2.1 or later. It corrects the S3 result schema and automatically clears an incompatible result; then rerun **S3 → Run S3 scan**. |
| Installation dependency error | Use Python 3.12, check internet/proxy settings, then run the installer again. |
| Desktop window does not open | Run the Desktop shortcut again. See `%LOCALAPPDATA%\RCCloudSec\launcher.log` for the exact startup error. |

## Build a traditional Setup.exe (optional)

The ZIP includes an Inno Setup definition. On a Windows development computer:

1. Install Python 3.12 and Inno Setup 6.
2. Double-click `Build_Setup_EXE.bat` while connected to the internet.
3. The script downloads Windows wheels, then creates `dist\RC_AI_Cloud_Security_Setup_1.3.1.exe`.
4. Test the generated installer on a clean Windows VM before distributing it.

The generated Setup.exe bundles Python packages for offline installation, but the target computer still needs Python 3.11 or 3.12 installed.

## Scope and limitations

- The included Random Forest model is trained on synthetic login data and is only a demonstration.
- Isolation Forest findings are unusual events, not confirmed attacks.
- The overall score is a prioritization heuristic, not a compliance certification.
- IAM shadow-admin analysis is heuristic and does not fully evaluate SCPs, permission boundaries, conditions, resource policies, or every possible escalation chain.
- One-button fixes are deliberately limited to selected S3 Block Public Access and public Security Group ingress findings. Other findings require a reviewed manual change plan.
- Use the tool only on AWS accounts you own or are explicitly authorized to assess.
