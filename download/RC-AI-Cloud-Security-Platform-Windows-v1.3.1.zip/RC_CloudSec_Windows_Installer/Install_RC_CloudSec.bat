@echo off
setlocal EnableExtensions
title RC AI Cloud Security Installer
color 0B

set "SOURCE=%~dp0"
set "INSTALL_DIR=%LOCALAPPDATA%\Programs\RCCloudSec"

echo ==============================================================
echo          RC AI Powered Cloud Security Platform
echo ==============================================================
echo.
echo Install location: %INSTALL_DIR%
echo.

set "PYTHON_CMD="
py -3.12 -c "import sys" >nul 2>&1 && set "PYTHON_CMD=py -3.12"
if not defined PYTHON_CMD py -3.11 -c "import sys" >nul 2>&1 && set "PYTHON_CMD=py -3.11"

if not defined PYTHON_CMD (
    echo Python 3.11 or 3.12 was not found.
    where winget >nul 2>&1
    if errorlevel 1 goto :python_missing
    choice /C YN /M "Install Python 3.12 for this Windows user now"
    if errorlevel 2 goto :python_missing
    winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
    if errorlevel 1 goto :failed
    set "PYTHON_CMD=py -3.12"
)

echo [1/5] Copying application files...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
for %%F in (app.py aws_connection.py credential_vault.py run_app.py requirements.txt Launch_RC_CloudSec.bat Launch_RC_CloudSec.vbs Post_Install.bat Uninstall_RC_CloudSec.bat README_INSTALLATION.md) do (
    copy /Y "%SOURCE%%%F" "%INSTALL_DIR%\%%F" >nul || goto :failed
)
xcopy /E /I /Y "%SOURCE%.streamlit" "%INSTALL_DIR%\.streamlit" >nul || goto :failed
xcopy /E /I /Y "%SOURCE%aws" "%INSTALL_DIR%\aws" >nul || goto :failed
xcopy /E /I /Y "%SOURCE%assets" "%INSTALL_DIR%\assets" >nul || goto :failed
xcopy /E /I /Y "%SOURCE%sample_data" "%INSTALL_DIR%\sample_data" >nul || goto :failed
if exist "%INSTALL_DIR%\Configure_AWS.bat" del /Q "%INSTALL_DIR%\Configure_AWS.bat"
if exist "%INSTALL_DIR%\configure_aws.py" del /Q "%INSTALL_DIR%\configure_aws.py"

echo [2/5] Creating isolated Python environment...
call "%INSTALL_DIR%\Post_Install.bat" || goto :failed

echo [3/5] Creating shortcuts...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
 "$w=New-Object -ComObject WScript.Shell;" ^
 "Remove-Item -Force -ErrorAction SilentlyContinue ([Environment]::GetFolderPath('Desktop')+'\RC CloudSec.lnk');" ^
 "Remove-Item -Recurse -Force -ErrorAction SilentlyContinue ([Environment]::GetFolderPath('StartMenu')+'\Programs\RC CloudSec');" ^
 "$d=$w.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\RC AI Cloud Security.lnk');" ^
 "$d.TargetPath=$env:WINDIR+'\System32\wscript.exe';$d.Arguments=([char]34+'%INSTALL_DIR%\Launch_RC_CloudSec.vbs'+[char]34);$d.WorkingDirectory='%INSTALL_DIR%';$d.IconLocation='%INSTALL_DIR%\assets\rc_icon.ico,0';$d.Save();" ^
 "$menu=[Environment]::GetFolderPath('StartMenu')+'\Programs\RC AI Cloud Security';New-Item -ItemType Directory -Force -Path $menu|Out-Null;" ^
 "$s=$w.CreateShortcut($menu+'\RC AI Cloud Security.lnk');$s.TargetPath=$env:WINDIR+'\System32\wscript.exe';$s.Arguments=([char]34+'%INSTALL_DIR%\Launch_RC_CloudSec.vbs'+[char]34);$s.WorkingDirectory='%INSTALL_DIR%';$s.IconLocation='%INSTALL_DIR%\assets\rc_icon.ico,0';$s.Save();" ^
 "$u=$w.CreateShortcut($menu+'\Uninstall RC AI Cloud Security.lnk');$u.TargetPath='%INSTALL_DIR%\Uninstall_RC_CloudSec.bat';$u.WorkingDirectory='%INSTALL_DIR%';$u.Save()" || goto :failed

echo [4/5] Installation verified.
"%INSTALL_DIR%\.venv\Scripts\python.exe" -m py_compile "%INSTALL_DIR%\app.py" "%INSTALL_DIR%\aws_connection.py" "%INSTALL_DIR%\credential_vault.py" "%INSTALL_DIR%\run_app.py" || goto :failed

echo [5/5] Desktop application ready.

:success
echo.
echo ==============================================================
echo Installation complete.
echo Open RC AI Cloud Security from the Desktop, then use the AWS tab.
echo ==============================================================
echo.
pause
exit /b 0

:python_missing
echo.
echo Install 64-bit Python 3.12, tick "Add python.exe to PATH", then run this installer again.
echo https://www.python.org/downloads/
pause
exit /b 1

:failed
echo.
echo Installation failed. Read the error above, check the internet connection,
echo and run this installer again. Existing AWS credentials were not deleted.
pause
exit /b 1
