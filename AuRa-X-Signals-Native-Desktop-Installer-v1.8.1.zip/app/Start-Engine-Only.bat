@echo off
cd /d "%~dp0"
title AuRa X Signals - Engine Only
if not exist ".venv\Scripts\python.exe" (
  echo The application is not installed correctly. Run Repair from the Start Menu.
  pause
  exit /b 1
)
.venv\Scripts\python.exe run_signals.py
if errorlevel 1 pause
