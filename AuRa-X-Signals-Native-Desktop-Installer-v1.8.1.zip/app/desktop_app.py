from __future__ import annotations

from pathlib import Path
from datetime import datetime
import ctypes
import json
import logging
import os
import signal
import sys
import threading
import time
import traceback

from aurax_signals.engine import AuRaSignalsEngine
from aurax_signals.server import SignalsServer

APP_NAME = "AuRa X Signals"
APP_VERSION = "1.8.1"
APP_ID = "AuRaX.Signals.Desktop"


def app_root() -> Path:
    return Path(__file__).resolve().parent


def setup_logging(root: Path) -> Path:
    log_dir = root / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "aurax-signals.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[logging.FileHandler(log_file, encoding="utf-8")],
        force=True,
    )
    return log_file


def show_error(title: str, message: str) -> None:
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        messagebox.showerror(title, message, parent=root)
        root.destroy()
    except Exception:
        pass


def acquire_single_instance() -> int | None:
    if os.name != "nt":
        return 1
    kernel32 = ctypes.windll.kernel32
    handle = kernel32.CreateMutexW(None, False, "Local\\AuRaXSignalsDesktopV181")
    if not handle:
        return None
    if kernel32.GetLastError() == 183:  # ERROR_ALREADY_EXISTS
        kernel32.CloseHandle(handle)
        return None
    return int(handle)




def get_work_area() -> tuple[int, int, int, int]:
    """Return the usable desktop work area in physical pixels."""
    if os.name != "nt":
        return (0, 0, 1366, 768)
    try:
        # Per-monitor DPI awareness prevents Windows display scaling from making
        # a nominal 1420x900 window larger than the physical work area.
        try:
            ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
        except Exception:
            try:
                ctypes.windll.user32.SetProcessDPIAware()
            except Exception:
                pass
        class RECT(ctypes.Structure):
            _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                        ("right", ctypes.c_long), ("bottom", ctypes.c_long)]
        rect = RECT()
        SPI_GETWORKAREA = 0x0030
        if ctypes.windll.user32.SystemParametersInfoW(SPI_GETWORKAREA, 0, ctypes.byref(rect), 0):
            return (int(rect.left), int(rect.top), int(rect.right), int(rect.bottom))
    except Exception:
        pass
    return (0, 0, int(ctypes.windll.user32.GetSystemMetrics(0)), int(ctypes.windll.user32.GetSystemMetrics(1)))


def set_windows_identity() -> None:
    if os.name == "nt":
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
        except Exception:
            pass


class DesktopApi:
    def __init__(self, server: SignalsServer, log_file: Path):
        self.server = server
        self.log_file = log_file

    def get_desktop_info(self) -> dict:
        return {
            "desktop": True,
            "version": APP_VERSION,
            "phone_url": self.server.address,
            "log_file": str(self.log_file),
        }

    def copy_phone_url(self) -> dict:
        url = self.server.address
        try:
            import tkinter as tk
            root = tk.Tk()
            root.withdraw()
            root.clipboard_clear()
            root.clipboard_append(url)
            root.update()
            root.destroy()
            return {"ok": True, "value": url}
        except Exception as exc:
            return {"ok": False, "error": str(exc), "value": url}

    def open_logs_folder(self) -> dict:
        try:
            os.startfile(str(self.log_file.parent))  # type: ignore[attr-defined]
            return {"ok": True}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}


def main() -> int:
    root = app_root()
    log_file = setup_logging(root)
    set_windows_identity()
    mutex = acquire_single_instance()
    if mutex is None:
        show_error(APP_NAME, "AuRa X Signals is already running. Check the taskbar or close the existing window first.")
        return 2

    engine: AuRaSignalsEngine | None = None
    server: SignalsServer | None = None
    try:
        try:
            import webview
        except Exception as exc:
            raise RuntimeError(
                "The desktop window component is missing. Run Repair-AuRa-X-Signals from the Start Menu.\n\n"
                f"Technical detail: {exc}"
            ) from exc

        settings = json.loads((root / "config" / "settings.json").read_text(encoding="utf-8"))
        engine = AuRaSignalsEngine(root)
        server = SignalsServer(root, engine, int(settings.get("port", 8787)))
        engine.start()
        server.start()
        logging.info("Engine started. Desktop URL=%s Phone URL=%s", f"http://127.0.0.1:{server.port}", server.address)

        api = DesktopApi(server, log_file)
        try:
            webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = False
            webview.settings["ALLOW_DOWNLOADS"] = False
        except Exception:
            pass
        left, top, right, bottom = get_work_area()
        work_width, work_height = max(760, right - left), max(520, bottom - top)
        requested_width = int(settings.get("desktop_width", 1420))
        requested_height = int(settings.get("desktop_height", 900))
        window_width = max(720, min(requested_width, work_width - 24))
        window_height = max(500, min(requested_height, work_height - 24))
        window_x = left + max(0, (work_width - window_width) // 2)
        window_y = top + max(0, (work_height - window_height) // 2)

        window = webview.create_window(
            title=f"{APP_NAME}  •  Responsive Validation Edition v{APP_VERSION}",
            url=f"http://127.0.0.1:{server.port}/?desktop=1",
            js_api=api,
            width=window_width,
            height=window_height,
            x=window_x,
            y=window_y,
            min_size=(720, 500),
            resizable=True,
            fullscreen=False,
            frameless=False,
            easy_drag=False,
            confirm_close=False,
            background_color="#07090d",
            text_select=True,
        )

        def on_loaded() -> None:
            try:
                window.evaluate_js(
                    "document.documentElement.classList.add('desktop-shell');"
                    "window.__AURAX_DESKTOP__ = true;"
                )
            except Exception:
                logging.exception("Could not mark desktop shell")

        window.events.loaded += on_loaded
        # pywebview selects Microsoft Edge WebView2 on modern Windows and keeps the
        # dashboard inside a real application window instead of opening a browser.
        webview.start(
            debug=False,
            private_mode=False,
            storage_path=str(root / "config" / "desktop-storage"),
        )
        return 0
    except Exception as exc:
        logging.error("Fatal desktop error: %s\n%s", exc, traceback.format_exc())
        show_error(
            f"{APP_NAME} could not start",
            f"{exc}\n\nA diagnostic log was saved to:\n{log_file}",
        )
        return 1
    finally:
        if server is not None:
            try:
                server.stop()
            except Exception:
                logging.exception("Server stop failed")
        if engine is not None:
            try:
                engine.stop()
            except Exception:
                logging.exception("Engine stop failed")
        if os.name == "nt" and mutex not in (None, 1):
            try:
                ctypes.windll.kernel32.ReleaseMutex(mutex)
                ctypes.windll.kernel32.CloseHandle(mutex)
            except Exception:
                pass


if __name__ == "__main__":
    raise SystemExit(main())
