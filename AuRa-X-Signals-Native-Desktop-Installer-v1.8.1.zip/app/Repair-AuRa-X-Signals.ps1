$ErrorActionPreference = 'Stop'
$InstallDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Python = Join-Path $InstallDir '.venv\Scripts\python.exe'
$PythonW = Join-Path $InstallDir '.venv\Scripts\pythonw.exe'
$Icon = Join-Path $InstallDir 'assets\aurax_signals.ico'
$StartMenuDir = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\AuRa X Signals'
$DesktopShortcut = Join-Path ([Environment]::GetFolderPath('Desktop')) 'AuRa X Signals.lnk'
function New-Shortcut([string]$Path, [string]$Target, [string]$Arguments) {
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($Path)
    $shortcut.TargetPath = $Target
    $shortcut.Arguments = $Arguments
    $shortcut.WorkingDirectory = $InstallDir
    $shortcut.IconLocation = "$Icon,0"
    $shortcut.Save()
}
Clear-Host
Write-Host 'Repairing AuRa X Signals...' -ForegroundColor Yellow
if (-not (Test-Path $Python)) { throw 'The application environment is missing. Run the full installer again.' }
& $Python -m pip install --disable-pip-version-check --upgrade -r (Join-Path $InstallDir 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw 'Dependency repair failed.' }
New-Item -ItemType Directory -Path $StartMenuDir -Force | Out-Null
$args = '"' + (Join-Path $InstallDir 'desktop_app.py') + '"'
New-Shortcut $DesktopShortcut $PythonW $args
New-Shortcut (Join-Path $StartMenuDir 'AuRa X Signals.lnk') $PythonW $args
try {
    Start-Process powershell.exe -Verb RunAs -Wait -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + (Join-Path $InstallDir 'Configure-Firewall.ps1') + '"'))
} catch {}
Write-Host 'Repair completed.' -ForegroundColor Green
Read-Host 'Press Enter to close'
