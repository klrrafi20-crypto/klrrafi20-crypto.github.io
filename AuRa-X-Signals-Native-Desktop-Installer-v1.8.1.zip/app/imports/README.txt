AuRa X Signals local COMEX bridge
=================================

The application watches these files:
- comex_trades.jsonl : executed futures trades
- comex_book.jsonl   : MBO/order-book add, modify, cancel and clear events

One JSON object per line. Do not place JSON arrays in these files.
Use the .sample.jsonl files as field examples.
Events already present when the app starts are skipped; only newly appended lines are consumed.
The upstream platform must provide legitimate exchange data entitlement.
