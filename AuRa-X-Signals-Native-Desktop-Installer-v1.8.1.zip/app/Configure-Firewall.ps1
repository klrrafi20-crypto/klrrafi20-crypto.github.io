$ErrorActionPreference = 'Stop'
$ruleName = 'AuRa X Signals Mobile'
try {
    Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
    New-NetFirewallRule -DisplayName $ruleName -Description 'Allows the AuRa X Signals Android app to read the local Windows dashboard.' -Direction Inbound -Action Allow -Protocol TCP -LocalPort '8787-8795' -Profile Private | Out-Null
    exit 0
} catch {
    Write-Error $_
    exit 1
}
