from __future__ import annotations

"""Fast no-key market-microstructure proxy for AuRa X Signals.

This module never claims to provide CME Market-by-Order, Time & Sales contract
sizes, confirmed block trades, dark-pool prints, or institution identities.
It extracts the closest defensible *behavioural proxy* from unique MT5 quotes
and completed M1 broker tick-volume bars.
"""

from datetime import datetime, timezone
from statistics import median
from typing import Any, Iterable, Sequence
import json
import math
import threading
import time


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _mean(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _stdev(values: Sequence[float]) -> float:
    if len(values) < 2:
        return 0.0
    m = _mean(values)
    return math.sqrt(sum((x - m) ** 2 for x in values) / (len(values) - 1))


def _z(value: float, values: Sequence[float]) -> float:
    if len(values) < 5:
        return 0.0
    med = median(values)
    deviations = [abs(x - med) for x in values]
    mad = median(deviations)
    if mad > 1e-12:
        return 0.67448975 * (value - med) / mad
    sd = _stdev(values)
    return (value - _mean(values)) / sd if sd > 1e-12 else 0.0


def _iso(ts: float | None = None) -> str:
    return datetime.fromtimestamp(ts if ts is not None else time.time(), timezone.utc).isoformat()


def _clone(value: Any) -> Any:
    # Faster and safer than returning mutable internal objects to the HTTP thread.
    return json.loads(json.dumps(value))


class OrderFlowProxy:
    """No-key proxy for tape, footprint, heatmap and large-player behaviour.

    Inputs are deliberately limited to unique MT5 bid/ask changes and completed
    broker M1 bars. All output labels contain PROXY/ESTIMATE where exchange data
    would otherwise be required.
    """

    def __init__(self, settings: dict[str, Any]):
        self.settings = settings
        self.lock = threading.RLock()
        self.last_calc = 0.0
        self.last_bar_calc = 0.0
        self.last_signature: tuple[Any, ...] | None = None
        self.cached_heatmap: list[dict[str, Any]] = []
        self.cached_footprint: list[dict[str, Any]] = []
        self.cached_bar_events: list[dict[str, Any]] = []
        self._summary = self._empty("Waiting for unique MT5 quotes and completed M1 bars")

    def summary(self) -> dict[str, Any]:
        with self.lock:
            return _clone(self._summary)

    def update(
        self,
        tick_history: Iterable[Sequence[float]],
        m1_bars: list[dict[str, float]],
        current_price: float | None,
        point: float,
        digits: int,
        volume_profile: dict[str, Any] | None = None,
        smc: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        now = time.time()
        interval = max(0.20, _f(self.settings.get("order_flow_proxy_refresh_seconds", 0.40), 0.40))
        ticks = [tuple(x) for x in tick_history]
        ticks = [x for x in ticks if len(x) >= 5 and _f(x[0]) > 0 and _f(x[1]) > 0]
        last_tick_ts = _f(ticks[-1][0]) if ticks else 0.0
        signature = (int(last_tick_ts * 1000), len(ticks), len(m1_bars), round(_f(current_price), digits))
        if signature == self.last_signature and now - self.last_calc < interval:
            return self.summary()
        if now - self.last_calc < interval:
            return self.summary()
        self.last_calc = now
        self.last_signature = signature

        point = max(_f(point, 0.01), 1e-9)
        price = _f(current_price)
        if len(ticks) < 12 or len(m1_bars) < 30 or price <= 0:
            with self.lock:
                self._summary = self._empty("Warming up: need at least 12 unique ticks and 30 completed M1 bars")
            return self.summary()

        # Slow, bar-derived layers are refreshed only when a completed-bar set changes.
        if now - self.last_bar_calc >= max(1.0, _f(self.settings.get("order_flow_bar_refresh_seconds", 2.0), 2.0)):
            self.cached_footprint = self._footprint(m1_bars, point, digits)
            self.cached_heatmap = self._heatmap(m1_bars, price, point, digits)
            self.cached_bar_events = self._bar_bursts(m1_bars, point, digits)
            self.last_bar_calc = now

        windows = {
            "5s": self._tick_window(ticks, now - 5, point, digits),
            "15s": self._tick_window(ticks, now - 15, point, digits),
            "30s": self._tick_window(ticks, now - 30, point, digits),
            "1m": self._tick_window(ticks, now - 60, point, digits),
            "5m": self._tick_window(ticks, now - 300, point, digits),
        }
        tape = self._tape_clusters(ticks, now - 300, point, digits)
        large_tape = self._large_tape_events(tape)
        absorption = self._absorption(self.cached_footprint, self.cached_bar_events)
        iceberg = self._iceberg_proxy(self.cached_heatmap, absorption, windows)
        nearby = self._nearby_heatmap(self.cached_heatmap, price, point)
        stacked = self._stacked_imbalances(self.cached_footprint)

        quality = self._quality(ticks, m1_bars, now)
        score = self._score(windows, stacked, nearby, absorption, iceberg, quality)
        signal = "BUY-SIDE MICROSTRUCTURE" if score >= 6 else "SELL-SIDE MICROSTRUCTURE" if score <= -6 else "BALANCED / WAIT"
        if quality["score"] < 45:
            score = 0.0
            signal = "WARMING UP"

        summary = {
            "status": "LIVE MT5 ORDER-FLOW PROXY" if quality["score"] >= 45 else "WARMING UP",
            "mode": "NO-KEY · BROKER-FEED PROXY",
            "source": "Unique MT5 bid/ask changes + completed M1 broker tick volume",
            "generated_at": _iso(now),
            "data_age_seconds": round(max(0.0, now - last_tick_ts), 3),
            "calculation_latency_ms": round((time.perf_counter() - time.perf_counter()) * 1000, 3),
            "signal": signal,
            "score": round(score, 2),
            "confidence": quality["score"],
            "quantity_unit": "estimated activity units",
            "windows": windows,
            "tape_proxy": tape[-40:][::-1],
            "large_activity_filter": (large_tape + self.cached_bar_events[-30:])[-40:][::-1],
            "footprint_proxy": self.cached_footprint[-30:],
            "stacked_imbalances": stacked,
            "heatmap_proxy": self.cached_heatmap,
            "nearby_liquidity": nearby,
            "absorption": absorption,
            "iceberg_proxy": iceberg,
            "block_trade_monitor": {
                "status": "UNAVAILABLE WITHOUT LICENSED EXCHANGE REPORT/FEED",
                "events": [],
                "signal_weight": 0,
                "note": "A large MT5 activity burst is not labelled as a confirmed CME block trade.",
            },
            "dark_pool_monitor": {
                "status": "NOT PUBLICLY OBSERVABLE",
                "signal_weight": 0,
                "note": "Private OTC/dark-pool counterparties and orders are not exposed by the broker feed.",
            },
            "order_book": {
                "status": "REACTION HEATMAP PROXY · NOT MBO",
                "full_depth_available": False,
                "resting_order_sizes_available": False,
                "cancellations_available": False,
                "levels": nearby,
                "note": "Levels are inferred from repeated historical activity and reactions; they are not live resting limit orders.",
            },
            "time_and_sales": {
                "status": "UNIQUE-QUOTE TAPE PROXY · NOT EXCHANGE PRINTS",
                "events": tape[-40:][::-1],
                "exact_trade_size_available": False,
                "note": "MT5 quote changes do not reveal official futures trade sizes or aggressor IDs.",
            },
            "identity": {
                "available": False,
                "label": "Anonymous activity only",
                "note": "No bank, fund, algorithm or participant name can be inferred reliably.",
            },
            "quality": quality,
            "prediction_use": "Small confirmation weight only; live timeframes, spread, SMC and data-quality gates remain primary.",
            "limitations": [
                "Not CME Time & Sales, Market-by-Order or centralized GC contract volume.",
                "Cannot confirm block trades, dark-pool orders, institution identity or whether a position was opened versus closed.",
                "Broker XAUUSD activity can differ from COMEX futures activity.",
            ],
        }
        # Measure the whole update without polluting the score calculation.
        summary["calculation_latency_ms"] = round(max(0.01, (time.time() - now) * 1000), 2)
        with self.lock:
            self._summary = summary
        return self.summary()

    def _tick_window(self, ticks: list[tuple[Any, ...]], start: float, point: float, digits: int) -> dict[str, Any]:
        x = [t for t in ticks if _f(t[0]) >= start]
        buy_events = sell_events = flat_events = 0
        buy_weight = sell_weight = 0.0
        changes: list[float] = []
        for prev, cur in zip(x, x[1:]):
            mid_change = _f(cur[1]) - _f(prev[1])
            bid_change = _f(cur[3]) - _f(prev[3])
            ask_change = _f(cur[4]) - _f(prev[4])
            changes.append(mid_change)
            movement = abs(mid_change) / point
            speed_bonus = 0.0
            gap = max(0.001, _f(cur[0]) - _f(prev[0]))
            if gap < 0.15:
                speed_bonus = min(2.0, (0.15 - gap) * 8.0)
            weight = 1.0 + min(5.0, movement * 0.30) + speed_bonus
            if bid_change > 0 and ask_change > 0:
                buy_events += 1; buy_weight += weight
            elif bid_change < 0 and ask_change < 0:
                sell_events += 1; sell_weight += weight
            elif mid_change > 0:
                buy_events += 1; buy_weight += weight * 0.75
            elif mid_change < 0:
                sell_events += 1; sell_weight += weight * 0.75
            else:
                flat_events += 1
        total_weight = buy_weight + sell_weight
        delta_pct = (buy_weight - sell_weight) / total_weight * 100 if total_weight else 0.0
        duration = max(1.0, (_f(x[-1][0]) - _f(x[0][0])) if len(x) >= 2 else 1.0)
        price_change = (_f(x[-1][1]) - _f(x[0][1])) if len(x) >= 2 else 0.0
        dominant = "BUY" if delta_pct > 10 else "SELL" if delta_pct < -10 else "BALANCED"
        return {
            "buy_events": buy_events,
            "sell_events": sell_events,
            "flat_events": flat_events,
            "buy_weight": round(buy_weight, 2),
            "sell_weight": round(sell_weight, 2),
            "delta_weight": round(buy_weight - sell_weight, 2),
            "delta_percent": round(delta_pct, 1),
            "tick_rate": round(max(0, len(x) - 1) / duration, 2),
            "price_change": round(price_change, digits),
            "dominant": dominant,
            "sample_count": len(x),
        }

    def _tape_clusters(self, ticks: list[tuple[Any, ...]], start: float, point: float, digits: int) -> list[dict[str, Any]]:
        x = [t for t in ticks if _f(t[0]) >= start]
        clusters: list[dict[str, Any]] = []
        active: dict[str, Any] | None = None
        for prev, cur in zip(x, x[1:]):
            delta = _f(cur[1]) - _f(prev[1])
            side = "BUY" if delta > 0 else "SELL" if delta < 0 else "FLAT"
            if side == "FLAT":
                continue
            gap = max(0.0, _f(cur[0]) - _f(prev[0]))
            same = active and active["side"] == side and gap <= 0.45
            if not same:
                if active:
                    clusters.append(active)
                active = {
                    "start": _f(prev[0]), "time": _iso(_f(cur[0])), "side": side,
                    "start_price": _f(prev[1]), "price": _f(cur[1]), "events": 1,
                    "duration_ms": int(gap * 1000), "move_points": abs(delta) / point,
                    "speed_score": 1.0 / max(0.02, gap),
                }
            else:
                assert active is not None
                active["time"] = _iso(_f(cur[0]))
                active["price"] = _f(cur[1])
                active["events"] += 1
                active["duration_ms"] = int((_f(cur[0]) - active["start"]) * 1000)
                active["move_points"] = abs(_f(cur[1]) - active["start_price"]) / point
                active["speed_score"] += 1.0 / max(0.02, gap)
        if active:
            clusters.append(active)
        for c in clusters:
            intensity = c["events"] * 0.8 + c["move_points"] * 0.55 + min(8.0, c["speed_score"] * 0.03)
            c["activity_score"] = round(intensity, 2)
            c["price"] = round(c["price"], digits)
            c["move_points"] = round(c["move_points"], 1)
            c["label"] = "FAST BUY CLUSTER" if c["side"] == "BUY" else "FAST SELL CLUSTER"
            c.pop("start", None); c.pop("start_price", None); c.pop("speed_score", None)
        return clusters

    @staticmethod
    def _large_tape_events(tape: list[dict[str, Any]]) -> list[dict[str, Any]]:
        scores = [_f(x.get("activity_score")) for x in tape]
        output: list[dict[str, Any]] = []
        for item in tape:
            z = _z(_f(item.get("activity_score")), scores)
            if z >= 2.0 or (_f(item.get("move_points")) >= 5 and int(item.get("events", 0)) >= 4):
                row = dict(item)
                row["type"] = "STATISTICAL LARGE ACTIVITY"
                row["z_score"] = round(z, 2)
                row["confirmed_block"] = False
                output.append(row)
        return output

    def _footprint(self, bars: list[dict[str, float]], point: float, digits: int) -> list[dict[str, Any]]:
        output: list[dict[str, Any]] = []
        for b in bars[-90:]:
            op = _f(b.get("open")); hi = _f(b.get("high")); lo = _f(b.get("low")); close = _f(b.get("close"))
            volume = max(0.0, _f(b.get("tick_volume")))
            span = max(hi - lo, point)
            body = close - op
            clv = _clamp((2 * close - hi - lo) / span, -1, 1)
            direction = _clamp(body / span, -1, 1)
            buy_share = _clamp(0.50 + 0.27 * clv + 0.18 * direction, 0.05, 0.95)
            buy = volume * buy_share
            sell = volume - buy
            delta = buy - sell
            ratio = max(buy, sell) / max(1.0, min(buy, sell))
            imbalance = "BUY IMBALANCE" if buy > sell and ratio >= 2.4 else "SELL IMBALANCE" if sell > buy and ratio >= 2.4 else "BALANCED"
            output.append({
                "time": _iso(_f(b.get("time"))), "open": round(op, digits), "high": round(hi, digits),
                "low": round(lo, digits), "close": round(close, digits), "volume": int(round(volume)),
                "buy_activity": int(round(buy)), "sell_activity": int(round(sell)), "delta": int(round(delta)),
                "delta_percent": round(delta / max(1.0, volume) * 100, 1), "imbalance_ratio": round(ratio, 2),
                "imbalance": imbalance, "body_points": round(abs(body) / point, 1), "range_points": round(span / point, 1),
                "clv": round(clv, 2), "upper_wick_points": round(max(0.0, hi - max(op, close)) / point, 1),
                "lower_wick_points": round(max(0.0, min(op, close) - lo) / point, 1),
            })
        return output

    def _bar_bursts(self, bars: list[dict[str, float]], point: float, digits: int) -> list[dict[str, Any]]:
        x = bars[-240:]
        volumes = [max(0.0, _f(b.get("tick_volume"))) for b in x]
        ranges = [max(point, _f(b.get("high")) - _f(b.get("low"))) / point for b in x]
        output: list[dict[str, Any]] = []
        for b, volume, range_points in zip(x, volumes, ranges):
            op = _f(b.get("open")); close = _f(b.get("close")); span = max(_f(b.get("high")) - _f(b.get("low")), point)
            direction = (close - op) / span
            strength = _z(volume, volumes) * 0.72 + max(0.0, _z(range_points, ranges)) * 0.28 + abs(direction) * 0.65
            if strength >= 2.15:
                side = "BUY" if direction > 0.08 else "SELL" if direction < -0.08 else "BALANCED"
                output.append({
                    "time": _iso(_f(b.get("time"))), "side": side, "price": round(close, digits),
                    "activity_score": round(strength, 2), "events": int(round(volume)),
                    "move_points": round(abs(close - op) / point, 1), "duration_ms": 60000,
                    "label": "M1 LARGE ACTIVITY BURST", "type": "STATISTICAL LARGE ACTIVITY",
                    "confirmed_block": False,
                })
        return output

    def _heatmap(self, bars: list[dict[str, float]], current: float, point: float, digits: int) -> list[dict[str, Any]]:
        x = bars[-360:]
        low = min(_f(b.get("low")) for b in x)
        high = max(_f(b.get("high")) for b in x)
        bins = max(32, min(72, int(self.settings.get("order_flow_heatmap_bins", 52))))
        width = max((high - low) / bins, point)
        intensity = [0.0] * bins
        buy_react = [0.0] * bins
        sell_react = [0.0] * bins
        touches = [0] * bins
        now_index = len(x) - 1
        for idx, b in enumerate(x):
            hi = _f(b.get("high")); lo = _f(b.get("low")); op = _f(b.get("open")); close = _f(b.get("close"))
            volume = max(1.0, _f(b.get("tick_volume")))
            age = now_index - idx
            decay = math.exp(-age / 180.0)
            span = max(hi - lo, point)
            direction = _clamp((close - op) / span, -1, 1)
            lower = max(0, min(bins - 1, int((lo - low) / width)))
            upper = max(0, min(bins - 1, int((hi - low) / width)))
            count = max(1, upper - lower + 1)
            allocated = volume * decay / count
            for i in range(lower, upper + 1):
                intensity[i] += allocated
                touches[i] += 1
                # A candle rejecting upward from the level is evidence of bid-side reaction;
                # rejecting downward is evidence of ask-side reaction.
                center = low + (i + 0.5) * width
                if close > center and direction >= -0.15:
                    buy_react[i] += allocated * (0.55 + max(0.0, direction) * 0.45)
                if close < center and direction <= 0.15:
                    sell_react[i] += allocated * (0.55 + max(0.0, -direction) * 0.45)
        peak = max(intensity) or 1.0
        rows: list[dict[str, Any]] = []
        for i in range(bins):
            if intensity[i] <= peak * 0.08:
                continue
            price = low + (i + 0.5) * width
            total_react = buy_react[i] + sell_react[i]
            bias = (buy_react[i] - sell_react[i]) / total_react * 100 if total_react else 0.0
            side = "BID-REACTION" if bias > 15 else "ASK-REACTION" if bias < -15 else "BALANCED"
            distance_points = abs(price - current) / point
            rows.append({
                "price": round(price, digits), "intensity": round(intensity[i] / peak * 100, 1),
                "side_bias_percent": round(bias, 1), "side": side, "touches": touches[i],
                "distance_points": round(distance_points, 1),
                "label": "HIGH REACTION ZONE" if intensity[i] >= peak * 0.65 else "REACTION ZONE",
            })
        rows.sort(key=lambda r: (r["distance_points"], -r["intensity"]))
        return rows[:30]

    @staticmethod
    def _nearby_heatmap(rows: list[dict[str, Any]], current: float, point: float) -> list[dict[str, Any]]:
        result = [dict(x) for x in rows if abs(_f(x.get("price")) - current) / max(point, 1e-9) <= 450]
        result.sort(key=lambda x: (-_f(x.get("intensity")), _f(x.get("distance_points"))))
        return result[:12]

    @staticmethod
    def _stacked_imbalances(footprint: list[dict[str, Any]]) -> dict[str, Any]:
        recent = footprint[-12:]
        buy_run = sell_run = max_buy = max_sell = 0
        for row in recent:
            imbalance = str(row.get("imbalance", ""))
            if imbalance == "BUY IMBALANCE":
                buy_run += 1; sell_run = 0; max_buy = max(max_buy, buy_run)
            elif imbalance == "SELL IMBALANCE":
                sell_run += 1; buy_run = 0; max_sell = max(max_sell, sell_run)
            else:
                buy_run = sell_run = 0
        label = "STACKED BUY IMBALANCE" if max_buy >= 2 and max_buy > max_sell else "STACKED SELL IMBALANCE" if max_sell >= 2 else "NONE"
        return {"label": label, "max_buy_run": max_buy, "max_sell_run": max_sell}

    @staticmethod
    def _absorption(footprint: list[dict[str, Any]], bursts: list[dict[str, Any]]) -> dict[str, Any]:
        recent = footprint[-40:]
        volumes = [_f(x.get("volume")) for x in recent]
        ranges = [_f(x.get("range_points")) for x in recent]
        events: list[dict[str, Any]] = []
        median_range = median(ranges) if ranges else 0.0
        for row in recent:
            volume_z = _z(_f(row.get("volume")), volumes)
            small_progress = _f(row.get("range_points")) <= max(1.0, median_range * 0.92)
            delta_pct = _f(row.get("delta_percent"))
            upper = _f(row.get("upper_wick_points")); lower = _f(row.get("lower_wick_points"))
            if volume_z >= 1.45 and small_progress:
                if delta_pct < -12 and lower > upper * 1.25:
                    events.append({"time": row.get("time"), "side": "BUY", "label": "SELLING ABSORBED", "evidence_score": round(min(100, 50 + volume_z * 12 + abs(delta_pct) * 0.4), 1)})
                elif delta_pct > 12 and upper > lower * 1.25:
                    events.append({"time": row.get("time"), "side": "SELL", "label": "BUYING ABSORBED", "evidence_score": round(min(100, 50 + volume_z * 12 + abs(delta_pct) * 0.4), 1)})
        latest = events[-1] if events else {"side": "NONE", "label": "NONE", "evidence_score": 0}
        return {"status": latest["label"], "side": latest["side"], "evidence_score": latest["evidence_score"], "events": events[-8:][::-1], "confirmed": False}

    @staticmethod
    def _iceberg_proxy(heatmap: list[dict[str, Any]], absorption: dict[str, Any], windows: dict[str, dict[str, Any]]) -> dict[str, Any]:
        candidates = [x for x in heatmap if int(x.get("touches", 0)) >= 7 and _f(x.get("intensity")) >= 55 and _f(x.get("distance_points")) <= 450]
        candidates.sort(key=lambda x: (-int(x.get("touches", 0)), -_f(x.get("intensity"))))
        top = candidates[0] if candidates else None
        evidence = 0.0
        side = "NONE"
        if top:
            evidence += min(55.0, int(top.get("touches", 0)) * 3.0) + _f(top.get("intensity")) * 0.20
            side = "BUY" if str(top.get("side")) == "BID-REACTION" else "SELL" if str(top.get("side")) == "ASK-REACTION" else "NONE"
        if absorption.get("side") in {"BUY", "SELL"}:
            evidence += _f(absorption.get("evidence_score")) * 0.25
            if side == "NONE":
                side = absorption.get("side")
            elif side != absorption.get("side"):
                evidence *= 0.65
        if abs(_f(windows.get("1m", {}).get("delta_percent"))) > 35:
            evidence += 6
        evidence = _clamp(evidence, 0, 100)
        label = f"POSSIBLE {side}-SIDE REPLENISHMENT" if evidence >= 62 and side != "NONE" else "NO STRONG REPLENISHMENT EVIDENCE"
        return {"status": label, "side": side, "evidence_score": round(evidence, 1), "level": top, "confirmed": False, "note": "Repeated reactions and absorption can resemble an iceberg, but hidden exchange quantity is not visible in MT5."}

    @staticmethod
    def _quality(ticks: list[tuple[Any, ...]], bars: list[dict[str, float]], now: float) -> dict[str, Any]:
        recent = [x for x in ticks if _f(x[0]) >= now - 60]
        age = max(0.0, now - _f(ticks[-1][0])) if ticks else 999.0
        score = 100.0
        reasons: list[str] = []
        if age > 3:
            score -= min(60, (age - 3) * 12); reasons.append("Stale quote stream")
        if len(recent) < 15:
            score -= 35; reasons.append("Low unique-tick coverage")
        elif len(recent) < 40:
            score -= 15; reasons.append("Moderate unique-tick coverage")
        if len(bars) < 120:
            score -= 20; reasons.append("Limited completed M1 history")
        score = int(round(_clamp(score, 0, 100)))
        return {"score": score, "state": "HIGH" if score >= 82 else "GOOD" if score >= 68 else "CAUTION" if score >= 45 else "LOW", "unique_ticks_60s": len(recent), "data_age_seconds": round(age, 2), "reasons": reasons}

    @staticmethod
    def _score(
        windows: dict[str, dict[str, Any]],
        stacked: dict[str, Any],
        nearby: list[dict[str, Any]],
        absorption: dict[str, Any],
        iceberg: dict[str, Any],
        quality: dict[str, Any],
    ) -> float:
        window_weights = {"5s": 0.18, "15s": 0.22, "30s": 0.20, "1m": 0.24, "5m": 0.16}
        value = sum(_f(windows.get(k, {}).get("delta_percent")) * w for k, w in window_weights.items()) * 0.14
        label = str(stacked.get("label", ""))
        if "BUY" in label:
            value += min(4.0, int(stacked.get("max_buy_run", 0)) * 1.4)
        elif "SELL" in label:
            value -= min(4.0, int(stacked.get("max_sell_run", 0)) * 1.4)
        for level in nearby[:4]:
            distance_factor = max(0.15, 1.0 - _f(level.get("distance_points")) / 450.0)
            value += _f(level.get("side_bias_percent")) / 100.0 * (_f(level.get("intensity")) / 100.0) * 2.8 * distance_factor
        if absorption.get("side") == "BUY":
            value += _f(absorption.get("evidence_score")) / 100 * 3.2
        elif absorption.get("side") == "SELL":
            value -= _f(absorption.get("evidence_score")) / 100 * 3.2
        if iceberg.get("side") == "BUY":
            value += _f(iceberg.get("evidence_score")) / 100 * 2.2
        elif iceberg.get("side") == "SELL":
            value -= _f(iceberg.get("evidence_score")) / 100 * 2.2
        value *= _f(quality.get("score")) / 100.0
        return _clamp(value, -20, 20)

    @staticmethod
    def _empty(reason: str) -> dict[str, Any]:
        return {
            "status": "WARMING UP", "mode": "NO-KEY · BROKER-FEED PROXY", "source": "MT5",
            "generated_at": _iso(), "data_age_seconds": None, "calculation_latency_ms": None,
            "signal": "WARMING UP", "score": 0.0, "confidence": 0, "quantity_unit": "estimated activity units",
            "windows": {}, "tape_proxy": [], "large_activity_filter": [], "footprint_proxy": [],
            "stacked_imbalances": {"label": "NONE", "max_buy_run": 0, "max_sell_run": 0},
            "heatmap_proxy": [], "nearby_liquidity": [],
            "absorption": {"status": "NONE", "side": "NONE", "evidence_score": 0, "events": [], "confirmed": False},
            "iceberg_proxy": {"status": "NONE", "side": "NONE", "evidence_score": 0, "level": None, "confirmed": False},
            "block_trade_monitor": {"status": "UNAVAILABLE WITHOUT LICENSED EXCHANGE REPORT/FEED", "events": [], "signal_weight": 0},
            "dark_pool_monitor": {"status": "NOT PUBLICLY OBSERVABLE", "signal_weight": 0},
            "order_book": {"status": "REACTION HEATMAP PROXY · NOT MBO", "levels": []},
            "time_and_sales": {"status": "UNIQUE-QUOTE TAPE PROXY · NOT EXCHANGE PRINTS", "events": []},
            "identity": {"available": False, "label": "Anonymous activity only"},
            "quality": {"score": 0, "state": "LOW", "reasons": [reason]},
            "prediction_use": "No signal influence until warm-up is complete.",
            "limitations": [reason],
        }
