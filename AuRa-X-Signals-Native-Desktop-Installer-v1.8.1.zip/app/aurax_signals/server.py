from __future__ import annotations

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
import json
import mimetypes
import socket
import threading

from .engine import AuRaSignalsEngine


def local_ip() -> str:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        return sock.getsockname()[0]
    except OSError:
        try:
            return socket.gethostbyname(socket.gethostname())
        except OSError:
            return "127.0.0.1"
    finally:
        sock.close()


class SignalsServer:
    def __init__(self, root: str | Path, engine: AuRaSignalsEngine, port: int = 8787):
        self.root = Path(root)
        self.web = self.root / "web"
        self.engine = engine
        self.port = port
        self.httpd: ThreadingHTTPServer | None = None
        self.thread: threading.Thread | None = None

    @property
    def address(self) -> str:
        return f"http://{local_ip()}:{self.port}"

    def start(self) -> None:
        parent = self

        class Handler(BaseHTTPRequestHandler):
            def _common(self, status: int, content_type: str) -> None:
                self.send_response(status)
                self.send_header("Content-Type", content_type)
                self.send_header("Cache-Control", "no-store")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                self.send_header("Access-Control-Allow-Headers", "Content-Type, X-AuRa-Token")
                self.end_headers()

            def _json(self, payload: dict, status: int = 200) -> None:
                self._common(status, "application/json; charset=utf-8")
                self.wfile.write(json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8"))

            def _read_json(self) -> dict | list:
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length <= 0 or length > 2_000_000:
                    raise ValueError("Request body is missing or too large")
                return json.loads(self.rfile.read(length).decode("utf-8"))

            def _authorized_ingest(self) -> bool:
                if not parent.engine.settings.get("pro_flow_ingest_enabled", True):
                    return False
                expected = str(parent.engine.settings.get("pro_flow_ingest_token", "")).strip()
                if expected:
                    return self.headers.get("X-AuRa-Token", "") == expected
                host = self.client_address[0]
                return host in {"127.0.0.1", "::1"}

            def do_OPTIONS(self):
                self._common(204, "text/plain")

            def do_POST(self):
                path = urlparse(self.path).path
                if path == "/api/v1/institution/refresh":
                    return self._json(parent.engine.institution_intelligence.request_refresh())
                if path == "/api/v1/lbma/refresh":
                    return self._json({"ok": True, "lbma": parent.engine.global_gold_flow.lbma.refresh()})
                trade_paths = {"/api/v1/pro-flow/trade", "/api/v1/pro-flow/trades", "/api/pro-flow/trade", "/api/v1/comex/trade", "/api/v1/comex/trades"}
                book_paths = {"/api/v1/comex/book", "/api/v1/comex/books", "/api/v1/pro-flow/book"}
                if path not in trade_paths | book_paths:
                    return self._json({"ok": False, "error": "Endpoint not found"}, 404)
                if not self._authorized_ingest():
                    return self._json({"ok": False, "error": "Unauthorized pro-flow ingest"}, 401)
                try:
                    payload = self._read_json()
                    if path in book_paths:
                        if isinstance(payload, list):
                            result = parent.engine.pro_flow.ingest_book_many(payload)
                        elif isinstance(payload, dict) and isinstance(payload.get("events"), list):
                            result = parent.engine.pro_flow.ingest_book_many(payload["events"])
                        elif isinstance(payload, dict):
                            result = parent.engine.pro_flow.ingest_book(payload)
                        else:
                            raise ValueError("Expected one book event or an array of book events")
                    elif isinstance(payload, list):
                        result = parent.engine.pro_flow.ingest_many(payload)
                    elif isinstance(payload, dict) and isinstance(payload.get("trades"), list):
                        result = parent.engine.pro_flow.ingest_many(payload["trades"])
                    elif isinstance(payload, dict):
                        result = parent.engine.pro_flow.ingest(payload)
                    else:
                        raise ValueError("Expected one trade object or an array of trades")
                    return self._json({"ok": True, **result})
                except Exception as exc:
                    return self._json({"ok": False, "error": str(exc)}, 400)

            def do_GET(self):
                path = urlparse(self.path).path
                if path in {"/api/health", "/api/v1/health"}:
                    return self._json(parent.engine.health())
                if path in {"/api/v1/dashboard", "/api/dashboard"}:
                    return self._json(parent.engine.snapshot())
                if path in {"/api/v1/pro-flow", "/api/pro-flow"}:
                    current = parent.engine.last_tick.get("mid") if parent.engine.last_tick else None
                    return self._json({"ok": True, "pro_flow": parent.engine.pro_flow.summary(current)})
                if path in {"/api/v1/institution", "/api/institution"}:
                    return self._json({"ok": True, "intelligence": parent.engine.institution_intelligence.summary()})
                if path in {"/api/v1/order-flow", "/api/order-flow"}:
                    return self._json({"ok": True, "order_flow": parent.engine.order_flow_proxy.summary()})
                if path in {"/api/v1/global-flow", "/api/global-flow"}:
                    snap = parent.engine.snapshot()
                    return self._json({"ok": True, "global_flow": (snap.get("institutional") or {}).get("global_gold_flow", {})})
                if path in {"/api/v1/validation", "/api/validation"}:
                    return self._json({"ok": True, "validation": parent.engine.signal_validation.summary(parent.engine.snapshot())})
                if path in {"/api/v1/validation/export.csv", "/api/validation/export.csv"}:
                    payload = parent.engine.signal_validation.export_csv().encode("utf-8-sig")
                    self.send_response(200)
                    self.send_header("Content-Type", "text/csv; charset=utf-8")
                    self.send_header("Content-Disposition", 'attachment; filename="AuRa-X-Signals-Paper-Journal.csv"')
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.send_header("Content-Length", str(len(payload)))
                    self.end_headers()
                    self.wfile.write(payload)
                    return
                if path in {"/api/v1/lbma", "/api/lbma"}:
                    return self._json({"ok": True, "lbma": parent.engine.global_gold_flow.lbma.summary()})
                if path in {"/api/v1/comex/status", "/api/comex/status"}:
                    current = parent.engine.last_tick.get("mid") if parent.engine.last_tick else None
                    return self._json({"ok": True, "exchange": parent.engine.pro_flow.exchange_summary(current), "mt5_connector": parent.engine.global_gold_flow.mt5_comex.summary(), "file_bridge": parent.engine.global_gold_flow.file_bridge.summary()})
                if path == "/api/v1/sources":
                    snap = parent.engine.snapshot()
                    return self._json({"ok": True, "institutional": snap.get("institutional"), "smart_money": snap.get("smart_money")})
                if path == "/":
                    path = "/index.html"
                candidate = (parent.web / path.lstrip("/")).resolve()
                try:
                    candidate.relative_to(parent.web.resolve())
                except ValueError:
                    return self._json({"ok": False, "error": "Not found"}, 404)
                if not candidate.is_file():
                    return self._json({"ok": False, "error": "Endpoint not found"}, 404)
                content_type = mimetypes.guess_type(candidate.name)[0] or "application/octet-stream"
                self._common(200, content_type + ("; charset=utf-8" if content_type.startswith("text/") or content_type in {"application/javascript", "application/json"} else ""))
                self.wfile.write(candidate.read_bytes())

            def log_message(self, *_args):
                return

        requested_port = int(self.port)
        last_error: OSError | None = None
        for candidate_port in range(requested_port, requested_port + 9):
            try:
                self.httpd = ThreadingHTTPServer(("0.0.0.0", candidate_port), Handler)
                break
            except OSError as exc:
                last_error = exc
                self.httpd = None
        if self.httpd is None:
            raise RuntimeError(f"Could not open dashboard ports {requested_port}-{requested_port + 8}: {last_error}")
        self.port = int(self.httpd.server_address[1])
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True, name="aurax-signals-http")
        self.thread.start()

    def stop(self) -> None:
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
        self.httpd = None
        self.thread = None
