from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from statistics import median
from typing import Any, Iterable, Sequence
import math
import threading
import time


def as_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def iso_utc(ts: float | None = None) -> str:
    return datetime.fromtimestamp(ts if ts is not None else time.time(), timezone.utc).isoformat()


def mean(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def stdev(values: Sequence[float]) -> float:
    if len(values) < 2:
        return 0.0
    m = mean(values)
    return math.sqrt(sum((x - m) ** 2 for x in values) / (len(values) - 1))


def robust_z(value: float, values: Sequence[float]) -> float:
    if len(values) < 8:
        sd = stdev(values)
        return (value - mean(values)) / sd if sd > 1e-12 else 0.0
    med = median(values)
    mad = median([abs(x - med) for x in values])
    if mad > 1e-12:
        return 0.67448975 * (value - med) / mad
    sd = stdev(values)
    return (value - mean(values)) / sd if sd > 1e-12 else 0.0


def _tick_parts(tick: Sequence[float]) -> tuple[float, float, float, float, float]:
    ts = as_float(tick[0]) if len(tick) > 0 else 0.0
    mid = as_float(tick[1]) if len(tick) > 1 else 0.0
    spread = as_float(tick[2]) if len(tick) > 2 else 0.0
    bid = as_float(tick[3], mid) if len(tick) > 3 else mid
    ask = as_float(tick[4], mid) if len(tick) > 4 else mid
    return ts, mid, spread, bid, ask


class LocalFlowEstimator:
    """No-key professional-activity estimator built only from MT5 data.

    The estimator deliberately uses the words *estimate*, *activity*, and
    *proxy*. It cannot know centralized COMEX contracts, MBO queues, block
    trades, or participant names from an OTC/CFD broker feed.
    """

    def __init__(self, root: str | Path, settings: dict[str, Any]):
        self.root = Path(root)
        self.settings = settings
        self.lock = threading.RLock()
        self._summary = self._empty("Waiting for unique MT5 ticks and completed M1 bars")

    def update(
        self,
        tick_history: Iterable[Sequence[float]],
        frame_bars: dict[str, list[dict[str, float]]],
        volume_profile: dict[str, Any],
        smc: dict[str, Any],
        current_price: float | None,
        point: float,
        digits: int,
        frames: dict[str, dict[str, Any]] | None = None,
    ) -> None:
        now = time.time()
        ticks = [_tick_parts(x) for x in tick_history]
        ticks = [x for x in ticks if x[0] > 0 and x[1] > 0]
        bars = list(frame_bars.get("M1") or [])
        current = as_float(current_price)
        point = max(as_float(point, 0.01), 1e-9)
        if not bars or current <= 0:
            with self.lock:
                self._summary = self._empty("Waiting for completed M1 history")
            return

        analysed = self._analyse_bars(bars, point)
        tick_windows = {
            "1m": self._tick_window(ticks, now - 60, point),
            "5m": self._tick_window(ticks, now - 300, point),
            "15m": self._tick_window(ticks, now - 900, point),
        }
        windows = {
            "1m": self._combined_window(analysed[-1:], tick_windows["1m"], 0.40),
            "5m": self._combined_window(analysed[-5:], tick_windows["5m"], 0.30),
            "15m": self._combined_window(analysed[-15:], tick_windows["15m"], 0.20),
            "1h": self._combined_window(analysed[-60:], None, 0.0),
        }

        today_start = datetime.fromtimestamp(now, timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
        today_items = [x for x in analysed if x["time"] >= today_start] or analysed[-min(480, len(analysed)):]
        today = self._combined_window(today_items, tick_windows["15m"], 0.08)

        baseline = analysed[-min(360, len(analysed)):]
        volumes = [x["volume"] for x in baseline if x["volume"] > 0]
        ranges = [x["span_points"] for x in baseline if x["span_points"] > 0]
        efforts: list[dict[str, Any]] = []
        threshold = as_float(self.settings.get("local_flow_burst_z", 2.25), 2.25)
        for item in baseline:
            vz = robust_z(item["volume"], volumes)
            rz = robust_z(item["span_points"], ranges)
            body_quality = item["body_ratio"] * 0.8 + abs(item["clv"]) * 0.2
            strength = vz * 0.68 + max(0.0, rz) * 0.20 + body_quality * 0.75
            item["volume_z"] = vz
            item["range_z"] = rz
            item["burst_strength"] = strength
            if strength >= threshold and item["volume"] > 0:
                efforts.append(item)

        patterns = self._patterns(baseline, efforts, point)
        liquidity = self._liquidity_map(volume_profile, smc, current, digits)
        vwap = self._session_vwap(today_items, current, digits)
        quality = self._quality(ticks, bars, now, point)
        score = self._score(windows, patterns, volume_profile, smc, frames or {}, vwap, quality)
        signal = "EST. PRO BUY" if score >= 10 else "EST. PRO SELL" if score <= -10 else "BALANCED"
        if quality["score"] < 45:
            signal = "WARMING UP"
            score = 0.0

        recent = [self._event(x, digits) for x in efforts[-20:]][::-1]
        buy_bursts = [x for x in efforts if x["side"] == "BUY" and x["time"] >= today_start]
        sell_bursts = [x for x in efforts if x["side"] == "SELL" and x["time"] >= today_start]
        last_tick_ts = ticks[-1][0] if ticks else 0.0
        age = max(0.0, now - last_tick_ts) if last_tick_ts else None

        summary = {
            "status": "LIVE MT5 ESTIMATE" if quality["score"] >= 45 else "WARMING UP",
            "quality": "NO-KEY · BROKER-FEED ESTIMATE",
            "source": "MT5 unique ticks + completed M1 tick volume",
            "provider": "LOCAL NO-KEY ENGINE",
            "signal": signal,
            "score": round(score, 1),
            "data_age_seconds": round(age, 2) if age is not None else None,
            "generated_at": iso_utc(now),
            "session_definition": "Current UTC day from available MT5 history",
            "large_trade_threshold": round(threshold, 2),
            "threshold_unit": "robust activity z-score",
            "quantity_unit": "estimated broker activity units",
            "today": self._legacy_window(today, len(buy_bursts), len(sell_bursts), buy_bursts, sell_bursts),
            "windows": {name: self._legacy_window(value) for name, value in windows.items()},
            "patterns": patterns,
            "order_book": liquidity,
            "liquidity_map": liquidity,
            "session_vwap": vwap,
            "recent_large_trades": recent,
            "activity_bursts": recent,
            "block_trades": [],
            "data_quality": quality,
            "identity": {
                "available": False,
                "label": "Anonymous professional-style activity estimate",
                "note": "The no-key feed cannot reveal bank, hedge-fund, or individual trader names. Large activity means statistically unusual broker-feed pressure, not a confirmed institution.",
            },
            "exchange_status": "OPTIONAL · NOT REQUIRED",
            "limitations": [
                "Not exact COMEX contract quantity or centralized order flow.",
                "No genuine Market-by-Order queue, cancellations, or block-trade classification without an exchange feed.",
                "Different brokers can have different XAUUSD tick activity.",
            ],
            "note": "This high-speed no-key mode is a confirmation layer. It becomes safer by refusing low-quality conditions, not by pretending estimates are exact institutional trades.",
            "error": "",
        }
        with self.lock:
            self._summary = summary

    def summary(self) -> dict[str, Any]:
        with self.lock:
            return self._clone(self._summary)

    @staticmethod
    def _clone(value: Any) -> Any:
        if isinstance(value, dict):
            return {k: LocalFlowEstimator._clone(v) for k, v in value.items()}
        if isinstance(value, list):
            return [LocalFlowEstimator._clone(v) for v in value]
        return value

    @staticmethod
    def _analyse_bars(bars: list[dict[str, float]], point: float) -> list[dict[str, Any]]:
        output: list[dict[str, Any]] = []
        for b in bars:
            op = as_float(b.get("open")); hi = as_float(b.get("high")); lo = as_float(b.get("low")); close = as_float(b.get("close"))
            volume = max(0.0, as_float(b.get("tick_volume")))
            span = max(hi - lo, point)
            body = close - op
            body_ratio = clamp(abs(body) / span, 0.0, 1.0)
            clv = clamp((2.0 * close - hi - lo) / span, -1.0, 1.0)
            direction = clamp(body / span, -1.0, 1.0)
            # Direction plus close-location gives a smoother split than assigning an entire candle to one side.
            buy_share = clamp(0.50 + 0.26 * clv + 0.18 * direction, 0.06, 0.94)
            buy = volume * buy_share
            sell = volume - buy
            output.append({
                "time": as_float(b.get("time")), "open": op, "high": hi, "low": lo, "close": close,
                "volume": volume, "buy": buy, "sell": sell, "net": buy - sell,
                "side": "BUY" if buy - sell > volume * 0.04 else "SELL" if sell - buy > volume * 0.04 else "BALANCED",
                "body_ratio": body_ratio, "clv": clv, "span": span, "span_points": span / point,
                "upper_wick": max(0.0, hi - max(op, close)), "lower_wick": max(0.0, min(op, close) - lo),
            })
        return output

    @staticmethod
    def _tick_window(ticks: list[tuple[float, float, float, float, float]], start: float, point: float) -> dict[str, Any]:
        selected = [x for x in ticks if x[0] >= start]
        buy = sell = flat = 0.0
        buy_count = sell_count = flat_count = 0
        for prev, cur in zip(selected, selected[1:]):
            _, p_mid, p_spread, p_bid, p_ask = prev
            _, c_mid, c_spread, c_bid, c_ask = cur
            bid_delta = c_bid - p_bid
            ask_delta = c_ask - p_ask
            mid_delta = c_mid - p_mid
            move_points = abs(mid_delta) / point
            weight = 1.0 + min(5.0, move_points * 0.22)
            if c_spread > max(p_spread * 1.8, p_spread + 15):
                weight *= 0.55
            if bid_delta > 0 and ask_delta > 0:
                buy += weight; buy_count += 1
            elif bid_delta < 0 and ask_delta < 0:
                sell += weight; sell_count += 1
            elif mid_delta > 0:
                buy += weight * 0.8; buy_count += 1
            elif mid_delta < 0:
                sell += weight * 0.8; sell_count += 1
            else:
                flat += 1.0; flat_count += 1
        directional = buy + sell
        delta = buy - sell
        return {
            "buy": buy, "sell": sell, "flat": flat, "net": delta,
            "delta_percent": delta / directional * 100 if directional else 0.0,
            "buy_count": buy_count, "sell_count": sell_count, "flat_count": flat_count,
            "events": max(0, len(selected) - 1),
        }

    @staticmethod
    def _combined_window(items: list[dict[str, Any]], ticks: dict[str, Any] | None, tick_weight: float) -> dict[str, Any]:
        buy = sum(as_float(x.get("buy")) for x in items)
        sell = sum(as_float(x.get("sell")) for x in items)
        if ticks and ticks.get("events", 0) > 0:
            bar_total = max(1.0, buy + sell)
            tick_total = max(1.0, as_float(ticks.get("buy")) + as_float(ticks.get("sell")))
            scale = bar_total / tick_total * tick_weight
            buy += as_float(ticks.get("buy")) * scale
            sell += as_float(ticks.get("sell")) * scale
        directional = buy + sell
        net = buy - sell
        delta_pct = net / directional * 100 if directional else 0.0
        return {
            "buy": buy, "sell": sell, "net": net, "delta_percent": delta_pct,
            "dominant": "EST. BUY" if delta_pct >= 8 else "EST. SELL" if delta_pct <= -8 else "BALANCED",
        }

    @staticmethod
    def _legacy_window(value: dict[str, Any], buy_count: int = 0, sell_count: int = 0, buy_items: list[dict[str, Any]] | None = None, sell_items: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        buy = as_float(value.get("buy")); sell = as_float(value.get("sell")); net = as_float(value.get("net")); delta = as_float(value.get("delta_percent"))
        buy_items = buy_items or []; sell_items = sell_items or []
        return {
            "buy_contracts": int(round(buy)), "sell_contracts": int(round(sell)), "unknown_contracts": 0,
            "net_delta": int(round(net)), "delta_percent": round(delta, 1),
            "buy_trades": buy_count, "sell_trades": sell_count, "unknown_trades": 0,
            "largest_buy": int(round(max((as_float(x.get("volume")) for x in buy_items), default=0.0))),
            "largest_sell": int(round(max((as_float(x.get("volume")) for x in sell_items), default=0.0))),
            "dominant": value.get("dominant", "BALANCED"),
            "score": round(clamp(delta * 0.30, -30.0, 30.0), 1),
        }

    @staticmethod
    def _patterns(items: list[dict[str, Any]], bursts: list[dict[str, Any]], point: float) -> dict[str, Any]:
        recent = items[-15:]
        recent_bursts = [x for x in bursts if x in recent]
        buys = sum(1 for x in recent_bursts if x["side"] == "BUY")
        sells = sum(1 for x in recent_bursts if x["side"] == "SELL")
        cluster = "EST. BUY CLUSTER" if buys >= 3 and buys > sells else "EST. SELL CLUSTER" if sells >= 3 and sells > buys else "NONE"

        absorption = "NONE"
        for x in reversed(recent):
            if as_float(x.get("volume_z")) < 1.6:
                continue
            effort_no_result = x["body_ratio"] <= 0.28 or as_float(x.get("range_z")) < -0.25
            if not effort_no_result:
                continue
            if x["lower_wick"] > x["upper_wick"] * 1.5 and x["lower_wick"] > point * 4:
                absorption = "POSSIBLE BUY ABSORPTION"; break
            if x["upper_wick"] > x["lower_wick"] * 1.5 and x["upper_wick"] > point * 4:
                absorption = "POSSIBLE SELL ABSORPTION"; break
            absorption = "POSSIBLE TWO-WAY ABSORPTION"; break

        repeated = "NOT CONFIRMABLE"
        candidates = [x for x in recent[-10:] if as_float(x.get("volume_z")) >= 1.2 and x["body_ratio"] <= 0.30]
        if len(candidates) >= 3:
            net = sum(as_float(x.get("net")) for x in candidates)
            repeated = "POSSIBLE BUY REPLENISHMENT" if net > 0 else "POSSIBLE SELL REPLENISHMENT" if net < 0 else "POSSIBLE REPEATED ABSORPTION"
        return {
            "cluster": cluster, "absorption": absorption, "iceberg": repeated,
            "note": "These are statistical price/tick-volume patterns. Iceberg orders cannot be confirmed without centralized order-book data.",
        }

    @staticmethod
    def _liquidity_map(volume_profile: dict[str, Any], smc: dict[str, Any], current: float, digits: int) -> dict[str, Any]:
        nodes = list(volume_profile.get("high_volume_nodes") or [])
        below = sorted((n for n in nodes if as_float(n.get("price")) <= current), key=lambda n: as_float(n.get("price")), reverse=True)[:3]
        above = sorted((n for n in nodes if as_float(n.get("price")) >= current), key=lambda n: as_float(n.get("price")))[:3]
        bid_total = sum(as_float(x.get("share")) for x in below)
        ask_total = sum(as_float(x.get("share")) for x in above)
        total = bid_total + ask_total
        imbalance = (bid_total - ask_total) / total * 100 if total else 0.0
        bid_walls = [{"price": round(as_float(x.get("price")), digits), "contracts": round(as_float(x.get("share")), 1), "instrument_id": "HVN", "label": "High-activity support zone"} for x in below]
        ask_walls = [{"price": round(as_float(x.get("price")), digits), "contracts": round(as_float(x.get("share")), 1), "instrument_id": "HVN", "label": "High-activity resistance zone"} for x in above]
        return {
            "status": "PRICE/VOLUME ZONE MAP", "data_age_seconds": None,
            "bid_wall_contracts": round(bid_total, 1), "ask_wall_contracts": round(ask_total, 1),
            "resting_imbalance_percent": round(imbalance, 1),
            "bid_walls": bid_walls, "ask_walls": ask_walls,
            "large_cancels_60s": None, "spoof_warning": "UNAVAILABLE WITHOUT MBO",
            "score": round(clamp(imbalance * 0.08, -8, 8), 1),
            "note": "These are volume-profile and swing-liquidity reaction zones, not visible resting exchange orders.",
        }

    @staticmethod
    def _session_vwap(items: list[dict[str, Any]], current: float, digits: int) -> dict[str, Any]:
        weighted = 0.0; volume = 0.0; prices: list[tuple[float, float]] = []
        for x in items:
            typical = (x["high"] + x["low"] + x["close"]) / 3.0
            v = max(1.0, x["volume"])
            weighted += typical * v; volume += v; prices.append((typical, v))
        vwap = weighted / volume if volume else current
        variance = sum(v * (p - vwap) ** 2 for p, v in prices) / volume if volume else 0.0
        sigma = math.sqrt(max(0.0, variance))
        location = "ABOVE VWAP" if current > vwap + sigma * 0.15 else "BELOW VWAP" if current < vwap - sigma * 0.15 else "AT VWAP"
        return {
            "vwap": round(vwap, digits), "upper_1sd": round(vwap + sigma, digits), "lower_1sd": round(vwap - sigma, digits),
            "location": location, "distance": round(current - vwap, digits),
        }

    @staticmethod
    def _quality(ticks: list[tuple[float, float, float, float, float]], bars: list[dict[str, float]], now: float, point: float) -> dict[str, Any]:
        recent60 = [x for x in ticks if x[0] >= now - 60]
        recent10 = [x for x in ticks if x[0] >= now - 10]
        tick_age = max(0.0, now - ticks[-1][0]) if ticks else 999.0
        spreads = [x[2] for x in recent60 if x[2] >= 0]
        spread_med = median(spreads) if spreads else 0.0
        spread_now = ticks[-1][2] if ticks else 0.0
        spread_ratio = spread_now / spread_med if spread_med > 0 else 1.0
        score = 100.0
        reasons: list[str] = []
        if tick_age > 3: score -= min(45.0, (tick_age - 3) * 8); reasons.append("Tick stream is delayed")
        if len(recent60) < 20: score -= 28; reasons.append("Low unique-tick sample count")
        elif len(recent60) < 60: score -= 12; reasons.append("Moderate unique-tick sample count")
        if len(recent10) < 3: score -= 18; reasons.append("Very low current activity")
        if spread_ratio > 2.2: score -= 25; reasons.append("Spread is unstable versus its 60-second median")
        if len(bars) < 180: score -= 20; reasons.append("Limited M1 history")
        score = clamp(score, 0.0, 100.0)
        state = "HIGH" if score >= 80 else "GOOD" if score >= 65 else "CAUTION" if score >= 45 else "LOW"
        return {
            "score": round(score, 0), "state": state, "unique_ticks_60s": len(recent60), "unique_ticks_10s": len(recent10),
            "tick_age_seconds": round(tick_age, 2), "spread_median_points": round(spread_med, 1),
            "spread_ratio": round(spread_ratio, 2), "m1_bars": len(bars), "reasons": reasons,
        }

    @staticmethod
    def _score(windows: dict[str, dict[str, Any]], patterns: dict[str, Any], volume_profile: dict[str, Any], smc: dict[str, Any], frames: dict[str, dict[str, Any]], vwap: dict[str, Any], quality: dict[str, Any]) -> float:
        weights = {"1m": 0.20, "5m": 0.34, "15m": 0.30, "1h": 0.16}
        score = sum(as_float(windows[k].get("delta_percent")) * weights[k] * 0.47 for k in weights)
        cluster = str(patterns.get("cluster", "")); absorption = str(patterns.get("absorption", ""))
        if "BUY" in cluster: score += 6.0
        elif "SELL" in cluster: score -= 6.0
        if "BUY" in absorption: score += 4.0
        elif "SELL" in absorption: score -= 4.0
        score += as_float(volume_profile.get("activity_delta_percent")) * 0.08
        score += as_float(smc.get("score")) * 0.14
        m5 = as_float(frames.get("M5", {}).get("score")); m15 = as_float(frames.get("M15", {}).get("score"))
        score += clamp((m5 + m15) * 0.035, -5, 5)
        if str(vwap.get("location")) == "ABOVE VWAP": score += 2.0
        elif str(vwap.get("location")) == "BELOW VWAP": score -= 2.0
        score *= clamp(as_float(quality.get("score")) / 75.0, 0.45, 1.0)
        return clamp(score, -30.0, 30.0)

    @staticmethod
    def _event(item: dict[str, Any], digits: int) -> dict[str, Any]:
        return {
            "time": iso_utc(item["time"]), "price": round(item["close"], digits), "size": int(round(item["volume"])),
            "side": item["side"], "symbol": "XAUUSD", "source": "MT5 activity estimator", "instrument_id": "LOCAL",
            "quality": "ESTIMATED", "reason": f"Unusual activity strength {as_float(item.get('burst_strength')):.2f} · volume z {as_float(item.get('volume_z')):.2f}",
        }

    @staticmethod
    def _empty(reason: str) -> dict[str, Any]:
        blank = {"buy_contracts": 0, "sell_contracts": 0, "unknown_contracts": 0, "net_delta": 0, "delta_percent": 0.0, "buy_trades": 0, "sell_trades": 0, "unknown_trades": 0, "largest_buy": 0, "largest_sell": 0, "dominant": "BALANCED", "score": 0.0}
        return {
            "status": "WAITING FOR MT5", "quality": "NO-KEY ESTIMATE", "source": "MT5 unique ticks + M1 history", "provider": "LOCAL NO-KEY ENGINE",
            "signal": "UNAVAILABLE", "score": 0.0, "data_age_seconds": None, "session_definition": "Current UTC day",
            "large_trade_threshold": None, "threshold_unit": "robust activity z-score", "quantity_unit": "estimated broker activity units",
            "today": dict(blank), "windows": {k: dict(blank) for k in ("1m", "5m", "15m", "1h")},
            "patterns": {"cluster": "NONE", "absorption": "NONE", "iceberg": "NOT CONFIRMABLE"},
            "order_book": {"status": "WAITING", "bid_wall_contracts": 0, "ask_wall_contracts": 0, "resting_imbalance_percent": 0.0, "bid_walls": [], "ask_walls": [], "spoof_warning": "UNAVAILABLE WITHOUT MBO", "note": reason},
            "session_vwap": {}, "recent_large_trades": [], "activity_bursts": [], "block_trades": [],
            "data_quality": {"score": 0, "state": "LOW", "unique_ticks_60s": 0, "unique_ticks_10s": 0, "tick_age_seconds": None, "reasons": [reason]},
            "identity": {"available": False, "label": "Anonymous estimate", "note": "Participant names are unavailable."},
            "exchange_status": "OPTIONAL · NOT REQUIRED", "limitations": [], "note": reason, "error": reason,
        }
