from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
import json
import re
import threading
import time
import urllib.request


TICK_FLAG_BUY = 32
TICK_FLAG_SELL = 64


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _iso(ts: float | None = None) -> str:
    return datetime.fromtimestamp(ts if ts is not None else time.time(), timezone.utc).isoformat()


def _clone(value: Any) -> Any:
    return json.loads(json.dumps(value))


class LBMAPublicCollector:
    """Collects the free public LBMA weekly turnover headline.

    The public page exposes a 12-week moving-average turnover figure. It does not
    expose live BUY/SELL direction. The directional score is therefore always zero.
    """

    URL = "https://www.lbma.org.uk/prices-and-data/lbma-daily-trade-reporting-data"

    def __init__(self, root: str | Path, settings: dict[str, Any]):
        self.root = Path(root)
        self.settings = settings
        self.cache_path = self.root / "config" / "lbma_public_cache.json"
        self.lock = threading.RLock()
        self.running = False
        self.thread: threading.Thread | None = None
        self.last_fetch = 0.0
        self._summary = self._empty("Waiting for public LBMA turnover refresh")
        try:
            if self.cache_path.is_file():
                cached = json.loads(self.cache_path.read_text(encoding="utf-8"))
                cached["status"] = "CACHED"
                self._summary = cached
        except Exception:
            pass

    @staticmethod
    def _empty(note: str) -> dict[str, Any]:
        return {
            "status": "WAITING",
            "source": "LBMA public Trade Reporting Weekly Turnover",
            "period_ending": None,
            "gold_turnover_usd_bn": None,
            "measure": "12-week moving-average value of reported trades",
            "freshness": "PUBLIC WEEKLY SUMMARY",
            "direction_available": False,
            "score": 0.0,
            "updated_at": None,
            "error": "",
            "note": note,
        }

    def start(self) -> None:
        if self.running or not self.settings.get("lbma_public_enabled", True):
            return
        self.running = True
        self.thread = threading.Thread(target=self._loop, name="aurax-lbma-public", daemon=True)
        self.thread.start()

    def stop(self) -> None:
        self.running = False
        if self.thread:
            self.thread.join(timeout=2)

    def _loop(self) -> None:
        # Delay first fetch slightly so desktop startup and MT5 initialization stay fast.
        time.sleep(1.5)
        while self.running:
            hours = max(2.0, _f(self.settings.get("lbma_refresh_hours", 12), 12))
            if time.time() - self.last_fetch >= hours * 3600:
                self.refresh()
            for _ in range(60):
                if not self.running:
                    return
                time.sleep(1)

    def refresh(self) -> dict[str, Any]:
        self.last_fetch = time.time()
        try:
            ua = str(self.settings.get("public_data_user_agent", "AuRa X Signals local research tool"))
            req = urllib.request.Request(self.URL, headers={"User-Agent": ua, "Accept": "text/html"})
            with urllib.request.urlopen(req, timeout=12) as response:
                html = response.read(1_500_000).decode("utf-8", errors="replace")
            plain = re.sub(r"<[^>]+>", " ", html)
            plain = re.sub(r"\s+", " ", plain)
            amount_match = re.search(r"Gold:\s*\$\s*([\d,.]+)\s*bn", plain, re.I)
            date_match = re.search(r"12\s*week moving average value of trades for the period ending\s+([^.<]{4,40})", plain, re.I)
            if not amount_match:
                raise RuntimeError("LBMA public gold turnover value was not found")
            amount = float(amount_match.group(1).replace(",", ""))
            summary = {
                "status": "LIVE",
                "source": "LBMA public Trade Reporting Weekly Turnover",
                "period_ending": date_match.group(1).strip() if date_match else None,
                "gold_turnover_usd_bn": round(amount, 2),
                "measure": "12-week moving-average value of reported London/Zurich OTC trades",
                "freshness": "PUBLIC WEEKLY SUMMARY",
                "direction_available": False,
                "score": 0.0,
                "updated_at": _iso(),
                "error": "",
                "note": "Liquidity context only. Public LBMA turnover does not provide real-time aggressive BUY/SELL direction.",
            }
            self.cache_path.parent.mkdir(parents=True, exist_ok=True)
            self.cache_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
            with self.lock:
                self._summary = summary
        except Exception as exc:
            with self.lock:
                current = dict(self._summary)
                current["status"] = "CACHED" if current.get("gold_turnover_usd_bn") is not None else "UNAVAILABLE"
                current["error"] = str(exc)
                current["note"] = "Live MT5 prediction continues; LBMA refresh never blocks the signal loop."
                self._summary = current
        return self.summary()

    def summary(self) -> dict[str, Any]:
        with self.lock:
            return _clone(self._summary)


class MT5ComexConnector:
    """Uses an exchange-traded gold futures symbol already available in MT5.

    No separate API key is required. Exact trade volume is only enabled when the
    connected broker supplies Last/Volume trade ticks for a futures symbol. BUY/SELL
    is exact when MT5 trade flags are present; otherwise it is marked inferred.
    """

    def __init__(self, settings: dict[str, Any], trade_ingest: Callable[[dict[str, Any]], dict[str, Any]]):
        self.settings = settings
        self.trade_ingest = trade_ingest
        self.symbol = ""
        self.last_scan = 0.0
        self.last_poll = 0.0
        self.last_time_msc = 0
        self.last_trade_price = 0.0
        self.accepted = 0
        self.flagged = 0
        self.inferred = 0
        self.last_error = ""
        self.last_trade_at = 0.0
        self.description = ""

    @staticmethod
    def _names(row: Any) -> dict[str, Any]:
        names = getattr(getattr(row, "dtype", None), "names", None)
        if names:
            return {name: row[name] for name in names}
        return {}

    def _find_symbol(self, mt5: Any) -> str:
        explicit = str(self.settings.get("mt5_comex_symbol", "")).strip()
        if explicit and mt5.symbol_info(explicit) is not None:
            return explicit
        best: tuple[int, str, str] | None = None
        for item in mt5.symbols_get() or []:
            name = str(getattr(item, "name", ""))
            compact = re.sub(r"[^A-Z0-9]", "", name.upper())
            desc = str(getattr(item, "description", ""))
            path = str(getattr(item, "path", ""))
            text = f"{name} {desc} {path}".upper()
            if "XAUUSD" in compact or "SPOT" in text or "CFD" in text:
                continue
            score = 0
            if re.match(r"^(GC|MGC)[A-Z0-9]*$", compact):
                score += 70
            if "GOLD FUT" in text or ("GOLD" in text and "FUTURE" in text):
                score += 65
            if "COMEX" in text:
                score += 35
            if "FUTURE" in path.upper() or "FUTURES" in path.upper():
                score += 20
            tick = mt5.symbol_info_tick(name)
            if tick is not None:
                if _f(getattr(tick, "last", 0)) > 0:
                    score += 8
                if _f(getattr(tick, "volume_real", 0)) > 0 or _f(getattr(tick, "volume", 0)) > 0:
                    score += 8
            if score >= 70 and (best is None or score > best[0]):
                best = (score, name, desc)
        if best:
            self.description = best[2]
            return best[1]
        return ""

    def poll(self, mt5: Any) -> None:
        if not self.settings.get("mt5_comex_auto_enabled", True):
            return
        now = time.time()
        if now - self.last_poll < max(0.25, _f(self.settings.get("mt5_comex_poll_seconds", 0.5), 0.5)):
            return
        self.last_poll = now
        if not self.symbol or now - self.last_scan > 300:
            self.last_scan = now
            found = self._find_symbol(mt5)
            if found != self.symbol:
                self.symbol = found
                self.last_time_msc = 0
                self.last_trade_price = 0.0
            if not self.symbol:
                self.last_error = "No exchange-traded GC/MGC gold futures symbol was found in this MT5 broker account."
                return
            try:
                mt5.symbol_select(self.symbol, True)
            except Exception:
                pass
        try:
            start = datetime.fromtimestamp((self.last_time_msc / 1000.0 - 1.0) if self.last_time_msc else now - 10.0, timezone.utc)
            rows = mt5.copy_ticks_from(self.symbol, start, 5000, mt5.COPY_TICKS_TRADE)
            if rows is None:
                self.last_error = f"MT5 trade ticks unavailable for {self.symbol}"
                return
            for row in rows:
                data = self._names(row)
                if not data:
                    continue
                msc = int(_f(data.get("time_msc"), _f(data.get("time")) * 1000))
                if msc <= self.last_time_msc:
                    continue
                price = _f(data.get("last"))
                size = _f(data.get("volume_real")) or _f(data.get("volume"))
                flags = int(_f(data.get("flags")))
                bid = _f(data.get("bid")); ask = _f(data.get("ask"))
                self.last_time_msc = max(self.last_time_msc, msc)
                if price <= 0 or size <= 0:
                    continue
                if flags & TICK_FLAG_BUY:
                    side = "BUY"; quality = "REAL EXCHANGE · MT5 BUY FLAG"; self.flagged += 1
                elif flags & TICK_FLAG_SELL:
                    side = "SELL"; quality = "REAL EXCHANGE · MT5 SELL FLAG"; self.flagged += 1
                elif ask > 0 and price >= ask:
                    side = "BUY"; quality = "REAL EXCHANGE · SIDE INFERRED"; self.inferred += 1
                elif bid > 0 and price <= bid:
                    side = "SELL"; quality = "REAL EXCHANGE · SIDE INFERRED"; self.inferred += 1
                elif self.last_trade_price and price != self.last_trade_price:
                    side = "BUY" if price > self.last_trade_price else "SELL"
                    quality = "REAL EXCHANGE · TICK-RULE SIDE"; self.inferred += 1
                else:
                    side = "UNKNOWN"; quality = "REAL EXCHANGE · SIDE UNKNOWN"
                self.last_trade_price = price
                result = self.trade_ingest({
                    "ts": msc / 1000.0,
                    "price": price,
                    "size": size,
                    "side": side,
                    "symbol": self.symbol,
                    "venue": "MT5 EXCHANGE FUTURES",
                    "source": f"MT5 EXCHANGE {self.symbol}",
                    "trade_id": str(msc),
                    "quality": quality,
                })
                if result.get("accepted"):
                    self.accepted += 1
                    self.last_trade_at = msc / 1000.0
            self.last_error = ""
        except Exception as exc:
            self.last_error = str(exc)

    def summary(self) -> dict[str, Any]:
        age = time.time() - self.last_trade_at if self.last_trade_at else None
        if not self.symbol:
            status = "NO FUTURES SYMBOL"
        elif age is None:
            status = "SYMBOL FOUND · NO TRADE TICKS"
        elif age <= max(10.0, _f(self.settings.get("pro_flow_stale_seconds", 20), 20)):
            status = "LIVE EXCHANGE VIA MT5"
        else:
            status = "STALE"
        exact_side = self.flagged > 0
        return {
            "status": status,
            "symbol": self.symbol or None,
            "description": self.description,
            "accepted_trades": self.accepted,
            "flagged_side_trades": self.flagged,
            "inferred_side_trades": self.inferred,
            "last_trade_time": _iso(self.last_trade_at) if self.last_trade_at else None,
            "data_age_seconds": round(age, 2) if age is not None else None,
            "volume_exactness": "EXACT TRADE VOLUME FOR CONNECTED FUTURES SYMBOL" if self.accepted else "UNAVAILABLE",
            "side_exactness": "EXCHANGE BUY/SELL FLAGS" if exact_side else "INFERRED OR UNAVAILABLE",
            "error": self.last_error,
            "note": "This is not global spot XAUUSD volume. It is exact only for the exchange futures symbol supplied by the connected MT5 broker.",
        }


class LocalComexFileBridge:
    """Tails local JSONL files written by a charting platform/plugin.

    This avoids an API key inside AuRa X. The upstream platform still needs a
    legitimate exchange-data entitlement. Each line must be one JSON object.
    """

    def __init__(self, root: str | Path, trade_ingest: Callable[[dict[str, Any]], dict[str, Any]], book_ingest: Callable[[dict[str, Any]], dict[str, Any]]):
        self.root = Path(root)
        self.trade_ingest = trade_ingest
        self.book_ingest = book_ingest
        self.import_dir = self.root / "imports"
        self.trade_file = self.import_dir / "comex_trades.jsonl"
        self.book_file = self.import_dir / "comex_book.jsonl"
        self.offsets: dict[Path, int] = {self.trade_file: 0, self.book_file: 0}
        self.running = False
        self.thread: threading.Thread | None = None
        self.accepted_trades = 0
        self.accepted_book = 0
        self.rejected = 0
        self.last_event_at = 0.0
        self.last_error = ""

    def start(self) -> None:
        self.import_dir.mkdir(parents=True, exist_ok=True)
        for path in (self.trade_file, self.book_file):
            path.touch(exist_ok=True)
            self.offsets[path] = path.stat().st_size
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._loop, name="aurax-comex-file-bridge", daemon=True)
        self.thread.start()

    def stop(self) -> None:
        self.running = False
        if self.thread:
            self.thread.join(timeout=2)

    def _loop(self) -> None:
        while self.running:
            try:
                self._read(self.trade_file, self.trade_ingest, "trade")
                self._read(self.book_file, self.book_ingest, "book")
                self.last_error = ""
            except Exception as exc:
                self.last_error = str(exc)
            time.sleep(0.25)

    def _read(self, path: Path, callback: Callable[[dict[str, Any]], dict[str, Any]], kind: str) -> None:
        size = path.stat().st_size
        offset = self.offsets.get(path, 0)
        if size < offset:
            offset = 0
        if size == offset:
            return
        with path.open("r", encoding="utf-8", errors="replace") as handle:
            handle.seek(offset)
            for line in handle:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                try:
                    payload = json.loads(line)
                    result = callback(payload)
                    if result.get("accepted", True):
                        if kind == "trade": self.accepted_trades += 1
                        else: self.accepted_book += 1
                        self.last_event_at = time.time()
                except Exception:
                    self.rejected += 1
            self.offsets[path] = handle.tell()

    def summary(self) -> dict[str, Any]:
        return {
            "status": "WATCHING LOCAL FILES" if self.running else "STOPPED",
            "trade_file": str(self.trade_file),
            "book_file": str(self.book_file),
            "accepted_trades": self.accepted_trades,
            "accepted_book_events": self.accepted_book,
            "rejected_lines": self.rejected,
            "last_event_time": _iso(self.last_event_at) if self.last_event_at else None,
            "error": self.last_error,
            "note": "No API key is stored in AuRa X. A legitimate upstream platform must write real exchange events into these local files.",
        }


class GlobalGoldFlowManager:
    def __init__(self, root: str | Path, settings: dict[str, Any], trade_ingest: Callable[[dict[str, Any]], dict[str, Any]], book_ingest: Callable[[dict[str, Any]], dict[str, Any]]):
        self.settings = settings
        self.lbma = LBMAPublicCollector(root, settings)
        self.mt5_comex = MT5ComexConnector(settings, trade_ingest)
        self.file_bridge = LocalComexFileBridge(root, trade_ingest, book_ingest)

    def start(self) -> None:
        self.lbma.start()
        if self.settings.get("comex_file_bridge_enabled", True):
            self.file_bridge.start()

    def stop(self) -> None:
        self.lbma.stop()
        self.file_bridge.stop()

    def poll_mt5(self, mt5: Any) -> None:
        self.mt5_comex.poll(mt5)

    def build(self, exchange: dict[str, Any], local: dict[str, Any], cot: dict[str, Any], intelligence: dict[str, Any], order_flow: dict[str, Any]) -> dict[str, Any]:
        exact_live = str(exchange.get("status")) in {"REAL CME", "REAL EXCHANGE"}
        local_live = str(local.get("status")) == "LIVE MT5 ESTIMATE"
        order_live = str(order_flow.get("status")) == "LIVE MT5 ORDER-FLOW PROXY"
        cot_live = str(cot.get("status")) in {"LIVE", "CACHED"}
        intel_live = str(intelligence.get("status")) in {"LIVE", "PARTIAL", "CACHED"}

        layers: list[tuple[str, float, float, bool]] = [
            ("COMEX exact futures flow", _f(exchange.get("score")), 0.46, exact_live),
            ("MT5 spot flow estimate", _f(local.get("score")), 0.24, local_live),
            ("MT5 order-flow proxy", _f(order_flow.get("score")), 0.14, order_live),
            ("CFTC COT", _f(cot.get("score")), 0.09, cot_live),
            ("Public institution bias", _f(intelligence.get("score")), 0.07, intel_live),
        ]
        available = [x for x in layers if x[3]]
        denom = sum(x[2] for x in available) or 1.0
        score = sum(x[1] * x[2] for x in available) / denom
        score = _clamp(score, -30.0, 30.0)
        signal = "STRONG BUY" if score >= 16 else "BUY" if score >= 7 else "STRONG SELL" if score <= -16 else "SELL" if score <= -7 else "BALANCED"

        exact_score = _f(exchange.get("score")) if exact_live else 0.0
        local_score = (_f(local.get("score")) * 0.6 + _f(order_flow.get("score")) * 0.4) if (local_live or order_live) else 0.0
        conflict = exact_live and abs(exact_score) >= 7 and abs(local_score) >= 7 and exact_score * local_score < 0
        agreement = 0
        signed = [x[1] for x in available if abs(x[1]) >= 3]
        if signed:
            dominant_positive = score >= 0
            agreement = round(100 * sum(1 for x in signed if (x >= 0) == dominant_positive) / len(signed))
        coverage = 30 + (35 if exact_live else 0) + (15 if local_live else 0) + (8 if order_live else 0) + (7 if cot_live else 0) + (5 if intel_live else 0)
        coverage = min(100, coverage)

        # This is a small cross-market confirmation only. Existing live safety gates remain primary.
        confirmation = _clamp(score * 0.28, -8.0, 8.0)
        if conflict:
            confirmation *= 0.25

        source_matrix = [
            {"name": "Global exact spot XAUUSD volume", "status": "NOT AVAILABLE", "quality": "IMPOSSIBLE BY MARKET DESIGN", "directional": False, "note": "Spot gold is decentralized OTC; no global participant ledger exists."},
            {"name": "COMEX GC/MGC futures", "status": exchange.get("status", "NOT CONNECTED"), "quality": "EXACT FOR CONNECTED FUTURES CONTRACT" if exact_live else "OPTIONAL LICENSED SOURCE", "directional": exact_live, "note": "Exact traded contracts for the connected futures contract, not worldwide spot volume."},
            {"name": "MT5 XAUUSD", "status": local.get("status", "OFFLINE"), "quality": "REAL-TIME BROKER TICK-VOLUME ESTIMATE", "directional": local_live, "note": "Fast spot-price confirmation from the user’s broker."},
            {"name": "LBMA London/Zurich OTC", "status": self.lbma.summary().get("status", "WAITING"), "quality": "PUBLIC WEEKLY LIQUIDITY CONTEXT", "directional": False, "note": "Public turnover is delayed/aggregated and has no aggressive-side split."},
            {"name": "CFTC positioning", "status": cot.get("status", "WAITING"), "quality": "OFFICIAL WEEKLY", "directional": cot_live, "note": "Structural positioning bias, not an entry trigger."},
        ]
        return {
            "status": "HYBRID LIVE" if (local_live or exact_live) else "WAITING",
            "signal": signal,
            "score": round(score, 1),
            "confirmation_score": round(confirmation, 1),
            "source_coverage": coverage,
            "agreement_percent": agreement,
            "cross_market_conflict": conflict,
            "exact_comex_active": exact_live,
            "global_exact_xauusd_available": False,
            "exchange": exchange,
            "mt5_spot": local,
            "lbma": self.lbma.summary(),
            "mt5_comex_connector": self.mt5_comex.summary(),
            "file_bridge": self.file_bridge.summary(),
            "source_matrix": source_matrix,
            "note": "The predictor becomes stronger through independent-source agreement. It does not convert futures volume into nonexistent exact global spot volume.",
        }
