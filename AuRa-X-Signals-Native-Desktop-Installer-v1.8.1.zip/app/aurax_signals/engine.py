from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .pro_flow import ProFlowManager
from .institution_intelligence import InstitutionIntelligence
from .order_flow_proxy import OrderFlowProxy
from .global_gold_flow import GlobalGoldFlowManager
from .signal_validation import SignalValidationJournal
import json
import math
import threading
import time
import urllib.parse
import urllib.request

try:
    import MetaTrader5 as mt5
except Exception:  # Kept import-safe so the UI can show a clear setup error.
    mt5 = None


TF_MAP = {
    "M1": "TIMEFRAME_M1",
    "M5": "TIMEFRAME_M5",
    "M15": "TIMEFRAME_M15",
    "H1": "TIMEFRAME_H1",
    "H4": "TIMEFRAME_H4",
}
TF_WEIGHTS = {"M1": 0.15, "M5": 0.30, "M15": 0.25, "H1": 0.20, "H4": 0.10}
VERSION = "1.8.1"


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def iso_utc(ts: float | int | None = None) -> str:
    dt = datetime.fromtimestamp(ts if ts is not None else time.time(), timezone.utc)
    return dt.isoformat()


def likely_weekend_market_closed(ts: float | int | None = None) -> bool:
    """Conservative weekend guard for OTC gold/forex feeds.

    Broker schedules vary, so this is only used together with a stale/missing tick.
    It never overrides a genuinely fresh broker quote.
    """
    dt = datetime.fromtimestamp(ts if ts is not None else time.time(), timezone.utc)
    weekday = dt.weekday()  # Monday=0
    minute_of_day = dt.hour * 60 + dt.minute
    if weekday == 5:  # Saturday
        return True
    if weekday == 6 and minute_of_day < 21 * 60:  # Sunday before typical reopen window
        return True
    if weekday == 4 and minute_of_day >= 22 * 60:  # Friday after typical close window
        return True
    return False


def ema(values: list[float], period: int) -> float | None:
    if len(values) < period:
        return None
    alpha = 2.0 / (period + 1.0)
    result = sum(values[:period]) / period
    for value in values[period:]:
        result = alpha * value + (1.0 - alpha) * result
    return result


def ema_series(values: list[float], period: int) -> list[float]:
    if not values:
        return []
    alpha = 2.0 / (period + 1.0)
    result = [values[0]]
    for value in values[1:]:
        result.append(alpha * value + (1.0 - alpha) * result[-1])
    return result


def rsi(values: list[float], period: int = 14) -> float | None:
    if len(values) <= period:
        return None
    gains: list[float] = []
    losses: list[float] = []
    for i in range(1, period + 1):
        diff = values[i] - values[i - 1]
        gains.append(max(diff, 0.0))
        losses.append(max(-diff, 0.0))
    avg_gain = sum(gains) / period
    avg_loss = sum(losses) / period
    for i in range(period + 1, len(values)):
        diff = values[i] - values[i - 1]
        gain = max(diff, 0.0)
        loss = max(-diff, 0.0)
        avg_gain = (avg_gain * (period - 1) + gain) / period
        avg_loss = (avg_loss * (period - 1) + loss) / period
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100.0 - 100.0 / (1.0 + rs)


def atr(bars: list[dict[str, float]], period: int = 14) -> float | None:
    if len(bars) <= period:
        return None
    tr: list[float] = []
    for i in range(1, len(bars)):
        current = bars[i]
        prev_close = bars[i - 1]["close"]
        tr.append(max(
            current["high"] - current["low"],
            abs(current["high"] - prev_close),
            abs(current["low"] - prev_close),
        ))
    if len(tr) < period:
        return None
    value = sum(tr[:period]) / period
    for item in tr[period:]:
        value = (value * (period - 1) + item) / period
    return value



def efficiency_ratio(values: list[float], period: int = 14) -> float:
    if len(values) <= period:
        return 0.0
    x = values[-(period + 1):]
    direction = abs(x[-1] - x[0])
    noise = sum(abs(x[i] - x[i - 1]) for i in range(1, len(x)))
    return direction / noise if noise > 1e-12 else 0.0


def adx(bars: list[dict[str, float]], period: int = 14) -> float | None:
    if len(bars) < period * 2 + 2:
        return None
    trs: list[float] = []
    plus_dm: list[float] = []
    minus_dm: list[float] = []
    for i in range(1, len(bars)):
        up = bars[i]["high"] - bars[i - 1]["high"]
        down = bars[i - 1]["low"] - bars[i]["low"]
        plus_dm.append(up if up > down and up > 0 else 0.0)
        minus_dm.append(down if down > up and down > 0 else 0.0)
        prev_close = bars[i - 1]["close"]
        trs.append(max(bars[i]["high"] - bars[i]["low"], abs(bars[i]["high"] - prev_close), abs(bars[i]["low"] - prev_close)))
    tr_s = sum(trs[:period]); plus_s = sum(plus_dm[:period]); minus_s = sum(minus_dm[:period])
    dxs: list[float] = []
    for i in range(period, len(trs)):
        if i > period:
            tr_s = tr_s - tr_s / period + trs[i]
            plus_s = plus_s - plus_s / period + plus_dm[i]
            minus_s = minus_s - minus_s / period + minus_dm[i]
        if tr_s <= 1e-12:
            continue
        plus_di = 100.0 * plus_s / tr_s
        minus_di = 100.0 * minus_s / tr_s
        denom = plus_di + minus_di
        dxs.append(100.0 * abs(plus_di - minus_di) / denom if denom > 1e-12 else 0.0)
    if len(dxs) < period:
        return mean(dxs) if dxs else None
    value = mean(dxs[:period])
    for d in dxs[period:]:
        value = (value * (period - 1) + d) / period
    return value


def percentile_rank(value: float, values: list[float]) -> float:
    if not values:
        return 50.0
    return 100.0 * sum(1 for x in values if x <= value) / len(values)

def mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def stdev(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    m = mean(values)
    return math.sqrt(sum((x - m) ** 2 for x in values) / (len(values) - 1))


def pct(value: float) -> float:
    return round(value, 2)


def as_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def rate_to_dict(row: Any) -> dict[str, float]:
    # MetaTrader5 returns numpy records. Index access remains stable across builds.
    names = getattr(getattr(row, "dtype", None), "names", None)
    if names:
        return {name: as_float(row[name]) for name in names}
    return {
        "time": as_float(row[0]), "open": as_float(row[1]), "high": as_float(row[2]),
        "low": as_float(row[3]), "close": as_float(row[4]), "tick_volume": as_float(row[5]),
        "spread": as_float(row[6]), "real_volume": as_float(row[7]),
    }


@dataclass
class SignalState:
    candidate: str = "WAIT"
    cycles: int = 0
    published: str = "WAIT"
    published_at: float = 0.0


class AuRaSignalsEngine:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.settings = json.loads((self.root / "config" / "settings.json").read_text(encoding="utf-8"))
        self.lock = threading.RLock()
        self.running = False
        self.thread: threading.Thread | None = None
        self.symbol = self.settings.get("symbol_hint", "XAUUSD")
        self.broker = "—"
        self.point = 0.01
        self.digits = 2
        self.tick_history: deque[tuple[float, float, float, float, float]] = deque(maxlen=int(self.settings.get("tick_history_max", 12000)))
        self.last_tick_signature: tuple[Any, ...] | None = None
        self.last_tick: dict[str, Any] | None = None
        self.frames: dict[str, dict[str, Any]] = {}
        self.frame_bars: dict[str, list[dict[str, float]]] = {}
        self.volume_profile: dict[str, Any] = self._empty_volume_profile()
        self.smc: dict[str, Any] = self._empty_smc()
        self.cot: dict[str, Any] = self._empty_cot("Waiting for free CFTC refresh")
        try:
            cache = self.root / "config" / "cot_cache.json"
            if cache.is_file():
                self.cot = json.loads(cache.read_text(encoding="utf-8"))
                self.cot["status"] = "CACHED"
        except Exception:
            pass
        self.last_cot_fetch = 0.0
        self.last_bar_refresh = 0.0
        self.last_slow_bar_refresh = 0.0
        self.signal_state = SignalState()
        self.pro_flow = ProFlowManager(self.root, self.settings)
        self.institution_intelligence = InstitutionIntelligence(self.root, self.settings)
        self.order_flow_proxy = OrderFlowProxy(self.settings)
        self.global_gold_flow = GlobalGoldFlowManager(
            self.root, self.settings, self.pro_flow.ingest, self.pro_flow.ingest_book
        )
        self.signal_validation = SignalValidationJournal(self.root, self.settings)
        self.dashboard: dict[str, Any] = self._offline_dashboard("Engine starting")
        self.last_error = ""
        self.mt5_ready = False

    def start(self) -> None:
        if self.running:
            return
        self.running = True
        self.pro_flow.start()
        self.institution_intelligence.start()
        self.global_gold_flow.start()
        self.thread = threading.Thread(target=self._loop, name="aurax-signals-engine", daemon=True)
        self.thread.start()

    def stop(self) -> None:
        self.running = False
        if self.thread:
            self.thread.join(timeout=3)
        self.global_gold_flow.stop()
        self.pro_flow.stop()
        self.institution_intelligence.stop()
        if mt5 is not None:
            try:
                mt5.shutdown()
            except Exception:
                pass

    def snapshot(self) -> dict[str, Any]:
        with self.lock:
            return json.loads(json.dumps(self.dashboard))

    def health(self) -> dict[str, Any]:
        with self.lock:
            tick_age = None
            if self.last_tick:
                tick_age = max(0.0, time.time() - as_float(self.last_tick.get("time")))
            return {
                "ok": True,
                "product": "AuRa X Signals",
                "version": VERSION,
                "engine": "LIVE" if self.mt5_ready else "OFFLINE",
                "symbol": self.symbol,
                "broker": self.broker,
                "tick_age_seconds": round(tick_age, 2) if tick_age is not None else None,
                "last_error": self.last_error,
                "read_only": True,
                "automatic_trading": False,
                "pro_flow": self.pro_flow.summary(self.last_tick.get("mid") if self.last_tick else None),
                "institution_intelligence": self.institution_intelligence.summary(),
                "order_flow_proxy_lab": self.order_flow_proxy.summary(),
                "global_gold_flow": self.global_gold_flow.build(
                    self.pro_flow.exchange_summary(self.last_tick.get("mid") if self.last_tick else None),
                    self.pro_flow.local_summary(), self.cot, self.institution_intelligence.summary(), self.order_flow_proxy.summary()
                ),
                "validation": self.signal_validation.summary(self.dashboard),
            }

    def _loop(self) -> None:
        while self.running:
            started = time.time()
            try:
                if not self.mt5_ready:
                    self._connect_mt5()
                if self.mt5_ready:
                    self._update_live()
            except Exception as exc:
                self.last_error = str(exc)
                self.mt5_ready = False
                with self.lock:
                    self.dashboard = self._offline_dashboard(self.last_error)
                try:
                    if mt5 is not None:
                        mt5.shutdown()
                except Exception:
                    pass
            elapsed = time.time() - started
            time.sleep(max(0.05, as_float(self.settings.get("refresh_seconds", 0.12), 0.12) - elapsed))

    def _connect_mt5(self) -> None:
        if mt5 is None:
            raise RuntimeError("MetaTrader5 Python package is not installed. Run Install-AuRa-X-Signals.bat.")
        if not mt5.initialize():
            code, message = mt5.last_error()
            raise RuntimeError(f"MT5 connection failed ({code}): {message}. Open MT5 and log in first.")
        terminal = mt5.terminal_info()
        account = mt5.account_info()
        self.broker = getattr(account, "company", None) or getattr(terminal, "company", None) or "Connected broker"
        self.symbol = self._discover_symbol(self.settings.get("symbol_hint", "XAUUSD"))
        info = mt5.symbol_info(self.symbol)
        if info is None:
            raise RuntimeError("Gold symbol was not found in Market Watch.")
        if not info.visible:
            mt5.symbol_select(self.symbol, True)
            info = mt5.symbol_info(self.symbol)
        self.point = as_float(getattr(info, "point", 0.01), 0.01) or 0.01
        self.digits = int(getattr(info, "digits", 2) or 2)
        self.mt5_ready = True
        self.last_error = ""
        self.last_bar_refresh = 0.0

    def _discover_symbol(self, hint: str) -> str:
        exact = mt5.symbol_info(hint)
        if exact is not None:
            return hint
        symbols = mt5.symbols_get() or []
        candidates: list[tuple[int, str]] = []
        target = hint.upper().replace("/", "")
        for item in symbols:
            name = str(getattr(item, "name", ""))
            compact = name.upper().replace("/", "")
            score = 0
            if compact == target:
                score = 100
            elif compact.startswith(target):
                score = 90
            elif "XAUUSD" in compact:
                score = 80
            elif "GOLD" in compact:
                score = 65
            if score:
                score += 4 if getattr(item, "visible", False) else 0
                candidates.append((score, name))
        if not candidates:
            raise RuntimeError("No XAUUSD/GOLD symbol found. Add the broker's gold symbol to Market Watch.")
        candidates.sort(reverse=True)
        return candidates[0][1]

    def _copy_bars(self, tf: str, count: int) -> list[dict[str, float]]:
        attr = TF_MAP[tf]
        timeframe = getattr(mt5, attr)
        raw = mt5.copy_rates_from_pos(self.symbol, timeframe, 1, count)  # position 1 excludes forming candle
        if raw is None or len(raw) < 60:
            code, message = mt5.last_error()
            raise RuntimeError(f"Not enough {tf} history ({code}: {message}). Open the chart and load history.")
        return [rate_to_dict(row) for row in raw]

    def _update_live(self) -> None:
        tick_obj = mt5.symbol_info_tick(self.symbol)
        if tick_obj is None:
            raise RuntimeError("MT5 tick is unavailable. Check Market Watch and market connection.")
        event_time = as_float(getattr(tick_obj, "time_msc", 0)) / 1000.0 or as_float(getattr(tick_obj, "time", time.time()))
        tick = {
            "time": event_time,
            "bid": as_float(getattr(tick_obj, "bid", 0.0)),
            "ask": as_float(getattr(tick_obj, "ask", 0.0)),
            "last": as_float(getattr(tick_obj, "last", 0.0)),
            "volume": as_float(getattr(tick_obj, "volume_real", 0.0)) or as_float(getattr(tick_obj, "volume", 0.0)),
        }
        if tick["bid"] <= 0 or tick["ask"] <= 0 or tick["ask"] < tick["bid"]:
            raise RuntimeError("Invalid MT5 bid/ask quote received.")
        tick["mid"] = (tick["bid"] + tick["ask"]) / 2.0
        tick["spread_points"] = (tick["ask"] - tick["bid"]) / self.point if self.point else 0.0
        self.last_tick = tick

        # Record only genuinely new broker ticks. The old engine counted the same
        # quote on every polling cycle, inflating speed and activity percentages.
        signature = (int(round(event_time * 1000)), round(tick["bid"], self.digits), round(tick["ask"], self.digits), round(tick["last"], self.digits))
        if signature != self.last_tick_signature:
            self.tick_history.append((event_time, tick["mid"], tick["spread_points"], tick["bid"], tick["ask"]))
            self.last_tick_signature = signature

        now = time.time()
        if now - self.last_bar_refresh >= as_float(self.settings.get("bar_refresh_seconds", 2.0), 2.0):
            self._refresh_bars()
            self.last_bar_refresh = now
        if self.settings.get("cot_enabled", True):
            refresh = as_float(self.settings.get("cot_refresh_hours", 6), 6) * 3600
            if now - self.last_cot_fetch > refresh:
                self._refresh_cot()

        # Optional no-key path: if this MT5 broker exposes an exchange-traded
        # GC/MGC futures symbol, ingest its exact trade volume automatically.
        self.global_gold_flow.poll_mt5(mt5)
        dashboard = self._build_dashboard(tick)
        validation = self.signal_validation.observe(dashboard, self.frame_bars.get("M1", []), tick)
        dashboard["validation"] = validation
        current_bucket = validation.get("current_confidence_bucket") or {}
        dashboard.setdefault("signal", {})["calibration_status"] = validation.get("sample_status", "INSUFFICIENT SAMPLE")
        dashboard["signal"]["observed_bucket_rate"] = current_bucket.get("observed_tp1_first_rate")
        dashboard["signal"]["observed_bucket_sample"] = current_bucket.get("sample", 0)
        with self.lock:
            self.dashboard = dashboard

    def _refresh_bars(self) -> None:
        counts = {
            "M1": max(900, int(self.settings.get("volume_profile_bars", 720)) + 120),
            "M5": 520, "M15": 420, "H1": 360, "H4": 320,
        }
        now = time.time()
        slow_due = not self.frames or now - self.last_slow_bar_refresh >= as_float(self.settings.get("slow_bar_refresh_seconds", 10.0), 10.0)
        targets = list(TF_MAP) if slow_due else ["M1", "M5"]
        bars_map = dict(self.frame_bars)
        frames = dict(self.frames)
        for tf in targets:
            bars = self._copy_bars(tf, counts[tf])
            bars_map[tf] = bars
            frames[tf] = self._analyze_frame(tf, bars)
        self.frame_bars = bars_map
        self.frames = frames
        if bars_map.get("M1"):
            self.volume_profile = self._build_volume_profile(bars_map["M1"])
        if bars_map.get("M5"):
            self.smc = self._build_smc(bars_map["M5"])
        if slow_due:
            self.last_slow_bar_refresh = now

    def _analyze_frame(self, tf: str, bars: list[dict[str, float]]) -> dict[str, Any]:
        closes = [b["close"] for b in bars]
        e20 = ema(closes, 20) or closes[-1]
        e50 = ema(closes, 50) or closes[-1]
        e200 = ema(closes, 200) or e50
        e20_prev = ema(closes[:-3], 20) or e20
        r = rsi(closes, 14) or 50.0
        a = atr(bars, 14) or max(mean([b["high"] - b["low"] for b in bars[-20:]]), self.point * 10)
        adx_value = adx(bars, 14) or 0.0
        er = efficiency_ratio(closes, 14)
        close = closes[-1]
        momentum = (close - closes[-4]) / a if len(closes) >= 4 and a else 0.0
        recent_high = max(b["high"] for b in bars[-21:-1])
        recent_low = min(b["low"] for b in bars[-21:-1])
        volume_now = max(0.0, bars[-1].get("tick_volume", 0.0))
        volume_history = [max(0.0, b.get("tick_volume", 0.0)) for b in bars[-61:-1]]
        volume_avg = mean(volume_history) or 1.0
        volume_sd = stdev(volume_history)
        volume_ratio = volume_now / volume_avg
        volume_z = (volume_now - volume_avg) / volume_sd if volume_sd > 1e-9 else 0.0
        atr_history = []
        for i in range(max(30, len(bars) - 120), len(bars) + 1):
            sample = atr(bars[:i], 14)
            if sample:
                atr_history.append(sample)
        atr_percentile = percentile_rank(a, atr_history[-100:]) if atr_history else 50.0

        if adx_value >= 24 and er >= 0.28:
            regime = "TRENDING"
        elif atr_percentile >= 82:
            regime = "HIGH VOLATILITY"
        elif er <= 0.18 and adx_value < 20:
            regime = "RANGE"
        else:
            regime = "TRANSITION"

        score = 0.0
        reasons: list[str] = []
        if close > e20 > e50 and e50 >= e200 * 0.998:
            trend = "BULLISH"
            score += 27
            reasons.append("EMA structure is bullish")
        elif close < e20 < e50 and e50 <= e200 * 1.002:
            trend = "BEARISH"
            score -= 27
            reasons.append("EMA structure is bearish")
        else:
            trend = "MIXED"
            score += clamp((close - e50) / max(a, self.point) * 6.0, -11, 11)
            reasons.append("EMA structure is mixed")

        slope = (e20 - e20_prev) / max(a, self.point)
        score += clamp(slope * 14.0, -10, 10)
        score += clamp((r - 50.0) * 0.55, -11, 11)
        score += clamp(momentum * 9.0, -17, 17)
        if close > recent_high:
            score += 13
            reasons.append("Confirmed close above recent resistance")
        elif close < recent_low:
            score -= 13
            reasons.append("Confirmed close below recent support")

        candle_span = max(bars[-1]["high"] - bars[-1]["low"], self.point)
        candle_direction = clamp((bars[-1]["close"] - bars[-1]["open"]) / candle_span, -1.0, 1.0)
        if volume_z > 0.8:
            score += candle_direction * min(9.0, volume_z * 3.0)
            reasons.append("Above-normal tick activity supports the completed candle")
        if regime == "RANGE":
            score *= 0.78
        elif regime == "HIGH VOLATILITY":
            score *= 0.88
        elif regime == "TRENDING":
            score *= 1.05

        score = clamp(score, -100, 100)
        return {
            "timeframe": tf,
            "completed_bar_time": iso_utc(bars[-1]["time"]),
            "trend": trend,
            "regime": regime,
            "score": round(score, 1),
            "close": round(close, self.digits),
            "ema20": round(e20, self.digits),
            "ema50": round(e50, self.digits),
            "ema200": round(e200, self.digits),
            "rsi14": round(r, 1),
            "atr14": round(a, self.digits),
            "adx14": round(adx_value, 1),
            "efficiency_ratio": round(er, 2),
            "atr_percentile": round(atr_percentile, 1),
            "momentum_atr": round(momentum, 2),
            "volume_ratio": round(volume_ratio, 2),
            "volume_z": round(volume_z, 2),
            "recent_high": round(recent_high, self.digits),
            "recent_low": round(recent_low, self.digits),
            "reasons": reasons,
        }

    def _build_volume_profile(self, bars: list[dict[str, float]]) -> dict[str, Any]:
        count = int(self.settings.get("volume_profile_bars", 720))
        bins = max(24, int(self.settings.get("volume_profile_bins", 64)))
        x = bars[-count:]
        low = min(b["low"] for b in x)
        high = max(b["high"] for b in x)
        width = (high - low) / bins if high > low else self.point
        histogram = [0.0] * bins
        up = [0.0] * bins
        down = [0.0] * bins

        for b in x:
            b_low = max(low, b["low"]); b_high = min(high, b["high"])
            typical = (b["high"] + b["low"] + b["close"]) / 3.0
            start = max(0, min(bins - 1, int((b_low - low) / width)))
            end = max(0, min(bins - 1, int((b_high - low) / width)))
            if end < start:
                start, end = end, start
            indexes = list(range(start, end + 1)) or [max(0, min(bins - 1, int((typical - low) / width)))]
            weights = []
            for i in indexes:
                center = low + (i + 0.5) * width
                distance = abs(center - typical) / max(width, self.point)
                weights.append(1.0 / (1.0 + distance))
            weight_sum = sum(weights) or 1.0
            volume = max(1.0, b.get("tick_volume", 0.0))
            span = max(b["high"] - b["low"], self.point)
            clv = clamp((2.0 * b["close"] - b["high"] - b["low"]) / span, -1.0, 1.0)
            direction = clamp((b["close"] - b["open"]) / span, -1.0, 1.0)
            buy_share = clamp(0.50 + 0.26 * clv + 0.18 * direction, 0.06, 0.94)
            for i, w in zip(indexes, weights):
                allocated = volume * w / weight_sum
                histogram[i] += allocated
                up[i] += allocated * buy_share
                down[i] += allocated * (1.0 - buy_share)

        total = sum(histogram) or 1.0
        up_total = sum(up); down_total = sum(down); activity_total = up_total + down_total or 1.0
        poc_idx = max(range(bins), key=lambda i: histogram[i])
        included = {poc_idx}; value_sum = histogram[poc_idx]; left = poc_idx - 1; right = poc_idx + 1
        while value_sum < total * 0.70 and (left >= 0 or right < bins):
            left_v = histogram[left] if left >= 0 else -1.0
            right_v = histogram[right] if right < bins else -1.0
            if right_v > left_v:
                included.add(right); value_sum += max(0.0, right_v); right += 1
            else:
                included.add(left); value_sum += max(0.0, left_v); left -= 1
        val_idx = min(included); vah_idx = max(included)
        center = lambda i: low + (i + 0.5) * width
        poc = center(poc_idx); val = low + val_idx * width; vah = low + (vah_idx + 1) * width
        current = self.last_tick["mid"] if self.last_tick else x[-1]["close"]
        if current > vah:
            location = "ABOVE VALUE AREA"; bias = "BULLISH ACCEPTANCE"
        elif current < val:
            location = "BELOW VALUE AREA"; bias = "BEARISH ACCEPTANCE"
        elif abs(current - poc) <= width:
            location = "AT POC"; bias = "BALANCED"
        else:
            location = "INSIDE VALUE AREA"; bias = "ABOVE POC" if current > poc else "BELOW POC"

        top = sorted(range(bins), key=lambda i: histogram[i], reverse=True)[:8]
        nodes = [{"price": round(center(i), self.digits), "share": round(histogram[i] / total * 100, 1)} for i in top]
        rows = []
        peak = max(histogram) or 1.0
        for i in range(bins):
            if histogram[i] <= 0:
                continue
            rows.append({
                "price": round(center(i), self.digits),
                "relative": round(histogram[i] / peak * 100, 1),
                "delta": round((up[i] - down[i]) / histogram[i] * 100, 1),
                "value_area": i in included,
            })

        now = time.time()
        today_start = datetime.fromtimestamp(now, timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
        today = [b for b in bars if b["time"] >= today_start] or bars[-min(360, len(bars)):]
        weighted = sum(((b["high"] + b["low"] + b["close"]) / 3.0) * max(1.0, b.get("tick_volume", 0.0)) for b in today)
        day_volume = sum(max(1.0, b.get("tick_volume", 0.0)) for b in today) or 1.0
        session_vwap = weighted / day_volume
        variance = sum(max(1.0, b.get("tick_volume", 0.0)) * (((b["high"] + b["low"] + b["close"]) / 3.0) - session_vwap) ** 2 for b in today) / day_volume
        sigma = math.sqrt(max(0.0, variance))

        return {
            "status": "LIVE",
            "source": "MT5 broker tick-volume profile · range-distributed",
            "lookback_bars": len(x),
            "poc": round(poc, self.digits), "vah": round(vah, self.digits), "val": round(val, self.digits),
            "location": location, "bias": bias,
            "session_vwap": round(session_vwap, self.digits),
            "vwap_upper_1sd": round(session_vwap + sigma, self.digits),
            "vwap_lower_1sd": round(session_vwap - sigma, self.digits),
            "vwap_location": "ABOVE VWAP" if current > session_vwap + sigma * 0.15 else "BELOW VWAP" if current < session_vwap - sigma * 0.15 else "AT VWAP",
            "high_volume_nodes": nodes, "rows": rows,
            "up_activity": int(round(up_total)), "down_activity": int(round(down_total)),
            "up_activity_percent": round(up_total / activity_total * 100, 1),
            "down_activity_percent": round(down_total / activity_total * 100, 1),
            "activity_delta_percent": round((up_total - down_total) / activity_total * 100, 1),
            "quantity_unit": "estimated broker activity units",
            "note": "Volume is distributed through each candle range and split using close location. It is more stable than assigning the whole candle to one price, but remains broker tick-volume—not exact institutional orders.",
        }

    def _pivot_points(self, bars: list[dict[str, float]], order: int = 3) -> tuple[list[tuple[int, float]], list[tuple[int, float]]]:
        highs: list[tuple[int, float]] = []
        lows: list[tuple[int, float]] = []
        for i in range(order, len(bars) - order):
            window = bars[i - order:i + order + 1]
            h = bars[i]["high"]
            l = bars[i]["low"]
            if h == max(x["high"] for x in window):
                highs.append((i, h))
            if l == min(x["low"] for x in window):
                lows.append((i, l))
        return highs, lows

    def _build_smc(self, bars: list[dict[str, float]]) -> dict[str, Any]:
        x = bars[-320:]
        highs, lows = self._pivot_points(x, 3)
        latest = x[-1]
        current = self.last_tick["mid"] if self.last_tick else latest["close"]
        a = atr(x, 14) or max(mean([b["high"] - b["low"] for b in x[-20:]]), self.point * 10)
        last_high = highs[-1] if highs else (len(x) - 2, max(b["high"] for b in x[-30:-1]))
        last_low = lows[-1] if lows else (len(x) - 2, min(b["low"] for b in x[-30:-1]))
        prev_high = highs[-2] if len(highs) >= 2 else last_high
        prev_low = lows[-2] if len(lows) >= 2 else last_low

        if last_high[1] > prev_high[1] and last_low[1] > prev_low[1]:
            prior_structure = "BULLISH"
        elif last_high[1] < prev_high[1] and last_low[1] < prev_low[1]:
            prior_structure = "BEARISH"
        else:
            prior_structure = "RANGE"

        bos = "NONE"; choch = "NONE"; structure = prior_structure; score = 0.0
        if latest["close"] > last_high[1] + self.point:
            bos = "BULLISH BOS"
            choch = "BULLISH CHOCH" if prior_structure == "BEARISH" else "NONE"
            structure = "BULLISH"
            score += 13 if choch == "NONE" else 18
        elif latest["close"] < last_low[1] - self.point:
            bos = "BEARISH BOS"
            choch = "BEARISH CHOCH" if prior_structure == "BULLISH" else "NONE"
            structure = "BEARISH"
            score -= 13 if choch == "NONE" else 18
        elif prior_structure == "RANGE":
            m5_score = as_float(self.frames.get("M5", {}).get("score"))
            structure = "BULLISH" if m5_score > 25 else "BEARISH" if m5_score < -25 else "RANGE"

        sweep = "NONE"
        if latest["low"] < last_low[1] and latest["close"] > last_low[1] and latest["close"] > latest["open"]:
            sweep = "SELL-SIDE LIQUIDITY SWEEP"; score += 13
        elif latest["high"] > last_high[1] and latest["close"] < last_high[1] and latest["close"] < latest["open"]:
            sweep = "BUY-SIDE LIQUIDITY SWEEP"; score -= 13

        def make_ob(kind: str) -> dict[str, Any] | None:
            for i in range(len(x) - 5, max(8, len(x) - 120), -1):
                candle = x[i]
                future = x[i + 1:min(len(x), i + 5)]
                if not future:
                    continue
                future_close = future[-1]["close"]
                displacement = future_close - candle["close"]
                if kind == "BULLISH" and candle["close"] < candle["open"] and displacement > 1.25 * a:
                    zone_low, zone_high = candle["low"], max(candle["open"], candle["close"])
                elif kind == "BEARISH" and candle["close"] > candle["open"] and displacement < -1.25 * a:
                    zone_low, zone_high = min(candle["open"], candle["close"]), candle["high"]
                else:
                    continue
                after = x[i + 4:]
                invalidated = any(b["close"] < zone_low - 0.10 * a for b in after) if kind == "BULLISH" else any(b["close"] > zone_high + 0.10 * a for b in after)
                if invalidated:
                    continue
                touched = any(b["low"] <= zone_high and b["high"] >= zone_low for b in after)
                return {
                    "low": round(zone_low, self.digits), "high": round(zone_high, self.digits),
                    "time": iso_utc(candle["time"]), "type": kind,
                    "status": "MITIGATED" if touched else "FRESH",
                    "strength": round(clamp(abs(displacement) / max(a, self.point), 0, 5), 2),
                }
            return None

        bullish_ob = make_ob("BULLISH")
        bearish_ob = make_ob("BEARISH")
        near_ob = "NONE"
        if bullish_ob and bullish_ob["low"] - 0.20 * a <= current <= bullish_ob["high"] + 0.30 * a:
            near_ob = "NEAR BULLISH ORDER BLOCK"; score += 7 if bullish_ob["status"] == "FRESH" else 4
        if bearish_ob and bearish_ob["low"] - 0.30 * a <= current <= bearish_ob["high"] + 0.20 * a:
            near_ob = "NEAR BEARISH ORDER BLOCK"; score -= 7 if bearish_ob["status"] == "FRESH" else 4

        bullish_fvg = None; bearish_fvg = None
        for i in range(len(x) - 1, max(2, len(x) - 100), -1):
            if bullish_fvg is None and x[i]["low"] > x[i - 2]["high"] + self.point * 2:
                low_gap, high_gap = x[i - 2]["high"], x[i]["low"]
                filled = any(b["low"] <= low_gap for b in x[i + 1:])
                if not filled:
                    bullish_fvg = {"low": round(low_gap, self.digits), "high": round(high_gap, self.digits), "time": iso_utc(x[i]["time"]), "type": "BULLISH"}
            if bearish_fvg is None and x[i]["high"] < x[i - 2]["low"] - self.point * 2:
                low_gap, high_gap = x[i]["high"], x[i - 2]["low"]
                filled = any(b["high"] >= high_gap for b in x[i + 1:])
                if not filled:
                    bearish_fvg = {"low": round(low_gap, self.digits), "high": round(high_gap, self.digits), "time": iso_utc(x[i]["time"]), "type": "BEARISH"}
            if bullish_fvg and bearish_fvg:
                break

        swing_high = max(last_high[1], prev_high[1]); swing_low = min(last_low[1], prev_low[1])
        equilibrium = (swing_high + swing_low) / 2.0
        dealing_range = "PREMIUM" if current > equilibrium + a * 0.08 else "DISCOUNT" if current < equilibrium - a * 0.08 else "EQUILIBRIUM"
        if structure == "BULLISH" and dealing_range == "DISCOUNT": score += 4
        if structure == "BEARISH" and dealing_range == "PREMIUM": score -= 4

        equal_highs = [h for _, h in highs[-5:] if abs(h - last_high[1]) <= a * 0.12]
        equal_lows = [l for _, l in lows[-5:] if abs(l - last_low[1]) <= a * 0.12]
        liquidity_pools = []
        if len(equal_highs) >= 2: liquidity_pools.append({"type": "EQUAL HIGHS", "price": round(mean(equal_highs), self.digits)})
        if len(equal_lows) >= 2: liquidity_pools.append({"type": "EQUAL LOWS", "price": round(mean(equal_lows), self.digits)})

        return {
            "status": "LIVE", "timeframe": "M5", "structure": structure, "prior_structure": prior_structure,
            "bos": bos, "choch": choch, "liquidity_sweep": sweep, "nearest_order_block": near_ob,
            "bullish_order_block": bullish_ob, "bearish_order_block": bearish_ob,
            "bullish_fvg": bullish_fvg, "bearish_fvg": bearish_fvg,
            "dealing_range": dealing_range, "equilibrium": round(equilibrium, self.digits),
            "liquidity_pools": liquidity_pools,
            "buy_side_liquidity": round(last_high[1], self.digits), "sell_side_liquidity": round(last_low[1], self.digits),
            "score": round(clamp(score, -35, 35), 1),
            "note": "BOS/CHoCH use confirmed M5 pivots. Order blocks, FVGs and liquidity pools are algorithmic price-action estimates—not confirmed bank orders.",
        }

    def _refresh_cot(self) -> None:
        self.last_cot_fetch = time.time()
        try:
            fields = ",".join([
                "market_and_exchange_names", "report_date_as_yyyy_mm_dd", "open_interest_all",
                "prod_merc_positions_long", "prod_merc_positions_short",
                "swap_positions_long_all", "swap__positions_short_all",
                "m_money_positions_long_all", "m_money_positions_short_all",
                "other_rept_positions_long", "other_rept_positions_short",
                "change_in_m_money_long_all", "change_in_m_money_short_all",
                "traders_tot_all", "traders_prod_merc_long_all", "traders_prod_merc_short_all",
                "traders_swap_long_all", "traders_swap_short_all",
                "traders_m_money_long_all", "traders_m_money_short_all",
                "traders_other_rept_long_all", "traders_other_rept_short_all",
            ])
            params = {
                "$select": fields,
                "$where": "market_and_exchange_names like 'GOLD - COMMODITY EXCHANGE INC.%'",
                "$order": "report_date_as_yyyy_mm_dd DESC",
                "$limit": "2",
            }
            def fetch_rows(selected_fields: str) -> list[dict[str, Any]]:
                query = dict(params)
                query["$select"] = selected_fields
                url = "https://publicreporting.cftc.gov/resource/72hh-3qpy.json?" + urllib.parse.urlencode(query)
                request = urllib.request.Request(url, headers={"User-Agent": "AuRa-X-Signals/1.3"})
                with urllib.request.urlopen(request, timeout=12) as response:
                    return json.loads(response.read().decode("utf-8"))

            try:
                rows = fetch_rows(fields)
            except Exception:
                # Older/mirrored CFTC schemas can omit trader-count fields. Position quantities still load.
                position_fields = ",".join([
                    "market_and_exchange_names", "report_date_as_yyyy_mm_dd", "open_interest_all",
                    "prod_merc_positions_long", "prod_merc_positions_short",
                    "swap_positions_long_all", "swap__positions_short_all",
                    "m_money_positions_long_all", "m_money_positions_short_all",
                    "other_rept_positions_long", "other_rept_positions_short",
                    "change_in_m_money_long_all", "change_in_m_money_short_all",
                ])
                rows = fetch_rows(position_fields)
            if not rows:
                raise RuntimeError("No GOLD record returned")
            current = rows[0]
            previous = rows[1] if len(rows) > 1 else {}

            def optional_int(row: dict[str, Any], key: str) -> int | None:
                raw = row.get(key)
                if raw is None or str(raw).strip() in {"", "."}:
                    return None
                return int(as_float(raw))

            def category(label: str, long_key: str, short_key: str, long_traders_key: str, short_traders_key: str, meaning: str) -> dict[str, Any]:
                long_value = int(as_float(current.get(long_key)))
                short_value = int(as_float(current.get(short_key)))
                return {
                    "label": label,
                    "long": long_value,
                    "short": short_value,
                    "net": long_value - short_value,
                    "long_traders": optional_int(current, long_traders_key),
                    "short_traders": optional_int(current, short_traders_key),
                    "meaning": meaning,
                }

            categories = [
                category("Producer / Merchant", "prod_merc_positions_long", "prod_merc_positions_short", "traders_prod_merc_long_all", "traders_prod_merc_short_all", "Commercial firms connected to producing, processing or using gold."),
                category("Swap Dealers", "swap_positions_long_all", "swap__positions_short_all", "traders_swap_long_all", "traders_swap_short_all", "Dealers managing swap-related exposure; category identity, not company names."),
                category("Managed Money", "m_money_positions_long_all", "m_money_positions_short_all", "traders_m_money_long_all", "traders_m_money_short_all", "CTAs, CPOs, hedge funds and similar professional money managers."),
                category("Other Reportables", "other_rept_positions_long", "other_rept_positions_short", "traders_other_rept_long_all", "traders_other_rept_short_all", "Other large reportable traders outside the main categories."),
            ]

            long_now = as_float(current.get("m_money_positions_long_all"))
            short_now = as_float(current.get("m_money_positions_short_all"))
            net = long_now - short_now
            prev_net = as_float(previous.get("m_money_positions_long_all")) - as_float(previous.get("m_money_positions_short_all"))
            change = net - prev_net
            oi = as_float(current.get("open_interest_all"))
            normalized = net / oi * 100 if oi else 0.0
            if net > 0 and change > 0:
                bias = "BULLISH"
                score = 8
            elif net < 0 and change < 0:
                bias = "BEARISH"
                score = -8
            elif change > 0:
                bias = "IMPROVING"
                score = 4
            elif change < 0:
                bias = "WEAKENING"
                score = -4
            else:
                bias = "NEUTRAL"
                score = 0
            date_text = str(current.get("report_date_as_yyyy_mm_dd", ""))[:10]
            report_dt = datetime.fromisoformat(date_text).replace(tzinfo=timezone.utc) if date_text else None
            age_days = (datetime.now(timezone.utc) - report_dt).days if report_dt else None
            self.cot = {
                "status": "LIVE",
                "source": "Official CFTC Disaggregated Futures Only",
                "report_date": date_text or "—",
                "open_interest": int(oi),
                "managed_money_long": int(long_now),
                "managed_money_short": int(short_now),
                "managed_money_net": int(net),
                "weekly_net_change": int(change),
                "net_percent_open_interest": round(normalized, 2),
                "bias": bias,
                "score": score,
                "age_days": age_days,
                "total_reported_traders": optional_int(current, "traders_tot_all"),
                "categories": categories,
                "quantity_unit": "COMEX Gold futures contracts",
                "identity": {
                    "available_level": "CFTC trader category",
                    "individual_names_available": False,
                    "display": "Producer/Merchant · Swap Dealers · Managed Money · Other Reportables",
                    "note": "CFTC public reports do not disclose individual trader or institution names.",
                },
                "note": "COT is weekly COMEX futures positioning. Contract quantities are official, but participant names are confidential and it is not a fast entry trigger.",
            }
            try:
                cache = self.root / "config" / "cot_cache.json"
                cache.write_text(json.dumps(self.cot, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass
        except Exception as exc:
            if self.cot.get("status") in {"LIVE", "CACHED"}:
                self.cot["refresh_error"] = str(exc)
                return
            try:
                cache = self.root / "config" / "cot_cache.json"
                cached = json.loads(cache.read_text(encoding="utf-8"))
                cached["status"] = "CACHED"
                cached["refresh_error"] = str(exc)
                cached["note"] = str(cached.get("note", "")) + " Cached because the free CFTC refresh is currently unavailable."
                self.cot = cached
            except Exception:
                self.cot = self._empty_cot(str(exc))

    def _speed_metrics(self, current: float, m1_atr: float) -> dict[str, Any]:
        now = time.time()
        points = list(self.tick_history)
        def move(seconds: float) -> float:
            eligible = [p for p in points if p[0] <= now - seconds]
            reference = eligible[-1][1] if eligible else (points[0][1] if points else current)
            return current - reference
        move1 = move(1); move3 = move(3); move10 = move(10)
        recent5 = [p for p in points if p[0] >= now - 5]
        recent60 = [p for p in points if p[0] >= now - 60]
        tick_rate = len(recent5) / 5.0
        normalizer = max(m1_atr, self.point * 30)
        raw_speed = (move1 / normalizer) * 42 + (move3 / normalizer) * 58 + (move10 / normalizer) * 28

        buy = sell = 0.0
        for previous, item in zip(recent60, recent60[1:]):
            bid_delta = item[3] - previous[3]
            ask_delta = item[4] - previous[4]
            mid_delta = item[1] - previous[1]
            weight = 1.0 + min(4.0, abs(mid_delta) / max(self.point, 1e-9) * 0.18)
            if bid_delta > 0 and ask_delta > 0:
                buy += weight
            elif bid_delta < 0 and ask_delta < 0:
                sell += weight
            elif mid_delta > 0:
                buy += weight * 0.75
            elif mid_delta < 0:
                sell += weight * 0.75
        directional = buy + sell
        micro_delta = (buy - sell) / directional * 100 if directional else 0.0
        speed_score = clamp(raw_speed + micro_delta * 0.10, -25, 25)
        spreads = [p[2] for p in recent60]
        spread_avg = mean(spreads) if spreads else None
        spread_med = sorted(spreads)[len(spreads)//2] if spreads else None
        return {
            "move_1s": round(move1, self.digits), "move_3s": round(move3, self.digits), "move_10s": round(move10, self.digits),
            "tick_rate_per_second": round(tick_rate, 1), "unique_ticks_60s": len(recent60),
            "spread_average_points": round(spread_avg, 1) if spread_avg is not None else None,
            "spread_median_points": round(spread_med, 1) if spread_med is not None else None,
            "micro_buy_weight": round(buy, 1), "micro_sell_weight": round(sell, 1), "micro_delta_percent": round(micro_delta, 1),
            "score": round(speed_score, 1),
            "pressure": "BUYING" if speed_score > 5 else "SELLING" if speed_score < -5 else "BALANCED",
            "note": "Calculated from unique MT5 quote changes only; repeated polling samples are excluded.",
        }

    def _activity_metrics(self) -> dict[str, Any]:
        bars = self.frame_bars.get("M1", [])
        lookback = min(15, len(bars))
        selected = bars[-lookback:] if lookback else []
        buy_activity = 0.0; sell_activity = 0.0
        for b in selected:
            span = max(b["high"] - b["low"], self.point)
            clv = clamp((2.0 * b["close"] - b["high"] - b["low"]) / span, -1.0, 1.0)
            direction = clamp((b["close"] - b["open"]) / span, -1.0, 1.0)
            buy_share = clamp(0.50 + 0.26 * clv + 0.18 * direction, 0.06, 0.94)
            volume = max(0.0, b.get("tick_volume", 0.0))
            buy_activity += volume * buy_share
            sell_activity += volume * (1.0 - buy_share)
        total_activity = buy_activity + sell_activity
        buy_percent = buy_activity / total_activity * 100 if total_activity else 50.0
        sell_percent = sell_activity / total_activity * 100 if total_activity else 50.0

        now = time.time()
        recent = [p for p in self.tick_history if p[0] >= now - 60]
        buy_samples = sell_samples = flat_samples = 0
        buy_weight = sell_weight = 0.0
        for previous, item in zip(recent, recent[1:]):
            bid_delta = item[3] - previous[3]; ask_delta = item[4] - previous[4]; mid_delta = item[1] - previous[1]
            weight = 1.0 + min(4.0, abs(mid_delta) / max(self.point, 1e-9) * 0.18)
            if bid_delta > 0 and ask_delta > 0 or mid_delta > 0:
                buy_samples += 1; buy_weight += weight
            elif bid_delta < 0 and ask_delta < 0 or mid_delta < 0:
                sell_samples += 1; sell_weight += weight
            else:
                flat_samples += 1
        directional = buy_weight + sell_weight
        live_buy_percent = buy_weight / directional * 100 if directional else 50.0
        live_sell_percent = sell_weight / directional * 100 if directional else 50.0
        score = clamp((buy_percent - sell_percent) * 0.20 + (live_buy_percent - live_sell_percent) * 0.12, -18, 18)
        dominant = "BUY-SIDE" if score > 3 else "SELL-SIDE" if score < -3 else "BALANCED"
        return {
            "status": "LIVE" if selected and len(recent) >= 3 else "WARMING UP",
            "lookback_minutes": lookback,
            "buy_activity": int(round(buy_activity)), "sell_activity": int(round(sell_activity)), "net_activity": int(round(buy_activity - sell_activity)),
            "buy_percent": round(buy_percent, 1), "sell_percent": round(sell_percent, 1),
            "live_buy_samples": buy_samples, "live_sell_samples": sell_samples, "live_flat_samples": flat_samples,
            "live_buy_percent": round(live_buy_percent, 1), "live_sell_percent": round(live_sell_percent, 1),
            "dominant_side": dominant, "score": round(score, 1),
            "quantity_unit": "estimated broker activity units",
            "identity": "Anonymous broker-feed activity; participant names are unavailable",
            "note": "Completed M1 volume is split using candle close-location and body direction, then confirmed by unique live quote changes. It is not exact executed bank lots.",
        }

    def _data_quality(self, tick: dict[str, Any], speed: dict[str, Any]) -> dict[str, Any]:
        now = time.time()
        tick_age = max(0.0, now - as_float(tick.get("time"), now))
        recent = [p for p in self.tick_history if p[0] >= now - 60]
        spreads = [p[2] for p in recent if p[2] >= 0]
        median_spread = sorted(spreads)[len(spreads) // 2] if spreads else max(1.0, as_float(tick.get("spread_points")))
        spread_ratio = as_float(tick.get("spread_points")) / max(median_spread, 1e-9)
        score = 100.0
        reasons: list[str] = []
        if tick_age > 2.5:
            score -= min(55.0, (tick_age - 2.5) * 10.0); reasons.append("Delayed MT5 tick")
        if len(recent) < 15:
            score -= 35; reasons.append("Too few unique ticks in 60 seconds")
        elif len(recent) < 45:
            score -= 15; reasons.append("Moderate unique-tick coverage")
        if spread_ratio > 2.2:
            score -= 28; reasons.append("Spread unstable versus 60-second median")
        elif spread_ratio > 1.6:
            score -= 12; reasons.append("Spread above recent norm")
        if not self.frames or any(len(self.frame_bars.get(tf, [])) < 200 for tf in ("M1", "M5", "M15")):
            score -= 22; reasons.append("Insufficient completed-candle history")
        max_spread = as_float(self.settings.get("max_spread_points", 120), 120)
        if as_float(tick.get("spread_points")) > max_spread:
            score -= 35; reasons.append("Absolute spread safety limit exceeded")
        score = clamp(score, 0, 100)

        high_score = as_float(self.frames.get("H1", {}).get("score")) * 0.65 + as_float(self.frames.get("H4", {}).get("score")) * 0.35
        fast_score = as_float(self.frames.get("M1", {}).get("score")) * 0.30 + as_float(self.frames.get("M5", {}).get("score")) * 0.45 + as_float(self.frames.get("M15", {}).get("score")) * 0.25
        conflict = high_score * fast_score < 0 and abs(high_score) >= 22 and abs(fast_score) >= 22
        if conflict:
            score = max(0.0, score - 12.0); reasons.append("Fast and higher timeframes conflict")

        regimes = [str(self.frames.get(tf, {}).get("regime", "")) for tf in ("M5", "M15", "H1")]
        regime = max(set(regimes), key=regimes.count) if regimes else "UNKNOWN"
        state = "HIGH" if score >= 82 else "GOOD" if score >= 68 else "CAUTION" if score >= 52 else "LOW"
        return {
            "score": int(round(score)), "state": state, "tick_age_seconds": round(tick_age, 2),
            "unique_ticks_60s": len(recent), "spread_median_points": round(median_spread, 1),
            "spread_ratio": round(spread_ratio, 2), "timeframe_conflict": conflict,
            "fast_timeframe_score": round(fast_score, 1), "higher_timeframe_score": round(high_score, 1),
            "market_regime": regime, "reasons": reasons,
        }

    def _profile_score(self, current: float) -> float:
        vp = self.volume_profile
        if vp.get("status") != "LIVE":
            return 0.0
        poc = as_float(vp.get("poc"))
        vah = as_float(vp.get("vah"))
        val = as_float(vp.get("val"))
        if current > vah:
            return 10.0
        if current < val:
            return -10.0
        return clamp((current - poc) / max(vah - val, self.point) * 12.0, -6, 6)

    def _publish_signal(self, raw: str, score: float) -> str:
        state = self.signal_state
        if raw == state.candidate:
            state.cycles += 1
        else:
            state.candidate = raw
            state.cycles = 1
        required = max(1, int(self.settings.get("signal_confirm_cycles", 2)))
        if abs(score) >= 70:
            required = 1
        reversing = ("BUY" in state.published and "SELL" in raw) or ("SELL" in state.published and "BUY" in raw)
        if reversing:
            required += 1
        if raw == "WAIT" or state.cycles >= required:
            if state.published != raw:
                state.published = raw
                state.published_at = time.time()
        return state.published

    def _build_dashboard(self, tick: dict[str, Any]) -> dict[str, Any]:
        if not self.frames:
            return self._offline_dashboard("Loading completed candle history")
        frame_score = sum(as_float(self.frames[tf].get("score")) * TF_WEIGHTS[tf] for tf in TF_MAP)
        m1_atr = as_float(self.frames["M1"].get("atr14"), self.point * 50)
        speed = self._speed_metrics(tick["mid"], m1_atr)
        activity = self._activity_metrics()
        self.pro_flow.update(self.tick_history, self.frame_bars, self.volume_profile, self.smc, tick["mid"], self.point, self.digits, self.frames)
        exchange_flow = self.pro_flow.exchange_summary(tick["mid"])
        local_flow = self.pro_flow.local_summary()
        pro_flow = self.pro_flow.summary(tick["mid"])
        pro_status = str(pro_flow.get("status", ""))
        exact_exchange_live = str(exchange_flow.get("status", "")) in {"REAL CME", "REAL EXCHANGE"}
        pro_flow_score = as_float(exchange_flow.get("score")) if exact_exchange_live else as_float(local_flow.get("score")) if str(local_flow.get("status", "")) == "LIVE MT5 ESTIMATE" else 0.0
        pro_flow_weight = 0.95 if exact_exchange_live else as_float(self.settings.get("local_flow_signal_weight", 0.55), 0.55)
        intelligence = self.institution_intelligence.summary()
        intelligence_status = str(intelligence.get("status", ""))
        intelligence_score = as_float(intelligence.get("score")) if intelligence_status in {"LIVE", "PARTIAL", "CACHED"} else 0.0
        intelligence_weight = as_float(self.settings.get("institution_signal_weight", 0.35), 0.35)
        order_flow_lab = self.order_flow_proxy.update(
            self.tick_history, self.frame_bars.get("M1", []), tick["mid"], self.point, self.digits, self.volume_profile, self.smc
        )
        order_flow_status = str(order_flow_lab.get("status", ""))
        order_flow_score = as_float(order_flow_lab.get("score")) if order_flow_status == "LIVE MT5 ORDER-FLOW PROXY" else 0.0
        order_flow_weight = as_float(self.settings.get("order_flow_proxy_signal_weight", 0.35), 0.35)
        profile_score = self._profile_score(tick["mid"])
        smc_score = as_float(self.smc.get("score"))
        cot_score = as_float(self.cot.get("score")) if self.cot.get("status") in {"LIVE", "CACHED"} else 0.0
        activity_score = as_float(activity.get("score"))
        quality = self._data_quality(tick, speed)
        global_flow = self.global_gold_flow.build(exchange_flow, local_flow, self.cot, intelligence, order_flow_lab)

        components = {
            "timeframes": frame_score * 0.65,
            "fast_pressure": as_float(speed.get("score")) * 0.35,
            "activity": activity_score * 0.25,
            "volume_profile": profile_score * 0.75,
            "smart_money": smc_score * 0.45,
            "cot": cot_score * 0.25,
            "institution_intelligence": intelligence_score * intelligence_weight,
            "pro_flow": pro_flow_score * pro_flow_weight,
            "order_flow_proxy_lab": order_flow_score * order_flow_weight,
            "global_flow_alignment": as_float(global_flow.get("confirmation_score")),
        }
        # Keep every v1.7 component visible, but prevent correlated indicators from
        # multiplying the same market move. The grouped score is the live decision
        # score; legacy_total is retained for audit and comparison.
        legacy_total = clamp(sum(components.values()), -100, 100)
        evidence_groups = {
            "trend_context": clamp(components["timeframes"], -42, 42),
            "structure_location": clamp(components["volume_profile"] + components["smart_money"], -22, 22),
            "live_flow": clamp(
                components["fast_pressure"] + components["activity"] + components["pro_flow"]
                + components["order_flow_proxy_lab"] + components["global_flow_alignment"], -28, 28
            ),
            "macro_bias": clamp(components["cot"] + components["institution_intelligence"], -8, 8),
        }
        total = sum(evidence_groups.values())
        if quality.get("timeframe_conflict"):
            total *= 0.66
        if global_flow.get("cross_market_conflict"):
            total *= 0.82
        regime = str(quality.get("market_regime", "TRANSITION"))
        if regime == "RANGE":
            total *= 0.82
        elif regime == "HIGH VOLATILITY":
            total *= 0.88
        total = clamp(total, -100, 100)

        buy_threshold = as_float(self.settings.get("buy_threshold", 30), 30)
        strong_threshold = as_float(self.settings.get("strong_threshold", 54), 54)
        if regime == "RANGE":
            buy_threshold += 6; strong_threshold += 6
        if total >= strong_threshold:
            raw = "STRONG BUY"
        elif total >= buy_threshold:
            raw = "BUY"
        elif total <= -strong_threshold:
            raw = "STRONG SELL"
        elif total <= -buy_threshold:
            raw = "SELL"
        else:
            raw = "WAIT"

        warnings: list[str] = []
        max_spread = as_float(self.settings.get("max_spread_points", 120), 120)
        if tick["spread_points"] > max_spread:
            raw = "WAIT"; warnings.append(f"Spread is high: {tick['spread_points']:.0f} points")
        if as_float(quality.get("spread_ratio")) > 2.2:
            raw = "WAIT"; warnings.append("Spread is abnormally wide versus the recent median")
        if abs(as_float(speed.get("move_3s"))) > m1_atr * 0.42:
            raw = "WAIT"; warnings.append("Abnormal 3-second move detected; wait for stabilization")
        tick_age = max(0.0, time.time() - tick["time"])
        market_closed = tick_age > 30 and likely_weekend_market_closed()
        if market_closed:
            raw = "WAIT"
            warnings.append("Market is closed or the broker is waiting to resume gold quotes")
        elif tick_age > 5:
            raw = "WAIT"; warnings.append("MT5 tick is stale")
        if as_float(quality.get("score")) < as_float(self.settings.get("minimum_data_quality", 55), 55):
            raw = "WAIT"; warnings.append(f"Data quality is {quality.get('state', 'LOW')} ({quality.get('score', 0)}/100)")
        if quality.get("timeframe_conflict") and abs(total) < strong_threshold + 8:
            raw = "WAIT"; warnings.append("Fast and higher timeframes are conflicting")
        if pro_status == "WARMING UP":
            warnings.append("Professional-activity estimate is warming up")
        if order_flow_status == "WARMING UP":
            warnings.append("Order-flow proxy is warming up")
        if global_flow.get("cross_market_conflict"):
            warnings.append("COMEX futures flow conflicts with the MT5 XAUUSD flow; confidence reduced")
            if abs(total) < strong_threshold + 10:
                raw = "WAIT"

        published = self._publish_signal(raw, total)
        direction = 1 if "BUY" in published else -1 if "SELL" in published else 0
        signed_components = [v for v in components.values() if abs(v) >= 1.0]
        signed_groups = [v for v in evidence_groups.values() if abs(v) >= 1.0]
        if direction:
            same_components = sum(abs(v) for v in signed_components if v * direction > 0)
            component_weight = sum(abs(v) for v in signed_components) or 1.0
            component_agreement = same_components / component_weight * 100
            same_groups = sum(abs(v) for v in signed_groups if v * direction > 0)
            group_weight = sum(abs(v) for v in signed_groups) or 1.0
            group_agreement = same_groups / group_weight * 100
            strength = clamp(abs(total) / max(strong_threshold, 1.0) * 100, 0, 100)
            alignment = int(round(clamp(as_float(quality.get("score")) * 0.45 + group_agreement * 0.35 + strength * 0.20, 0, 94)))
        else:
            component_agreement = 0.0
            group_agreement = 0.0
            alignment = int(round(clamp(as_float(quality.get("score")) * 0.55, 0, 65)))
        plan = self._trade_plan(tick["mid"], direction)
        reasons = self._signal_reasons(components, speed, quality, pro_status)
        if direction == 0:
            reasons.insert(0, "No-trade gate: evidence is not aligned strongly and safely enough")

        price_series = [{"time": iso_utc(b["time"]), "close": round(b["close"], self.digits)} for b in self.frame_bars.get("M1", [])[-180:]]
        generated = time.time()
        return {
            "product": "AuRa X Signals", "version": VERSION, "generated_at": iso_utc(generated),
            "data_age_seconds": round(tick_age, 2),
            "mode": "MARKET CLOSED · WAITING FOR TICKS" if market_closed else "LIVE MT5 · NO-KEY CORE",
            "symbol": self.symbol, "broker": self.broker,
            "price": {"bid": round(tick["bid"], self.digits), "ask": round(tick["ask"], self.digits), "mid": round(tick["mid"], self.digits), "spread_points": round(tick["spread_points"], 1), "tick_time": iso_utc(tick["time"])},
            "signal": {
                "action": published, "raw_action": raw, "score": round(total, 1), "legacy_score": round(legacy_total, 1), "alignment_confidence": alignment,
                "component_agreement": round(component_agreement, 1), "group_agreement": round(group_agreement, 1), "published_at": iso_utc(self.signal_state.published_at) if self.signal_state.published_at else None,
                "horizon": "Fast intraday confirmation", "reasons": reasons, "warnings": warnings,
                "meaning": self._simple_meaning(published), "thresholds": {"trade": round(buy_threshold, 1), "strong": round(strong_threshold, 1)},
                "components": {k: round(v, 1) for k, v in components.items()},
                "evidence_groups": {k: round(v, 1) for k, v in evidence_groups.items()},
                "score_method": "Correlation-aware grouped evidence; all legacy components remain visible",
            },
            "trade_plan": plan, "timeframes": self.frames,
            "institutional": {"volume_profile": self.volume_profile, "cot": self.cot, "intelligence": intelligence, "order_flow_proxy": speed, "activity_quantity": activity, "pro_flow": pro_flow, "order_flow_lab": order_flow_lab, "global_gold_flow": global_flow},
            "smart_money": self.smc, "data_quality": quality, "market_regime": regime,
            "price_series": price_series,
            "system": {
                "mt5": "CONNECTED",
                "engine": "WAITING" if market_closed else "LIVE",
                "market": "CLOSED" if market_closed else "OPEN",
                "desktop_interface": True,
                "automatic_trading": False,
                "calculation": "Hybrid MT5 XAUUSD analysis with optional exact GC/MGC futures trade flow, public LBMA liquidity context, CFTC positioning, SMC and safety gates",
                "disclaimer": "Alignment is not a win probability. Exact global spot XAUUSD volume does not exist; exact volume is only for a connected exchange futures contract.",
            },
        }

    def _signal_reasons(self, components: dict[str, float], speed: dict[str, Any], quality: dict[str, Any], pro_flow_status: str) -> list[str]:
        labels = {
            "timeframes": "Multi-timeframe direction",
            "fast_pressure": f"Unique-tick pressure ({speed.get('pressure', 'BALANCED')})",
            "activity": "Estimated buy/sell activity",
            "volume_profile": "Volume profile and VWAP position",
            "smart_money": "Smart-money price structure",
            "cot": "Weekly CFTC COT confirmation",
            "institution_intelligence": "Cached public institution intelligence (CFTC Bank Participation + SEC 13F)",
            "pro_flow": f"Professional-activity layer ({pro_flow_status})",
            "order_flow_proxy_lab": "No-key tape, footprint and reaction-heatmap confirmation",
            "global_flow_alignment": "Cross-market agreement across COMEX, MT5 spot and public positioning layers",
        }
        items = [(abs(value), f"{labels.get(key, key)}: {value:+.1f}") for key, value in components.items()]
        items.sort(reverse=True, key=lambda x: x[0])
        output = [text for _, text in items]
        output.append(f"Data quality: {quality.get('state', '—')} ({quality.get('score', 0)}/100) · regime {quality.get('market_regime', '—')}")
        return output

    def _trade_plan(self, price: float, direction: int) -> dict[str, Any]:
        if direction == 0:
            return {
                "status": "NO TRADE", "direction": "WAIT",
                "entry_low": None, "entry_high": None, "stop_loss": None, "tp1": None, "tp2": None,
                "risk_reward_tp1": None, "risk_reward_tp2": None,
                "invalidation": "Wait until data quality, spread, timeframe direction and structure align.",
            }
        a1 = as_float(self.frames.get("M1", {}).get("atr14"), self.point * 70)
        a5 = as_float(self.frames.get("M5", {}).get("atr14"), a1 * 2)
        entry_half = max(a1 * 0.10, self.point * 6)
        risk_floor = max(a5 * 0.68, a1 * 1.05, self.point * 35)
        # Old liquidity zones can be far from the live market. Bound the structural
        # stop so an outdated zone cannot silently create an oversized trade plan.
        risk_cap = max(risk_floor * 1.65, a5 * 1.25)
        vp = self.volume_profile; smc = self.smc

        def sane_target(candidate: float, fallback: float, minimum: float, maximum: float, side: int) -> float:
            distance = (candidate - price) * side
            if minimum <= distance <= maximum:
                return candidate
            return fallback

        if direction > 0:
            ob = smc.get("bullish_order_block") or {}
            if ob and as_float(ob.get("high")) >= price - a5 * 0.8 and as_float(ob.get("low")) <= price + a5 * 0.25:
                entry_low = max(as_float(ob.get("low")), price - a5 * 0.45); entry_high = min(as_float(ob.get("high")), price + entry_half)
            else:
                entry_low, entry_high = price - entry_half, price + entry_half
            structural_sl = min(as_float(smc.get("sell_side_liquidity"), price - risk_floor), as_float(ob.get("low"), price - risk_floor)) - a1 * 0.15
            sl = clamp(structural_sl, price - risk_cap, price - risk_floor)
            risk = max(price - sl, risk_floor)
            first_target = as_float(smc.get("buy_side_liquidity"), price + risk * 1.10)
            tp1 = sane_target(first_target, price + risk * 1.10, risk, risk * 1.55, 1)
            profile_target = as_float(vp.get("vah"), price + risk * 1.85)
            tp2 = sane_target(profile_target, price + risk * 1.85, risk * 1.55, risk * 2.40, 1)
            if tp2 <= tp1:
                tp2 = price + risk * 1.85
            invalidation = "Invalid if M5 closes below the stop zone, data quality drops, or the signal returns to WAIT/SELL."
            label = "BUY"
        else:
            ob = smc.get("bearish_order_block") or {}
            if ob and as_float(ob.get("low")) <= price + a5 * 0.8 and as_float(ob.get("high")) >= price - a5 * 0.25:
                entry_low = max(as_float(ob.get("low")), price - entry_half); entry_high = min(as_float(ob.get("high")), price + a5 * 0.45)
            else:
                entry_low, entry_high = price - entry_half, price + entry_half
            structural_sl = max(as_float(smc.get("buy_side_liquidity"), price + risk_floor), as_float(ob.get("high"), price + risk_floor)) + a1 * 0.15
            sl = clamp(structural_sl, price + risk_floor, price + risk_cap)
            risk = max(sl - price, risk_floor)
            first_target = as_float(smc.get("sell_side_liquidity"), price - risk * 1.10)
            tp1 = sane_target(first_target, price - risk * 1.10, risk, risk * 1.55, -1)
            profile_target = as_float(vp.get("val"), price - risk * 1.85)
            tp2 = sane_target(profile_target, price - risk * 1.85, risk * 1.55, risk * 2.40, -1)
            if tp2 >= tp1:
                tp2 = price - risk * 1.85
            invalidation = "Invalid if M5 closes above the stop zone, data quality drops, or the signal returns to WAIT/BUY."
            label = "SELL"
        rr1 = abs(tp1 - price) / max(abs(price - sl), self.point)
        rr2 = abs(tp2 - price) / max(abs(price - sl), self.point)
        return {
            "status": "ACTIVE", "direction": label,
            "entry_low": round(min(entry_low, entry_high), self.digits), "entry_high": round(max(entry_low, entry_high), self.digits),
            "stop_loss": round(sl, self.digits), "tp1": round(tp1, self.digits), "tp2": round(tp2, self.digits),
            "risk_reward_tp1": round(rr1, 2), "risk_reward_tp2": round(rr2, 2),
            "invalidation": invalidation,
            "note": "Structure-and-volatility guidance only. Verify position size and broker execution before any manual trade.",
        }

    def _simple_meaning(self, signal: str) -> str:
        if signal == "STRONG BUY":
            return "Most live and higher-timeframe inputs agree upward. Still check spread and stop-loss."
        if signal == "BUY":
            return "Upward evidence is stronger than downward evidence, but confirmation is not perfect."
        if signal == "STRONG SELL":
            return "Most live and higher-timeframe inputs agree downward. Still check spread and stop-loss."
        if signal == "SELL":
            return "Downward evidence is stronger than upward evidence, but confirmation is not perfect."
        return "There is no clean alignment now. The safest output is to wait."

    def _offline_dashboard(self, reason: str) -> dict[str, Any]:
        market_closed = likely_weekend_market_closed()
        mode = "MARKET CLOSED · WAITING FOR TICKS" if market_closed else "OFFLINE · NO-KEY CORE"
        action = "MARKET CLOSED" if market_closed else "DATA OFFLINE"
        meaning = "The gold market is closed or the broker has not resumed quotes yet." if market_closed else "Start MT5 and the Windows signal engine."
        return {
            "product": "AuRa X Signals", "version": VERSION, "generated_at": iso_utc(), "data_age_seconds": None,
            "mode": mode, "symbol": self.symbol, "broker": self.broker,
            "price": {"bid": None, "ask": None, "mid": None, "spread_points": None, "tick_time": None},
            "signal": {
                "action": action, "raw_action": action, "score": 0, "legacy_score": 0, "alignment_confidence": 0,
                "component_agreement": 0, "group_agreement": 0, "published_at": None, "horizon": "—", "reasons": [], "warnings": [reason],
                "meaning": meaning, "components": {}, "evidence_groups": {}, "score_method": "Correlation-aware grouped evidence",
            },
            "trade_plan": {"status": "NO TRADE", "direction": "WAIT", "entry_low": None, "entry_high": None, "stop_loss": None, "tp1": None, "tp2": None, "invalidation": reason},
            "timeframes": self.frames,
            "institutional": {"volume_profile": self.volume_profile, "cot": self.cot, "intelligence": self.institution_intelligence.summary(), "order_flow_proxy": {}, "activity_quantity": {"status": "OFFLINE"}, "pro_flow": self.pro_flow.summary(None), "order_flow_lab": self.order_flow_proxy.summary(), "global_gold_flow": self.global_gold_flow.build(self.pro_flow.exchange_summary(None), self.pro_flow.local_summary(), self.cot, self.institution_intelligence.summary(), self.order_flow_proxy.summary())},
            "smart_money": self.smc,
            "data_quality": {"score": 0, "state": "LOW", "market_regime": "UNKNOWN", "unique_ticks_60s": 0, "reasons": [reason]},
            "validation": self.signal_validation.summary() if hasattr(self, "signal_validation") else SignalValidationJournal.empty_summary("WAITING"),
            "market_regime": "UNKNOWN", "price_series": [],
            "system": {"mt5": "OFFLINE", "engine": "WAITING", "market": "CLOSED" if market_closed else "UNKNOWN", "desktop_interface": True, "automatic_trading": False, "calculation": "Waiting for a fresh MT5 quote", "disclaimer": "No signal is published without live MT5 data."},
        }

    @staticmethod
    def _empty_volume_profile() -> dict[str, Any]:
        return {"status": "OFFLINE", "source": "MT5 broker tick-volume profile", "poc": None, "vah": None, "val": None, "session_vwap": None, "location": "—", "bias": "—", "high_volume_nodes": [], "rows": [], "note": "Waiting for M1 data."}

    @staticmethod
    def _empty_smc() -> dict[str, Any]:
        return {"status": "OFFLINE", "structure": "—", "prior_structure": "—", "bos": "NONE", "choch": "NONE", "liquidity_sweep": "NONE", "nearest_order_block": "NONE", "bullish_order_block": None, "bearish_order_block": None, "bullish_fvg": None, "bearish_fvg": None, "dealing_range": "—", "liquidity_pools": [], "buy_side_liquidity": None, "sell_side_liquidity": None, "score": 0, "note": "Waiting for M5 data."}

    @staticmethod
    def _empty_cot(error: str) -> dict[str, Any]:
        return {"status": "OFFLINE", "source": "Official CFTC Disaggregated Futures Only", "report_date": "—", "open_interest": None, "managed_money_long": None, "managed_money_short": None, "managed_money_net": None, "weekly_net_change": None, "net_percent_open_interest": None, "bias": "UNAVAILABLE", "score": 0, "age_days": None, "total_reported_traders": None, "categories": [], "quantity_unit": "COMEX Gold futures contracts", "identity": {"available_level": "CFTC trader category", "individual_names_available": False, "note": "Individual institution names are not public."}, "note": "COT refresh unavailable: " + error}
