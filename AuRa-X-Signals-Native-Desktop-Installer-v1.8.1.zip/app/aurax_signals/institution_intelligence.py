from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from typing import Any
import calendar
import json
import math
import re
import threading
import time
import urllib.request
import xml.etree.ElementTree as ET


VERSION = "1.8.1"


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _as_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        return float(str(value).replace(",", "").strip())
    except Exception:
        return default


def _iso(ts: float | None = None) -> str:
    return datetime.fromtimestamp(ts if ts is not None else time.time(), timezone.utc).isoformat()


def _age_days(date_text: str | None) -> int | None:
    if not date_text:
        return None
    try:
        dt = datetime.fromisoformat(str(date_text)[:10]).replace(tzinfo=timezone.utc)
        return max(0, (datetime.now(timezone.utc) - dt).days)
    except Exception:
        return None


class _TableParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.rows: list[list[str]] = []
        self._row: list[str] | None = None
        self._cell: list[str] | None = None
        self.all_text: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        if tag == "tr":
            self._row = []
        elif tag in {"td", "th"} and self._row is not None:
            self._cell = []

    def handle_data(self, data: str) -> None:
        text = " ".join(data.split())
        if not text:
            return
        self.all_text.append(text)
        if self._cell is not None:
            self._cell.append(text)

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in {"td", "th"} and self._cell is not None and self._row is not None:
            self._row.append(" ".join(self._cell).strip())
            self._cell = None
        elif tag == "tr" and self._row is not None:
            if any(self._row):
                self.rows.append(self._row)
            self._row = None


@dataclass
class _HttpClient:
    user_agent: str

    def get_bytes(self, url: str, timeout: float = 18.0) -> bytes:
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": self.user_agent,
                "Accept-Encoding": "identity",
                "Accept": "application/json, application/xml, text/xml, text/html, */*",
            },
        )
        with urllib.request.urlopen(req, timeout=timeout) as response:
            return response.read()

    def get_text(self, url: str, timeout: float = 18.0) -> str:
        return self.get_bytes(url, timeout=timeout).decode("utf-8", errors="replace")

    def get_json(self, url: str, timeout: float = 18.0) -> Any:
        return json.loads(self.get_text(url, timeout=timeout))


class InstitutionIntelligence:
    """Slow public-data collector isolated from the live MT5 loop.

    The collector refreshes official CFTC Bank Participation data and named SEC
    13F gold-ETF disclosures in a daemon thread. The engine only reads an
    in-memory snapshot, so network delays cannot freeze tick processing.
    """

    DEFAULT_MANAGERS = [
        "BLACKROCK INC",
        "JPMORGAN CHASE & CO",
        "GOLDMAN SACHS GROUP INC",
        "MORGAN STANLEY",
        "BANK OF AMERICA CORP",
        "STATE STREET CORP",
    ]

    GOLD_KEYWORDS = (
        "SPDR GOLD",
        "ISHARES GOLD TRUST",
        "ABRDN PHYSICAL GOLD",
        "SPROTT PHYSICAL GOLD",
        "VANECK GOLD MINERS",
        "VANECK JUNIOR GOLD MINERS",
        "FRANKLIN RESPONSIBLY SOURCED GOLD",
        "GRANITESHARES GOLD",
        "GOLDMAN SACHS PHYSICAL GOLD",
    )

    def __init__(self, root: str | Path, settings: dict[str, Any]):
        self.root = Path(root)
        self.settings = settings
        self.cache_path = self.root / "config" / "institution_intelligence_cache.json"
        self.lock = threading.RLock()
        self.running = False
        self.thread: threading.Thread | None = None
        self.refresh_event = threading.Event()
        self.last_attempt = 0.0
        self.client = _HttpClient(
            str(settings.get("public_data_user_agent") or "AuRa X Signals/1.8.1 local research tool contact: user@example.com")
        )
        self.data: dict[str, Any] = self._empty("Waiting for public-source refresh")
        self._load_cache()

    def _load_cache(self) -> None:
        try:
            if self.cache_path.is_file():
                cached = json.loads(self.cache_path.read_text(encoding="utf-8"))
                cached["status"] = "CACHED"
                cached["collector_state"] = "READY"
                self.data = cached
        except Exception:
            pass

    def start(self) -> None:
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True, name="aurax-institution-intelligence")
        self.thread.start()

    def stop(self) -> None:
        self.running = False
        self.refresh_event.set()
        if self.thread:
            self.thread.join(timeout=2.5)

    def request_refresh(self) -> dict[str, Any]:
        remaining = 300.0 - (time.time() - self.last_attempt)
        if remaining > 0:
            return {"ok": False, "queued": False, "retry_after_seconds": int(math.ceil(remaining)), "message": "Public-source refresh is rate-limited to protect official websites."}
        self.refresh_event.set()
        return {"ok": True, "queued": True, "message": "Institution Intelligence refresh queued in the background."}

    def summary(self) -> dict[str, Any]:
        with self.lock:
            return json.loads(json.dumps(self.data))

    def _loop(self) -> None:
        # Small startup pause lets MT5 and the desktop interface become available first.
        self.refresh_event.wait(timeout=3.0)
        while self.running:
            refresh_hours = max(1.0, _as_float(self.settings.get("institution_refresh_hours", 12), 12))
            updated_at = _as_float(self.data.get("updated_at_epoch"), 0.0)
            due = time.time() - updated_at >= refresh_hours * 3600
            if due or self.refresh_event.is_set():
                self.refresh_event.clear()
                self._refresh()
            self.refresh_event.wait(timeout=60.0)

    def _refresh(self) -> None:
        self.last_attempt = time.time()
        prior = self.summary()
        with self.lock:
            self.data["collector_state"] = "REFRESHING"
            self.data["last_attempt"] = _iso(self.last_attempt)

        errors: list[str] = []
        bank = prior.get("bank_participation", {})
        sec = prior.get("named_institutions", {})

        if self.settings.get("bank_participation_enabled", True):
            try:
                bank = self._fetch_bank_participation()
            except Exception as exc:
                errors.append(f"CFTC Bank Participation: {exc}")
                if bank:
                    bank["status"] = "CACHED"
                    bank["refresh_error"] = str(exc)
                else:
                    bank = self._empty_bank(str(exc))

        if self.settings.get("sec_13f_enabled", True):
            try:
                sec = self._fetch_sec_13f()
            except Exception as exc:
                errors.append(f"SEC 13F: {exc}")
                if sec:
                    sec["status"] = "CACHED"
                    sec["refresh_error"] = str(exc)
                else:
                    sec = self._empty_sec(str(exc))

        bank_score = _as_float(bank.get("score")) if bank.get("status") in {"LIVE", "CACHED"} else 0.0
        sec_score = _as_float(sec.get("score")) if sec.get("status") in {"LIVE", "CACHED"} else 0.0
        score = round(_clamp(bank_score + sec_score, -8.0, 8.0), 2)
        if score >= 2.5:
            bias = "BULLISH"
        elif score <= -2.5:
            bias = "BEARISH"
        elif score > 0.75:
            bias = "SLIGHTLY BULLISH"
        elif score < -0.75:
            bias = "SLIGHTLY BEARISH"
        else:
            bias = "NEUTRAL"

        payload = {
            "status": "LIVE" if not errors else "PARTIAL",
            "collector_state": "READY",
            "updated_at": _iso(),
            "updated_at_epoch": time.time(),
            "last_attempt": _iso(self.last_attempt),
            "source_mode": "OFFICIAL PUBLIC SOURCES · NO API KEY",
            "bias": bias,
            "score": score,
            "bank_participation": bank,
            "named_institutions": sec,
            "errors": errors,
            "prediction_use": {
                "role": "Slow higher-timeframe bias only",
                "maximum_engine_effect": "Small tie-breaker; never controls entry alone",
                "live_engine_blocking": False,
                "note": "Public reports are delayed. Live MT5 flow, structure, spread and data quality remain the main entry engine.",
            },
            "identity_limit": "Named SEC filers can be shown for delayed disclosed holdings. Live order identity remains unavailable.",
        }
        with self.lock:
            self.data = payload
        try:
            self.cache_path.parent.mkdir(parents=True, exist_ok=True)
            self.cache_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    def _bpr_url(self, year: int, month: int) -> str:
        mon = calendar.month_abbr[month].lower()
        return f"https://www.cftc.gov/MarketReports/BankParticipation/dea{mon}{str(year)[-2:]}f"

    def _parse_bpr(self, html: str, source_url: str) -> dict[str, Any]:
        parser = _TableParser()
        parser.feed(html)
        report_date = ""
        joined = " ".join(parser.all_text)
        match = re.search(r"REPORT\s+DATE\s*:\s*(\d{1,2}/\d{1,2}/\d{4})", joined, re.I)
        if match:
            report_date = datetime.strptime(match.group(1), "%m/%d/%Y").date().isoformat()

        gold_index = None
        for i, row in enumerate(parser.rows):
            normalized = [" ".join(cell.split()) for cell in row]
            if any("CMX GOLD" in cell.upper() for cell in normalized):
                gold_index = i
                break
        if gold_index is None:
            raise RuntimeError("CMX GOLD row was not found in the CFTC report")

        def parse_row(row: list[str], expected_type: str | None = None) -> dict[str, Any]:
            cells = [" ".join(x.split()) for x in row if x.strip()]
            if not cells:
                raise RuntimeError("Empty CFTC row")
            commodity = cells[0] if "CMX GOLD" in cells[0].upper() else "CMX GOLD"
            if "CMX GOLD" in cells[0].upper():
                cells = cells[1:]
            bank_type = cells[0] if cells and not re.fullmatch(r"[\d,\.]+", cells[0]) else (expected_type or "TOTAL")
            if cells and bank_type == cells[0]:
                cells = cells[1:]
            numbers = [_as_float(x, math.nan) for x in cells]
            numbers = [x for x in numbers if not math.isnan(x)]
            if len(numbers) < 5:
                raise RuntimeError(f"Unexpected CFTC GOLD row format: {row}")
            # Row format is bank count, long, long %, short, short %, open interest (first row only).
            if len(numbers) >= 6:
                count, long_v, long_pct, short_v, short_pct, oi = numbers[:6]
            else:
                count, long_v, long_pct, short_v, short_pct = numbers[:5]
                oi = 0.0
            return {
                "commodity": commodity,
                "bank_type": bank_type,
                "bank_count": int(count),
                "long": int(long_v),
                "long_percent_oi": round(long_pct, 2),
                "short": int(short_v),
                "short_percent_oi": round(short_pct, 2),
                "net": int(long_v - short_v),
                "open_interest": int(oi),
            }

        us = parse_row(parser.rows[gold_index], "U.S.")
        non_us = parse_row(parser.rows[gold_index + 1], "NON U.S.")
        combined = parse_row(parser.rows[gold_index + 2], "TOTAL")
        if not combined.get("open_interest"):
            combined["open_interest"] = us.get("open_interest", 0)
        return {
            "report_date": report_date,
            "source_url": source_url,
            "us_banks": us,
            "non_us_banks": non_us,
            "combined": combined,
        }

    def _fetch_bpr_candidate(self, year: int, month: int) -> dict[str, Any]:
        url = self._bpr_url(year, month)
        html = self.client.get_text(url, timeout=15)
        return self._parse_bpr(html, url)

    def _fetch_bank_participation(self) -> dict[str, Any]:
        now = datetime.now(timezone.utc)
        candidates: list[tuple[int, int]] = []
        year, month = now.year, now.month
        for _ in range(4):
            candidates.append((year, month))
            month -= 1
            if month == 0:
                month = 12
                year -= 1

        reports: list[dict[str, Any]] = []
        last_error = ""
        for year, month in candidates:
            try:
                report = self._fetch_bpr_candidate(year, month)
                if report.get("report_date"):
                    reports.append(report)
                if len(reports) >= 2:
                    break
            except Exception as exc:
                last_error = str(exc)
        if not reports:
            raise RuntimeError(last_error or "No recent CFTC Bank Participation report was available")

        current = reports[0]
        previous = reports[1] if len(reports) > 1 else None
        combined = current["combined"]
        previous_net = previous["combined"]["net"] if previous else combined["net"]
        monthly_change = int(combined["net"] - previous_net)
        oi = max(1, int(combined.get("open_interest") or current["us_banks"].get("open_interest") or 1))
        change_pct_oi = monthly_change / oi * 100.0
        # Banks often hedge. Direction uses month-over-month change rather than treating
        # their normal absolute short inventory as a direct trading signal.
        score = round(_clamp(change_pct_oi * 1.8, -4.0, 4.0), 2)
        if monthly_change > 0:
            interpretation = "BANK NET EXPOSURE IMPROVING"
        elif monthly_change < 0:
            interpretation = "BANK NET EXPOSURE WEAKENING"
        else:
            interpretation = "BANK EXPOSURE UNCHANGED"
        return {
            "status": "LIVE",
            "source": "Official CFTC Bank Participation Report · Futures",
            "report_date": current.get("report_date") or "—",
            "previous_report_date": previous.get("report_date") if previous else None,
            "age_days": _age_days(current.get("report_date")),
            "us_banks": current["us_banks"],
            "non_us_banks": current["non_us_banks"],
            "combined": combined,
            "monthly_net_change": monthly_change,
            "monthly_change_percent_oi": round(change_pct_oi, 3),
            "interpretation": interpretation,
            "score": score,
            "source_url": current.get("source_url"),
            "note": "Official monthly bank-category futures positions. Individual bank names are not published, and dealer hedging means absolute net-short exposure is not automatically a bearish entry signal.",
        }

    @staticmethod
    def _normalize_name(value: str) -> str:
        return re.sub(r"[^A-Z0-9]+", " ", value.upper()).strip()

    def _resolve_ciks(self, manager_names: list[str]) -> list[dict[str, Any]]:
        tickers = self.client.get_json("https://www.sec.gov/files/company_tickers.json", timeout=20)
        entries = list(tickers.values()) if isinstance(tickers, dict) else []
        resolved: list[dict[str, Any]] = []
        for wanted in manager_names:
            target = self._normalize_name(wanted)
            best: tuple[int, dict[str, Any]] | None = None
            for entry in entries:
                title = self._normalize_name(str(entry.get("title", "")))
                if not title:
                    continue
                score = 100 if title == target else 85 if target in title or title in target else 0
                if score and (best is None or score > best[0]):
                    best = (score, entry)
            if best:
                entry = best[1]
                resolved.append({"requested_name": wanted, "name": entry.get("title", wanted), "cik": int(entry.get("cik_str"))})
        return resolved

    @staticmethod
    def _recent_13f(submissions: dict[str, Any]) -> list[dict[str, str]]:
        recent = submissions.get("filings", {}).get("recent", {})
        forms = recent.get("form", [])
        accessions = recent.get("accessionNumber", [])
        report_dates = recent.get("reportDate", [])
        filing_dates = recent.get("filingDate", [])
        primary_docs = recent.get("primaryDocument", [])
        rows: list[dict[str, str]] = []
        for i, form in enumerate(forms):
            if str(form).upper() != "13F-HR":
                continue
            rows.append({
                "accession": str(accessions[i]),
                "report_date": str(report_dates[i]) if i < len(report_dates) else "",
                "filing_date": str(filing_dates[i]) if i < len(filing_dates) else "",
                "primary_document": str(primary_docs[i]) if i < len(primary_docs) else "",
            })
            if len(rows) >= 2:
                break
        return rows

    @staticmethod
    def _local_name(tag: str) -> str:
        return tag.rsplit("}", 1)[-1]

    def _parse_13f_information_table(self, text: str) -> list[dict[str, Any]]:
        docs = re.findall(r"<DOCUMENT>(.*?)</DOCUMENT>", text, flags=re.I | re.S)
        xml_text = ""
        for doc in docs:
            if re.search(r"<informationTable\b|<infoTable\b", doc, flags=re.I):
                match = re.search(r"<XML>(.*?)</XML>", doc, flags=re.I | re.S)
                xml_text = match.group(1).strip() if match else doc
                break
        if not xml_text:
            # Some EDGAR submissions expose the XML without DOCUMENT wrappers.
            match = re.search(r"(<(?:\w+:)?informationTable\b.*?</(?:\w+:)?informationTable>)", text, flags=re.I | re.S)
            xml_text = match.group(1) if match else ""
        if not xml_text:
            return []
        root = ET.fromstring(xml_text.encode("utf-8", errors="ignore"))
        rows: list[dict[str, Any]] = []
        for node in root.iter():
            if self._local_name(node.tag).lower() != "infotable":
                continue
            values: dict[str, str] = {}
            for child in node.iter():
                name = self._local_name(child.tag)
                text_value = (child.text or "").strip()
                if text_value:
                    values[name] = text_value
            issuer = values.get("nameOfIssuer", "")
            title = values.get("titleOfClass", "")
            combined_name = f"{issuer} {title}".upper()
            if not any(keyword in combined_name for keyword in self.GOLD_KEYWORDS):
                continue
            rows.append({
                "issuer": issuer,
                "title": title,
                "cusip": values.get("cusip", ""),
                "value_thousands_usd": int(_as_float(values.get("value"))),
                "shares": int(_as_float(values.get("sshPrnamt"))),
                "share_type": values.get("sshPrnamtType", ""),
            })
        return rows

    def _fetch_13f_table(self, cik: int, accession: str) -> list[dict[str, Any]]:
        folder = accession.replace("-", "")
        url = f"https://www.sec.gov/Archives/edgar/data/{cik}/{folder}/{accession}.txt"
        return self._parse_13f_information_table(self.client.get_text(url, timeout=25))

    @staticmethod
    def _manager_change(current: list[dict[str, Any]], previous: list[dict[str, Any]]) -> tuple[float, int, int]:
        prev_by_cusip = {str(x.get("cusip")): x for x in previous if x.get("cusip")}
        weighted_change = 0.0
        total_weight = 0.0
        increased = 0
        reduced = 0
        for item in current:
            key = str(item.get("cusip"))
            prev = prev_by_cusip.get(key, {})
            old_shares = _as_float(prev.get("shares"), 0.0)
            new_shares = _as_float(item.get("shares"), 0.0)
            weight = max(1.0, _as_float(item.get("value_thousands_usd"), 1.0))
            if old_shares > 0:
                change = (new_shares - old_shares) / old_shares * 100.0
            elif new_shares > 0:
                change = 100.0
            else:
                change = 0.0
            weighted_change += _clamp(change, -100, 100) * weight
            total_weight += weight
            if change > 1.0:
                increased += 1
            elif change < -1.0:
                reduced += 1
        current_cusips = {str(x.get("cusip")) for x in current}
        for item in previous:
            if str(item.get("cusip")) not in current_cusips and _as_float(item.get("shares")) > 0:
                reduced += 1
        return (weighted_change / total_weight if total_weight else 0.0, increased, reduced)

    def _fetch_sec_13f(self) -> dict[str, Any]:
        configured = self.settings.get("tracked_institutions")
        managers = [str(x) for x in configured] if isinstance(configured, list) and configured else list(self.DEFAULT_MANAGERS)
        resolved = self._resolve_ciks(managers)
        if not resolved:
            raise RuntimeError("Tracked SEC institutions could not be resolved")

        results: list[dict[str, Any]] = []
        errors: list[str] = []
        bullish = 0
        bearish = 0
        weighted_scores: list[float] = []
        newest_report = ""

        for manager in resolved[:8]:
            try:
                cik = int(manager["cik"])
                submissions = self.client.get_json(f"https://data.sec.gov/submissions/CIK{cik:010d}.json", timeout=20)
                filings = self._recent_13f(submissions)
                if not filings:
                    continue
                current = self._fetch_13f_table(cik, filings[0]["accession"])
                previous = self._fetch_13f_table(cik, filings[1]["accession"]) if len(filings) > 1 else []
                change_pct, increased, reduced = self._manager_change(current, previous)
                current_value = sum(int(x.get("value_thousands_usd", 0)) for x in current)
                current_shares = sum(int(x.get("shares", 0)) for x in current)
                if change_pct > 2.0:
                    action = "INCREASED"
                    bullish += 1
                elif change_pct < -2.0:
                    action = "REDUCED"
                    bearish += 1
                else:
                    action = "LITTLE CHANGE"
                report_date = filings[0].get("report_date", "")
                newest_report = max(newest_report, report_date)
                age = _age_days(report_date)
                age_factor = 1.0 if age is None or age <= 75 else 0.65 if age <= 120 else 0.25
                weighted_scores.append(_clamp(change_pct / 12.0, -1.0, 1.0) * age_factor)
                results.append({
                    "name": str(submissions.get("name") or manager.get("name") or manager["requested_name"]),
                    "cik": cik,
                    "report_date": report_date,
                    "filing_date": filings[0].get("filing_date"),
                    "age_days": age,
                    "gold_assets": current,
                    "gold_asset_count": len(current),
                    "reported_value_thousands_usd": current_value,
                    "reported_shares_total": current_shares,
                    "weighted_share_change_percent": round(change_pct, 2),
                    "assets_increased": increased,
                    "assets_reduced": reduced,
                    "action": action,
                    "source": "SEC EDGAR Form 13F-HR",
                    "delay_label": "QUARTERLY DELAYED DISCLOSURE",
                })
                # SEC asks automated clients to stay well below ten requests per second.
                time.sleep(0.12)
            except Exception as exc:
                errors.append(f"{manager.get('requested_name')}: {exc}")

        if not results:
            raise RuntimeError("No gold-related holdings were found in recent tracked 13F filings")
        average = sum(weighted_scores) / len(weighted_scores) if weighted_scores else 0.0
        score = round(_clamp(average * 4.0, -4.0, 4.0), 2)
        bias = "INCREASING GOLD EXPOSURE" if score > 1.0 else "REDUCING GOLD EXPOSURE" if score < -1.0 else "MIXED / STABLE"
        return {
            "status": "LIVE" if not errors else "PARTIAL",
            "source": "Official SEC EDGAR Form 13F-HR filings",
            "report_date": newest_report or "—",
            "age_days": _age_days(newest_report),
            "bias": bias,
            "score": score,
            "institutions_increased": bullish,
            "institutions_reduced": bearish,
            "institutions": results,
            "errors": errors,
            "note": "Named institutions are shown only from their public quarterly filings. This indicates disclosed gold-ETF exposure changes, not live XAUUSD orders.",
        }

    @staticmethod
    def _empty_bank(error: str) -> dict[str, Any]:
        return {
            "status": "UNAVAILABLE",
            "source": "Official CFTC Bank Participation Report",
            "report_date": "—",
            "score": 0.0,
            "interpretation": "UNAVAILABLE",
            "error": error,
        }

    @staticmethod
    def _empty_sec(error: str) -> dict[str, Any]:
        return {
            "status": "UNAVAILABLE",
            "source": "Official SEC EDGAR Form 13F-HR filings",
            "report_date": "—",
            "score": 0.0,
            "bias": "UNAVAILABLE",
            "institutions": [],
            "error": error,
        }

    def _empty(self, error: str) -> dict[str, Any]:
        return {
            "status": "WAITING",
            "collector_state": "STARTING",
            "updated_at": None,
            "updated_at_epoch": 0,
            "last_attempt": None,
            "source_mode": "OFFICIAL PUBLIC SOURCES · NO API KEY",
            "bias": "WAITING",
            "score": 0.0,
            "bank_participation": self._empty_bank(error),
            "named_institutions": self._empty_sec(error),
            "errors": [error] if error else [],
            "prediction_use": {
                "role": "Slow higher-timeframe bias only",
                "maximum_engine_effect": "Small tie-breaker; never controls entry alone",
                "live_engine_blocking": False,
            },
            "identity_limit": "Live institution order identity is not public.",
        }
