from __future__ import annotations

from collections import deque
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence
import json
import os
import threading
import time


def _as_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _iso(ts: float | None = None) -> str:
    return datetime.fromtimestamp(ts if ts is not None else time.time(), timezone.utc).isoformat()


def _norm_side(value: Any) -> str:
    text = str(value or "").strip().upper()
    if text in {"B", "BID", "BUY", "BUYER", "1", "+1"}:
        return "BUY"
    if text in {"A", "ASK", "SELL", "SELLER", "-1"}:
        return "SELL"
    return "UNKNOWN"


@dataclass
class FlowEvent:
    ts: float
    price: float
    size: float
    side: str
    symbol: str = "GC.FUT"
    venue: str = "CME"
    source: str = "EXTERNAL"
    trade_id: str = ""
    instrument_id: str = ""
    is_block: bool = False
    is_spread_leg: bool = False
    quality: str = "REAL EXCHANGE"


class ExchangeProFlowManager:
    """Aggregates real exchange Time & Sales when a licensed feed is connected.

    No synthetic events are produced. Without credentials or external bridge input,
    the dashboard remains NOT CONNECTED instead of showing fake professional flow.
    """

    def __init__(self, root: str | Path, settings: dict[str, Any]):
        self.root = Path(root)
        self.settings = settings
        self.lock = threading.RLock()
        self.events: deque[FlowEvent] = deque(maxlen=int(settings.get("pro_flow_max_events", 100000)))
        self.blocks: deque[FlowEvent] = deque(maxlen=500)
        self.book_orders: dict[str, dict[str, Any]] = {}
        self.book_cancels: deque[dict[str, Any]] = deque(maxlen=5000)
        self.book_last_event_at = 0.0
        self.book_wall_min = max(1.0, _as_float(settings.get("book_wall_min_contracts", 20), 20))
        self.book_track_min = max(1.0, _as_float(settings.get("book_track_min_contracts", 5), 5))
        self.running = False
        self.thread: threading.Thread | None = None
        self.client: Any = None
        self.connected = False
        self.last_error = ""
        self.last_event_at = 0.0
        self.source_name = "NOT CONNECTED"
        self.provider_mode = str(settings.get("pro_flow_provider", "auto")).lower()
        self.large_min = max(1.0, _as_float(settings.get("large_trade_min_contracts", 10), 10))
        self.block_min = max(self.large_min, _as_float(settings.get("block_trade_min_contracts", 25), 25))

    def start(self) -> None:
        if self.running:
            return
        self.running = True
        if not self.settings.get("pro_flow_enabled", True):
            self.last_error = "Professional flow is disabled in settings.json"
            return
        if self.provider_mode == "auto":
            if os.getenv("DATABENTO_API_KEY", "").strip():
                self.thread = threading.Thread(target=self._run_databento, name="aurax-pro-flow-databento", daemon=True)
                self.thread.start()
            else:
                self.source_name = "LOCAL NO-KEY MODE"
                self.last_error = ""
        elif self.provider_mode == "databento":
            self.thread = threading.Thread(target=self._run_databento, name="aurax-pro-flow-databento", daemon=True)
            self.thread.start()
        elif self.provider_mode in {"bridge", "external", "manual"}:
            self.source_name = "EXTERNAL FEED BRIDGE"
        elif self.provider_mode in {"local", "free", "no-key", "nokey"}:
            self.source_name = "LOCAL NO-KEY MODE"
            self.last_error = ""
        else:
            self.last_error = f"Unknown pro-flow provider: {self.provider_mode}"

    def stop(self) -> None:
        self.running = False
        client = self.client
        if client is not None:
            for method in ("stop", "terminate"):
                try:
                    getattr(client, method)()
                    break
                except Exception:
                    pass
        if self.thread:
            self.thread.join(timeout=3)

    def _run_databento(self) -> None:
        key = os.getenv("DATABENTO_API_KEY", "").strip()
        if not key:
            self.last_error = "DATABENTO_API_KEY is not configured; use the external bridge endpoint or add a licensed key."
            self.source_name = "DATABENTO NOT CONFIGURED"
            return
        try:
            import databento as db  # type: ignore
        except Exception as exc:
            self.last_error = f"Databento package unavailable: {exc}"
            self.source_name = "DATABENTO PACKAGE MISSING"
            return
        try:
            client = db.Live(key=key, heartbeat_interval_s=10)
            self.client = client
            dataset = str(self.settings.get("databento_dataset", "GLBX.MDP3"))
            symbols = str(self.settings.get("databento_symbols", "GC.FUT"))
            stype = str(self.settings.get("databento_stype_in", "parent"))
            client.subscribe(dataset=dataset, schema="trades", symbols=symbols, stype_in=stype, start=0)
            if self.settings.get("databento_mbo_enabled", True):
                client.subscribe(dataset=dataset, schema="mbo", symbols=symbols, stype_in=stype, snapshot=True)
            self.connected = True
            self.source_name = "DATABENTO CME TIME & SALES"
            self.last_error = ""
            for record in client:
                if not self.running:
                    break
                record_name = type(record).__name__.upper()
                if "MBO" in record_name:
                    self._process_databento_mbo(record)
                    continue
                event = self._event_from_databento(record)
                if event is not None:
                    self.ingest(event)
        except Exception as exc:
            self.connected = False
            self.last_error = f"Databento stream error: {exc}"
        finally:
            self.client = None


    @staticmethod
    def _db_price(value: Any) -> float:
        raw = _as_float(value)
        return raw / 1_000_000_000.0 if abs(raw) > 10_000_000 else raw

    @staticmethod
    def _db_ts(value: Any) -> float:
        raw = _as_float(value)
        if raw > 10_000_000_000:
            return raw / 1_000_000_000.0
        return raw or time.time()

    def _process_databento_mbo(self, record: Any) -> None:
        self.ingest_book({
            "action": getattr(record, "action", ""),
            "order_id": getattr(record, "order_id", ""),
            "ts": self._db_ts(getattr(record, "ts_event", 0)),
            "side": getattr(record, "side", ""),
            "size": _as_float(getattr(record, "size", 0)),
            "price": self._db_price(getattr(record, "price", 0)),
            "instrument_id": str(getattr(record, "instrument_id", "")),
            "source": "DATABENTO CME MBO",
        })

    def ingest_book(self, event: dict[str, Any]) -> dict[str, Any]:
        action = str(event.get("action") or event.get("type") or "").strip().upper()
        order_id = str(event.get("order_id") or event.get("id") or "")
        ts = _as_float(event.get("ts") or event.get("timestamp") or time.time(), time.time())
        if ts > 10_000_000_000:
            ts /= 1000.0 if ts < 10_000_000_000_000 else 1_000_000_000.0
        side = _norm_side(event.get("side"))
        size = max(0.0, _as_float(event.get("size") or event.get("quantity")))
        price = _as_float(event.get("price"))
        instrument_id = str(event.get("instrument_id") or event.get("symbol") or "")
        source = str(event.get("source") or "EXTERNAL MBO BRIDGE")
        add_actions = {"A", "ADD", "NEW"}
        modify_actions = {"M", "MODIFY", "UPDATE", "CHANGE"}
        cancel_actions = {"C", "CANCEL", "DELETE", "REMOVE"}
        clear_actions = {"R", "CLEAR", "RESET", "SNAPSHOT_CLEAR"}
        if action not in add_actions | modify_actions | cancel_actions | clear_actions:
            raise ValueError("Book event action must be ADD, MODIFY, CANCEL, or CLEAR")
        if action not in clear_actions and not order_id:
            raise ValueError("Book event requires order_id")
        with self.lock:
            self.book_last_event_at = max(self.book_last_event_at, ts)
            self.connected = True
            if source:
                self.source_name = source
            if action in clear_actions:
                self.book_orders.clear()
                return {"accepted": True, "action": action, "cleared": True}
            if action in add_actions:
                if size >= self.book_track_min and price > 0 and side in {"BUY", "SELL"}:
                    self.book_orders[order_id] = {"order_id": order_id, "ts": ts, "added_at": ts, "price": price, "size": size, "side": side, "instrument_id": instrument_id}
                return {"accepted": True, "action": action, "tracked": order_id in self.book_orders}
            if action in modify_actions:
                old = self.book_orders.get(order_id)
                if size < self.book_track_min:
                    self.book_orders.pop(order_id, None)
                elif price > 0 and side in {"BUY", "SELL"}:
                    self.book_orders[order_id] = {"order_id": order_id, "ts": ts, "added_at": old.get("added_at", ts) if old else ts, "price": price, "size": size, "side": side, "instrument_id": instrument_id}
                return {"accepted": True, "action": action, "tracked": order_id in self.book_orders}
            old = self.book_orders.pop(order_id, None)
            if old:
                self.book_cancels.append({**old, "cancelled_at": ts, "lifetime_seconds": max(0.0, ts - old.get("added_at", ts))})
            return {"accepted": True, "action": action, "cancelled": bool(old)}

    def ingest_book_many(self, items: list[dict[str, Any]]) -> dict[str, Any]:
        accepted = 0
        rejected: list[str] = []
        for idx, item in enumerate(items):
            try:
                result = self.ingest_book(item)
                if result.get("accepted"):
                    accepted += 1
            except Exception as exc:
                rejected.append(f"#{idx}: {exc}")
        return {"accepted": accepted, "rejected": rejected}

    def _order_book_summary(self, now: float) -> dict[str, Any]:
        with self.lock:
            orders = list(self.book_orders.values())
            cancels = list(self.book_cancels)
            last = self.book_last_event_at
        grouped: dict[tuple[str, str, float], float] = {}
        for o in orders:
            key = (str(o.get("instrument_id", "")), str(o.get("side", "UNKNOWN")), round(_as_float(o.get("price")), 2))
            grouped[key] = grouped.get(key, 0.0) + _as_float(o.get("size"))
        walls = [{"instrument_id": k[0], "side": k[1], "price": k[2], "contracts": int(round(v))} for k, v in grouped.items() if v >= self.book_wall_min]
        bid_walls = sorted((w for w in walls if w["side"] == "BUY"), key=lambda x: x["contracts"], reverse=True)[:10]
        ask_walls = sorted((w for w in walls if w["side"] == "SELL"), key=lambda x: x["contracts"], reverse=True)[:10]
        bid_total = sum(w["contracts"] for w in bid_walls)
        ask_total = sum(w["contracts"] for w in ask_walls)
        directional = bid_total + ask_total
        imbalance = (bid_total - ask_total) / directional * 100 if directional else 0.0
        recent_cancels = [c for c in cancels if c.get("cancelled_at", 0) >= now - 60 and c.get("size", 0) >= self.book_wall_min]
        fast = [c for c in recent_cancels if c.get("lifetime_seconds", 99) <= 2.0]
        fast_buy = sum(_as_float(c.get("size")) for c in fast if c.get("side") == "BUY")
        fast_sell = sum(_as_float(c.get("size")) for c in fast if c.get("side") == "SELL")
        spoof = "POSSIBLE BID SPOOF-LIKE CANCELLATIONS" if fast_buy >= self.book_wall_min * 3 else "POSSIBLE ASK SPOOF-LIKE CANCELLATIONS" if fast_sell >= self.book_wall_min * 3 else "NONE"
        age = now - last if last else None
        status = "LIVE MBO" if age is not None and age <= max(10, _as_float(self.settings.get("pro_flow_stale_seconds", 20))) else "STALE" if last else "NOT CONNECTED"
        return {
            "status": status, "data_age_seconds": round(age, 2) if age is not None else None,
            "tracked_orders": len(orders), "wall_threshold": self.book_wall_min,
            "bid_wall_contracts": int(bid_total), "ask_wall_contracts": int(ask_total),
            "resting_imbalance_percent": round(imbalance, 1),
            "bid_walls": bid_walls, "ask_walls": ask_walls,
            "large_cancels_60s": len(recent_cancels), "fast_cancel_buy_contracts": int(round(fast_buy)), "fast_cancel_sell_contracts": int(round(fast_sell)),
            "spoof_warning": spoof,
            "score": round(max(-10.0, min(10.0, imbalance * 0.10)), 1) if status == "LIVE MBO" else 0.0,
            "note": "MBO order IDs are anonymous. Resting walls can be cancelled and are not guaranteed executions."
        }

    def _event_from_databento(self, record: Any) -> FlowEvent | None:
        if not hasattr(record, "size") or not hasattr(record, "price"):
            return None
        size = _as_float(getattr(record, "size", 0))
        if size <= 0:
            return None
        price = self._db_price(getattr(record, "price", 0))
        ts = self._db_ts(getattr(record, "ts_event", 0))
        side = _norm_side(getattr(record, "side", ""))
        instrument_id = str(getattr(record, "instrument_id", ""))
        trade_id = str(getattr(record, "sequence", ""))
        return FlowEvent(
            ts=ts,
            price=price,
            size=size,
            side=side,
            symbol=str(self.settings.get("databento_symbols", "GC.FUT")),
            venue="CME",
            source="DATABENTO",
            trade_id=trade_id,
            instrument_id=instrument_id,
            is_block=False,
            quality="REAL CME",
        )

    def ingest(self, event: FlowEvent | dict[str, Any]) -> dict[str, Any]:
        if isinstance(event, dict):
            ts = _as_float(event.get("ts") or event.get("timestamp") or time.time(), time.time())
            if ts > 10_000_000_000:
                ts /= 1000.0 if ts < 10_000_000_000_000 else 1_000_000_000.0
            item = FlowEvent(
                ts=ts,
                price=_as_float(event.get("price")),
                size=max(0.0, _as_float(event.get("size") or event.get("quantity"))),
                side=_norm_side(event.get("side") or event.get("aggressor_side")),
                symbol=str(event.get("symbol") or "GC.FUT"),
                venue=str(event.get("venue") or "CME"),
                source=str(event.get("source") or "EXTERNAL BRIDGE"),
                trade_id=str(event.get("trade_id") or event.get("id") or ""),
                instrument_id=str(event.get("instrument_id") or ""),
                is_block=bool(event.get("is_block") or str(event.get("type", "")).upper() == "BLOCK"),
                is_spread_leg=bool(event.get("is_spread_leg", False)),
                quality=str(event.get("quality") or "REAL EXCHANGE"),
            )
        else:
            item = event
        if item.size <= 0 or item.price <= 0:
            raise ValueError("Trade requires positive price and size")
        if item.is_spread_leg and self.settings.get("pro_flow_ignore_spread_legs", True):
            return {"accepted": False, "reason": "spread leg ignored"}
        with self.lock:
            self.events.append(item)
            if item.is_block:
                self.blocks.append(item)
            self.last_event_at = max(self.last_event_at, item.ts)
            self.connected = True
            if item.source:
                self.source_name = item.source
            self.last_error = ""
        return {"accepted": True, "event": asdict(item)}

    def ingest_many(self, items: list[dict[str, Any]]) -> dict[str, Any]:
        accepted = 0
        rejected: list[str] = []
        for idx, item in enumerate(items):
            try:
                result = self.ingest(item)
                if result.get("accepted"):
                    accepted += 1
            except Exception as exc:
                rejected.append(f"#{idx}: {exc}")
        return {"accepted": accepted, "rejected": rejected}

    def _window(self, events: list[FlowEvent], seconds: float | None, now: float) -> dict[str, Any]:
        if seconds is None:
            start = datetime.fromtimestamp(now, timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
        else:
            start = now - seconds
        selected = [e for e in events if e.ts >= start and e.size >= self.large_min]
        buys = [e for e in selected if e.side == "BUY"]
        sells = [e for e in selected if e.side == "SELL"]
        unknown = [e for e in selected if e.side == "UNKNOWN"]
        buy_qty = sum(e.size for e in buys)
        sell_qty = sum(e.size for e in sells)
        unknown_qty = sum(e.size for e in unknown)
        directional = buy_qty + sell_qty
        delta = buy_qty - sell_qty
        delta_pct = delta / directional * 100 if directional else 0.0
        score = max(-30.0, min(30.0, delta_pct * 0.30))
        dominant = "PRO BUY" if delta_pct >= 15 else "PRO SELL" if delta_pct <= -15 else "BALANCED"
        return {
            "buy_contracts": int(round(buy_qty)),
            "sell_contracts": int(round(sell_qty)),
            "unknown_contracts": int(round(unknown_qty)),
            "net_delta": int(round(delta)),
            "delta_percent": round(delta_pct, 1),
            "buy_trades": len(buys),
            "sell_trades": len(sells),
            "unknown_trades": len(unknown),
            "largest_buy": int(round(max((e.size for e in buys), default=0))),
            "largest_sell": int(round(max((e.size for e in sells), default=0))),
            "dominant": dominant,
            "score": round(score, 1),
        }

    def _patterns(self, large: list[FlowEvent], current_price: float | None, now: float) -> dict[str, Any]:
        last20 = [e for e in large if e.ts >= now - 20 and e.side in {"BUY", "SELL"}]
        buy_cluster = [e for e in last20 if e.side == "BUY"]
        sell_cluster = [e for e in last20 if e.side == "SELL"]
        cluster = "BUY CLUSTER" if len(buy_cluster) >= 3 and sum(e.size for e in buy_cluster) > sum(e.size for e in sell_cluster) * 1.5 else "SELL CLUSTER" if len(sell_cluster) >= 3 and sum(e.size for e in sell_cluster) > sum(e.size for e in buy_cluster) * 1.5 else "NONE"

        recent60 = [e for e in large if e.ts >= now - 60 and e.side in {"BUY", "SELL"}]
        qty = sum(e.size for e in recent60)
        prices = [e.price for e in recent60]
        price_range = max(prices) - min(prices) if prices else 0.0
        absorption = "NONE"
        if qty >= self.large_min * 8 and price_range <= max(0.2, (current_price or 0) * 0.00008):
            buy_qty = sum(e.size for e in recent60 if e.side == "BUY")
            sell_qty = sum(e.size for e in recent60 if e.side == "SELL")
            absorption = "SELL ABSORPTION" if buy_qty > sell_qty * 1.5 else "BUY ABSORPTION" if sell_qty > buy_qty * 1.5 else "TWO-WAY ABSORPTION"

        repeats: dict[tuple[str, float], list[FlowEvent]] = {}
        for e in recent60:
            key = (e.side, round(e.price, 1))
            repeats.setdefault(key, []).append(e)
        iceberg = "NONE"
        best = max(repeats.values(), key=len, default=[])
        if len(best) >= 4 and sum(e.size for e in best) >= self.large_min * 5:
            iceberg = f"POSSIBLE {best[0].side} ICEBERG"
        return {"cluster": cluster, "absorption": absorption, "iceberg": iceberg}

    def summary(self, current_price: float | None = None) -> dict[str, Any]:
        now = time.time()
        with self.lock:
            events = list(self.events)
            blocks = list(self.blocks)
            last_event_at = self.last_event_at
            connected = self.connected
            source_name = self.source_name
            last_error = self.last_error
        stale_seconds = max(5.0, _as_float(self.settings.get("pro_flow_stale_seconds", 20), 20))
        age = now - last_event_at if last_event_at else None
        real_live = bool(connected and age is not None and age <= stale_seconds)
        if real_live:
            status = "REAL CME" if "CME" in source_name.upper() or "DATABENTO" in source_name.upper() else "REAL EXCHANGE"
        elif connected and events:
            status = "STALE"
        elif connected:
            status = "CONNECTED · NO TRADES"
        else:
            status = "NOT CONNECTED"

        large = [e for e in events if e.size >= self.large_min]
        windows = {
            "1m": self._window(events, 60, now),
            "5m": self._window(events, 300, now),
            "15m": self._window(events, 900, now),
            "1h": self._window(events, 3600, now),
            "today": self._window(events, None, now),
        }
        today = windows["today"]
        patterns = self._patterns(large, current_price, now)
        order_book = self._order_book_summary(now)
        score = today["score"] * 0.20 + windows["15m"]["score"] * 0.30 + windows["5m"]["score"] * 0.35 + _as_float(order_book.get("score")) * 0.15
        signal = "PRO BUY" if score >= 7 else "PRO SELL" if score <= -7 else "BALANCED"
        if not real_live:
            score = 0.0
            signal = "UNAVAILABLE" if status == "NOT CONNECTED" else "STALE"

        recent = sorted(large, key=lambda e: e.ts, reverse=True)[:30]
        recent_blocks = sorted(blocks, key=lambda e: e.ts, reverse=True)[:20]
        def pack(e: FlowEvent) -> dict[str, Any]:
            data = asdict(e)
            data["time"] = _iso(e.ts)
            data["age_seconds"] = round(max(0.0, now - e.ts), 1)
            if current_price and e.is_block:
                diff = current_price - e.price
                data["market_reaction"] = round(diff, 2)
                data["impact_estimate"] = "BULLISH REACTION" if diff > 0.5 else "BEARISH REACTION" if diff < -0.5 else "NEUTRAL REACTION"
            return data
        return {
            "status": status,
            "source": source_name,
            "provider": self.provider_mode.upper(),
            "last_event_time": _iso(last_event_at) if last_event_at else None,
            "data_age_seconds": round(age, 2) if age is not None else None,
            "large_trade_threshold": self.large_min,
            "block_trade_threshold": self.block_min,
            "quantity_unit": "GC futures contracts",
            "session_definition": "UTC calendar day",
            "today": today,
            "windows": windows,
            "patterns": patterns,
            "order_book": order_book,
            "signal": signal,
            "score": round(max(-24.0, min(24.0, score)), 1),
            "recent_large_trades": [pack(e) for e in recent],
            "block_trades": [pack(e) for e in recent_blocks],
            "identity": {
                "available": False,
                "label": "Anonymous professional-size activity",
                "note": "The feed can show aggressor side, price and contracts, but public exchange data normally does not reveal the bank or fund name.",
            },
            "quality_labels": ["REAL CME", "REAL EXCHANGE", "STALE", "NOT CONNECTED"],
            "error": last_error,
            "note": "A large trade is size-based and does not prove the trader is an institution. Aggressor BUY/SELL describes who crossed the spread, not future direction.",
        }


from .local_flow import LocalFlowEstimator


class ProFlowManager:
    """Hybrid source manager.

    The local no-key estimator is always active. A fresh real exchange stream,
    when explicitly configured, takes precedence without changing the app.
    """

    def __init__(self, root: str | Path, settings: dict[str, Any]):
        self.settings = settings
        self.exchange = ExchangeProFlowManager(root, settings)
        self.local = LocalFlowEstimator(root, settings)

    def start(self) -> None:
        self.exchange.start()

    def stop(self) -> None:
        self.exchange.stop()

    def update(
        self,
        tick_history: Iterable[Sequence[float]],
        frame_bars: dict[str, list[dict[str, float]]],
        volume_profile: dict[str, Any],
        smc: dict[str, Any],
        current_price: float | None,
        point: float,
        digits: int,
        frames: dict[str, dict[str, Any]] | None = None,
    ) -> None:
        self.local.update(tick_history, frame_bars, volume_profile, smc, current_price, point, digits, frames)

    def ingest(self, event: FlowEvent | dict[str, Any]) -> dict[str, Any]:
        return self.exchange.ingest(event)

    def ingest_many(self, items: list[dict[str, Any]]) -> dict[str, Any]:
        return self.exchange.ingest_many(items)

    def ingest_book(self, event: dict[str, Any]) -> dict[str, Any]:
        return self.exchange.ingest_book(event)

    def ingest_book_many(self, items: list[dict[str, Any]]) -> dict[str, Any]:
        return self.exchange.ingest_book_many(items)

    def exchange_summary(self, current_price: float | None = None) -> dict[str, Any]:
        return self.exchange.summary(current_price)

    def local_summary(self) -> dict[str, Any]:
        return self.local.summary()

    def summary(self, current_price: float | None = None) -> dict[str, Any]:
        real = self.exchange.summary(current_price)
        local = self.local.summary()
        if real.get("status") in {"REAL CME", "REAL EXCHANGE"}:
            real["local_confirmation"] = {
                "signal": local.get("signal"),
                "score": local.get("score"),
                "data_quality": local.get("data_quality"),
                "note": "Independent MT5 no-key confirmation layer",
            }
            return real
        local["exchange_status"] = real.get("status", "NOT CONNECTED")
        local["exchange_source"] = real.get("source", "OPTIONAL")
        if real.get("error") and self.exchange.provider_mode not in {"auto", "local", "free", "no-key", "nokey"}:
            local["exchange_error"] = real.get("error")
        return local
