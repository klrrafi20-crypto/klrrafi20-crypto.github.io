from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import csv
import io
import json
import math
import sqlite3
import threading
import time


def _f(value: Any, default: float = 0.0) -> float:
    try:
        value = float(value)
        return value if math.isfinite(value) else default
    except Exception:
        return default


def _iso(ts: float | None) -> str | None:
    if not ts:
        return None
    return datetime.fromtimestamp(float(ts), timezone.utc).isoformat()


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), default=str)


class SignalValidationJournal:
    """Persistent paper-signal journal and outcome evaluator.

    The journal never places trades and never changes live signal direction. It records
    published signals, waits for the proposed entry zone to be touched, then evaluates
    TP/SL order from completed M1 bars. When TP and SL are both touched inside the same
    completed bar, the result is marked AMBIGUOUS instead of guessing intrabar order.
    """

    def __init__(self, root: str | Path, settings: dict[str, Any]):
        self.root = Path(root)
        self.settings = settings
        self.enabled = bool(settings.get("validation_enabled", True))
        self.max_horizon_seconds = max(900.0, _f(settings.get("validation_max_horizon_hours", 4), 4) * 3600.0)
        self.minimum_sample = max(10, int(settings.get("validation_minimum_sample", 30)))
        self.lock = threading.RLock()
        self.last_action = "WAIT"
        self.last_event_time = 0.0
        db_relative = str(settings.get("validation_db_path", "data/signal_journal.sqlite3"))
        self.db_path = self.root / db_relative
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.db_path, timeout=5.0)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("PRAGMA synchronous=NORMAL")
        con.execute("PRAGMA busy_timeout=5000")
        return con

    def _init_db(self) -> None:
        if not self.enabled:
            return
        with self._connect() as con:
            con.executescript(
                """
                CREATE TABLE IF NOT EXISTS signal_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at REAL NOT NULL,
                    action TEXT NOT NULL,
                    price REAL,
                    score REAL,
                    grouped_score REAL,
                    alignment REAL,
                    regime TEXT,
                    quality REAL,
                    payload_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS paper_signals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL,
                    action TEXT NOT NULL,
                    direction INTEGER NOT NULL,
                    symbol TEXT,
                    broker TEXT,
                    signal_price REAL NOT NULL,
                    entry_low REAL,
                    entry_high REAL,
                    stop_loss REAL,
                    tp1 REAL,
                    tp2 REAL,
                    risk_distance REAL,
                    score REAL,
                    legacy_score REAL,
                    alignment REAL,
                    component_agreement REAL,
                    group_agreement REAL,
                    regime TEXT,
                    quality REAL,
                    spread_points REAL,
                    exact_comex_active INTEGER DEFAULT 0,
                    source_coverage REAL,
                    components_json TEXT,
                    groups_json TEXT,
                    reasons_json TEXT,
                    warnings_json TEXT,
                    status TEXT NOT NULL DEFAULT 'WAITING_ENTRY',
                    activated_at REAL,
                    first_outcome TEXT,
                    first_outcome_at REAL,
                    tp1_hit INTEGER DEFAULT 0,
                    tp1_hit_at REAL,
                    tp2_hit INTEGER DEFAULT 0,
                    tp2_hit_at REAL,
                    sl_hit INTEGER DEFAULT 0,
                    sl_hit_at REAL,
                    mfe REAL DEFAULT 0,
                    mae REAL DEFAULT 0,
                    last_price REAL,
                    h15_price REAL,
                    h15_r REAL,
                    h1_price REAL,
                    h1_r REAL,
                    h4_price REAL,
                    h4_r REAL,
                    closed_at REAL,
                    note TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_paper_status ON paper_signals(status);
                CREATE INDEX IF NOT EXISTS idx_paper_created ON paper_signals(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_events_created ON signal_events(created_at DESC);
                """
            )

    def observe(self, dashboard: dict[str, Any], m1_bars: list[dict[str, Any]], tick: dict[str, Any]) -> dict[str, Any]:
        if not self.enabled:
            return self.empty_summary("DISABLED")
        with self.lock:
            try:
                # Evaluate existing pending signals before a new WAIT/opposite transition
                # can cancel them. Then record the transition and evaluate once more so a
                # newly published signal can activate immediately when price is in entry.
                self._evaluate_open(dashboard, m1_bars, tick)
                self._record_transition(dashboard)
                self._evaluate_open(dashboard, m1_bars, tick)
                return self.summary(dashboard)
            except Exception as exc:
                result = self.empty_summary("ERROR")
                result["note"] = f"Validation journal error: {exc}"
                return result

    def _record_transition(self, d: dict[str, Any]) -> None:
        sig = d.get("signal") or {}
        action = str(sig.get("action") or "WAIT").upper()
        published_at = sig.get("published_at")
        try:
            event_time = datetime.fromisoformat(str(published_at).replace("Z", "+00:00")).timestamp() if published_at else time.time()
        except Exception:
            event_time = time.time()
        if action == self.last_action and abs(event_time - self.last_event_time) < 0.5:
            return
        # On process restart, avoid duplicating the latest already persisted transition.
        with self._connect() as con:
            latest = con.execute("SELECT action, created_at FROM signal_events ORDER BY id DESC LIMIT 1").fetchone()
            if latest and str(latest["action"]) == action and abs(_f(latest["created_at"]) - event_time) < 2.0:
                self.last_action = action
                self.last_event_time = event_time
                return
            price = _f((d.get("price") or {}).get("mid"))
            groups = sig.get("evidence_groups") or {}
            con.execute(
                "INSERT INTO signal_events(created_at,action,price,score,grouped_score,alignment,regime,quality,payload_json) VALUES(?,?,?,?,?,?,?,?,?)",
                (event_time, action, price, _f(sig.get("legacy_score", sig.get("score"))), _f(sig.get("score")),
                 _f(sig.get("alignment_confidence")), str(d.get("market_regime") or "UNKNOWN"),
                 _f((d.get("data_quality") or {}).get("score")), _json({"signal": sig, "groups": groups}))
            )
            if action in {"BUY", "STRONG BUY", "SELL", "STRONG SELL"}:
                self._insert_paper_signal(con, d, event_time)
            elif action == "WAIT":
                con.execute(
                    "UPDATE paper_signals SET status='CANCELLED_BEFORE_ENTRY', closed_at=?, updated_at=?, note='Published signal returned to WAIT before the proposed entry zone was activated' "
                    "WHERE status='WAITING_ENTRY'",
                    (event_time, event_time),
                )
        self.last_action = action
        self.last_event_time = event_time

    def _insert_paper_signal(self, con: sqlite3.Connection, d: dict[str, Any], ts: float) -> None:
        con.execute(
            "UPDATE paper_signals SET status='CANCELLED_BEFORE_ENTRY',closed_at=?,updated_at=?,note='Pending entry was superseded by a newly published directional signal' WHERE status='WAITING_ENTRY'",
            (ts, ts),
        )
        sig = d.get("signal") or {}
        plan = d.get("trade_plan") or {}
        price = _f((d.get("price") or {}).get("mid"))
        direction = 1 if "BUY" in str(sig.get("action")) else -1
        entry_low = _f(plan.get("entry_low"), price)
        entry_high = _f(plan.get("entry_high"), price)
        if entry_low > entry_high:
            entry_low, entry_high = entry_high, entry_low
        sl = _f(plan.get("stop_loss"))
        tp1 = _f(plan.get("tp1"))
        tp2 = _f(plan.get("tp2"))
        entry_mid = (entry_low + entry_high) / 2.0
        risk = abs(entry_mid - sl) if sl else 0.0
        if risk <= 0:
            risk = max(abs(price) * 0.0005, 0.01)
        global_flow = ((d.get("institutional") or {}).get("global_gold_flow") or {})
        con.execute(
            """
            INSERT INTO paper_signals(
                created_at,updated_at,action,direction,symbol,broker,signal_price,entry_low,entry_high,stop_loss,tp1,tp2,risk_distance,
                score,legacy_score,alignment,component_agreement,group_agreement,regime,quality,spread_points,exact_comex_active,
                source_coverage,components_json,groups_json,reasons_json,warnings_json,last_price,status
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                ts, ts, str(sig.get("action")), direction, str(d.get("symbol") or ""), str(d.get("broker") or ""), price,
                entry_low, entry_high, sl or None, tp1 or None, tp2 or None, risk,
                _f(sig.get("score")), _f(sig.get("legacy_score", sig.get("score"))), _f(sig.get("alignment_confidence")),
                _f(sig.get("component_agreement")), _f(sig.get("group_agreement")), str(d.get("market_regime") or "UNKNOWN"),
                _f((d.get("data_quality") or {}).get("score")), _f((d.get("price") or {}).get("spread_points")),
                1 if global_flow.get("exact_comex_active") else 0, _f(global_flow.get("source_coverage_percent")),
                _json(sig.get("components") or {}), _json(sig.get("evidence_groups") or {}), _json(sig.get("reasons") or []),
                _json(sig.get("warnings") or []), price, "WAITING_ENTRY",
            )
        )

    def _evaluate_open(self, d: dict[str, Any], bars: list[dict[str, Any]], tick: dict[str, Any]) -> None:
        now = time.time()
        current = _f(tick.get("mid"))
        completed = sorted([b for b in bars if _f(b.get("time")) > 0], key=lambda b: _f(b.get("time")))
        with self._connect() as con:
            rows = con.execute(
                "SELECT * FROM paper_signals WHERE status IN ('WAITING_ENTRY','ACTIVE','TP1_FIRST','AMBIGUOUS_FIRST') ORDER BY created_at"
            ).fetchall()
            for row in rows:
                record = dict(row)
                self._evaluate_record(con, record, completed, current, now)

    def _evaluate_record(self, con: sqlite3.Connection, r: dict[str, Any], bars: list[dict[str, Any]], current: float, now: float) -> None:
        sid = int(r["id"])
        direction = int(r["direction"])
        created = _f(r["created_at"])
        entry_low = _f(r["entry_low"], _f(r["signal_price"]))
        entry_high = _f(r["entry_high"], _f(r["signal_price"]))
        sl = _f(r["stop_loss"])
        tp1 = _f(r["tp1"])
        tp2 = _f(r["tp2"])
        risk = max(_f(r["risk_distance"]), 1e-9)
        status = str(r["status"])
        activated_at = _f(r["activated_at"])
        first_outcome = str(r["first_outcome"] or "")
        mfe = _f(r["mfe"])
        mae = _f(r["mae"])
        tp1_hit = int(r["tp1_hit"] or 0)
        tp2_hit = int(r["tp2_hit"] or 0)
        sl_hit = int(r["sl_hit"] or 0)
        start = activated_at or created
        relevant = [b for b in bars if _f(b.get("time")) >= created - 60]

        if status == "WAITING_ENTRY":
            activation_bar = None
            for b in relevant:
                if _f(b.get("high")) >= entry_low and _f(b.get("low")) <= entry_high:
                    activation_bar = b
                    break
            if activation_bar is not None:
                activated_at = max(created, _f(activation_bar.get("time")))
                status = "ACTIVE"
                start = activated_at
            elif entry_low <= current <= entry_high:
                activated_at = now
                status = "ACTIVE"
                start = activated_at
            elif now - created >= self.max_horizon_seconds:
                con.execute(
                    "UPDATE paper_signals SET status='EXPIRED_UNTRIGGERED',closed_at=?,updated_at=?,last_price=?,note='Entry zone was not reached within the validation horizon' WHERE id=?",
                    (now, now, current, sid),
                )
                return

        if status in {"ACTIVE", "TP1_FIRST", "AMBIGUOUS_FIRST"}:
            entry_mid = (entry_low + entry_high) / 2.0
            active_bars = [b for b in relevant if _f(b.get("time")) >= start - 60]
            for b in active_bars:
                high, low, bt = _f(b.get("high")), _f(b.get("low")), _f(b.get("time"))
                fav = (high - entry_mid) if direction > 0 else (entry_mid - low)
                adv = (entry_mid - low) if direction > 0 else (high - entry_mid)
                mfe = max(mfe, fav / risk)
                mae = max(mae, adv / risk)
                hit_sl = (low <= sl) if direction > 0 and sl else (high >= sl) if direction < 0 and sl else False
                hit_tp1 = (high >= tp1) if direction > 0 and tp1 else (low <= tp1) if direction < 0 and tp1 else False
                hit_tp2 = (high >= tp2) if direction > 0 and tp2 else (low <= tp2) if direction < 0 and tp2 else False
                if not first_outcome:
                    if hit_sl and hit_tp1:
                        first_outcome = "AMBIGUOUS"
                        status = "AMBIGUOUS_FIRST"
                        con.execute("UPDATE paper_signals SET first_outcome='AMBIGUOUS',first_outcome_at=?,note='TP1 and SL were both touched inside one completed M1 bar; intrabar order is unknown' WHERE id=?", (bt, sid))
                    elif hit_tp1:
                        first_outcome = "TP1"
                        status = "TP1_FIRST"
                        tp1_hit = 1
                        con.execute("UPDATE paper_signals SET first_outcome='TP1',first_outcome_at=?,tp1_hit=1,tp1_hit_at=? WHERE id=?", (bt, bt, sid))
                    elif hit_sl:
                        first_outcome = "SL"
                        sl_hit = 1
                        con.execute(
                            "UPDATE paper_signals SET first_outcome='SL',first_outcome_at=?,sl_hit=1,sl_hit_at=?,status='SL_FIRST',closed_at=?,updated_at=?,last_price=?,mfe=?,mae=? WHERE id=?",
                            (bt, bt, bt, now, current, mfe, mae, sid),
                        )
                        return
                if hit_tp1 and not tp1_hit:
                    tp1_hit = 1
                    con.execute("UPDATE paper_signals SET tp1_hit=1,tp1_hit_at=? WHERE id=?", (bt, sid))
                if hit_tp2 and not tp2_hit:
                    tp2_hit = 1
                    con.execute("UPDATE paper_signals SET tp2_hit=1,tp2_hit_at=?,status='TP2_REACHED',closed_at=? WHERE id=?", (bt, bt, sid))
                    status = "TP2_REACHED"
                    break
                if first_outcome == "TP1" and hit_sl and not sl_hit:
                    sl_hit = 1
                    con.execute("UPDATE paper_signals SET sl_hit=1,sl_hit_at=? WHERE id=?", (bt, sid))

            # Horizon prices use completed bar closes; they are diagnostics, not trade outcomes.
            updates: dict[str, Any] = {}
            for seconds, pcol, rcol in ((900, "h15_price", "h15_r"), (3600, "h1_price", "h1_r"), (14400, "h4_price", "h4_r")):
                if r.get(pcol) is None and now >= created + seconds:
                    candidates = [b for b in bars if _f(b.get("time")) >= created + seconds]
                    if candidates:
                        px = _f(candidates[0].get("close"))
                        updates[pcol] = px
                        updates[rcol] = ((px - _f(r["signal_price"])) * direction) / risk
            if status not in {"TP2_REACHED"} and now - (activated_at or created) >= self.max_horizon_seconds:
                status = "EXPIRED_AFTER_ENTRY"
                updates["closed_at"] = now
            updates.update({"status": status, "activated_at": activated_at or None, "updated_at": now, "last_price": current, "mfe": mfe, "mae": mae})
            setters = ",".join(f"{k}=?" for k in updates)
            con.execute(f"UPDATE paper_signals SET {setters} WHERE id=?", (*updates.values(), sid))

    @staticmethod
    def _is_resolved_status(status: str) -> bool:
        return status in {"SL_FIRST", "TP2_REACHED", "EXPIRED_AFTER_ENTRY", "AMBIGUOUS_FIRST", "CANCELLED_BEFORE_ENTRY", "EXPIRED_UNTRIGGERED"}

    def summary(self, dashboard: dict[str, Any] | None = None) -> dict[str, Any]:
        if not self.enabled:
            return self.empty_summary("DISABLED")
        with self._connect() as con:
            rows = [dict(x) for x in con.execute("SELECT * FROM paper_signals ORDER BY created_at DESC LIMIT 2500").fetchall()]
        trade_rows = [r for r in rows if str(r.get("status")) not in {"CANCELLED_BEFORE_ENTRY", "EXPIRED_UNTRIGGERED"}]
        judged = [r for r in trade_rows if str(r.get("first_outcome")) in {"TP1", "SL"}]
        wins = [r for r in judged if r.get("first_outcome") == "TP1"]
        losses = [r for r in judged if r.get("first_outcome") == "SL"]
        ambiguous = [r for r in trade_rows if r.get("first_outcome") == "AMBIGUOUS"]
        open_rows = [r for r in rows if str(r.get("status")) in {"WAITING_ENTRY", "ACTIVE", "TP1_FIRST"}]

        def rate(items: list[dict[str, Any]]) -> float | None:
            valid = [x for x in items if x.get("first_outcome") in {"TP1", "SL"}]
            if not valid:
                return None
            return 100.0 * sum(1 for x in valid if x.get("first_outcome") == "TP1") / len(valid)

        buy_rows = [r for r in judged if int(r.get("direction") or 0) > 0]
        sell_rows = [r for r in judged if int(r.get("direction") or 0) < 0]
        regime_stats = []
        for regime in sorted({str(r.get("regime") or "UNKNOWN") for r in judged}):
            subset = [r for r in judged if str(r.get("regime") or "UNKNOWN") == regime]
            regime_stats.append({"regime": regime, "sample": len(subset), "tp1_first_rate": round(rate(subset) or 0.0, 1)})
        regime_stats.sort(key=lambda x: (-x["sample"], x["regime"]))

        buckets = [(0,49),(50,59),(60,69),(70,79),(80,89),(90,100)]
        calibration = []
        for low, high in buckets:
            subset = [r for r in judged if low <= _f(r.get("alignment")) <= high]
            calibration.append({
                "label": f"{low}–{high}%", "low": low, "high": high, "sample": len(subset),
                "observed_tp1_first_rate": round(rate(subset) or 0.0, 1) if subset else None,
            })

        sample = len(judged)
        sample_status = "INSUFFICIENT SAMPLE" if sample < self.minimum_sample else "EARLY SAMPLE" if sample < 100 else "USEFUL SAMPLE" if sample < 250 else "MATURE SAMPLE"
        recent = []
        for r in rows[:30]:
            recent.append({
                "id": r["id"], "time": _iso(_f(r.get("created_at"))), "action": r.get("action"), "status": r.get("status"),
                "signal_price": r.get("signal_price"), "entry_low": r.get("entry_low"), "entry_high": r.get("entry_high"),
                "stop_loss": r.get("stop_loss"), "tp1": r.get("tp1"), "tp2": r.get("tp2"),
                "alignment": r.get("alignment"), "score": r.get("score"), "regime": r.get("regime"),
                "first_outcome": r.get("first_outcome"), "mfe_r": round(_f(r.get("mfe")), 2), "mae_r": round(_f(r.get("mae")), 2),
                "h15_r": None if r.get("h15_r") is None else round(_f(r.get("h15_r")), 2),
                "h1_r": None if r.get("h1_r") is None else round(_f(r.get("h1_r")), 2),
                "h4_r": None if r.get("h4_r") is None else round(_f(r.get("h4_r")), 2),
                "exact_comex_active": bool(r.get("exact_comex_active")), "note": r.get("note") or "",
            })

        weakness = self._weakness_diagnostics(judged)
        current_bucket = None
        if dashboard:
            conf = _f((dashboard.get("signal") or {}).get("alignment_confidence"))
            for item in calibration:
                if item["low"] <= conf <= item["high"]:
                    current_bucket = item
                    break
        return {
            "status": "PAPER JOURNAL ACTIVE",
            "mode": "READ-ONLY VALIDATION",
            "sample_status": sample_status,
            "minimum_sample": self.minimum_sample,
            "total_trade_signals": len(rows),
            "activated_signals": len(trade_rows),
            "judged_sample": sample,
            "open_signals": len(open_rows),
            "wins_tp1_first": len(wins),
            "losses_sl_first": len(losses),
            "ambiguous": len(ambiguous),
            "tp1_first_rate": None if not judged else round(rate(judged) or 0.0, 1),
            "buy_tp1_first_rate": None if not buy_rows else round(rate(buy_rows) or 0.0, 1),
            "sell_tp1_first_rate": None if not sell_rows else round(rate(sell_rows) or 0.0, 1),
            "tp2_reached": sum(1 for r in trade_rows if int(r.get("tp2_hit") or 0)),
            "average_mfe_r": round(sum(_f(r.get("mfe")) for r in trade_rows) / len(trade_rows), 2) if trade_rows else None,
            "average_mae_r": round(sum(_f(r.get("mae")) for r in trade_rows) / len(trade_rows), 2) if trade_rows else None,
            "confidence_buckets": calibration,
            "current_confidence_bucket": current_bucket,
            "regime_performance": regime_stats,
            "weakness_diagnostics": weakness,
            "recent_signals": recent,
            "database": str(self.db_path),
            "note": "Observed TP1-before-SL rate is a historical paper-signal statistic, not a guarantee. Ambiguous same-bar outcomes are excluded from precision.",
        }

    def _weakness_diagnostics(self, judged: list[dict[str, Any]]) -> list[dict[str, Any]]:
        if len(judged) < 10:
            return [{"label": "More observations required", "detail": "At least 10 judged paper signals are needed before weakness diagnostics are meaningful.", "severity": "INFO"}]
        outputs: list[dict[str, Any]] = []
        by_regime: dict[str, list[dict[str, Any]]] = {}
        for r in judged:
            by_regime.setdefault(str(r.get("regime") or "UNKNOWN"), []).append(r)
        for regime, subset in by_regime.items():
            if len(subset) >= 5:
                win_rate = 100.0 * sum(1 for r in subset if r.get("first_outcome") == "TP1") / len(subset)
                if win_rate < 45:
                    outputs.append({"label": f"Weak {regime} performance", "detail": f"TP1-first rate {win_rate:.1f}% across {len(subset)} judged signals.", "severity": "CAUTION"})
        high_conf = [r for r in judged if _f(r.get("alignment")) >= 75]
        if len(high_conf) >= 5:
            wr = 100.0 * sum(1 for r in high_conf if r.get("first_outcome") == "TP1") / len(high_conf)
            if wr < 60:
                outputs.append({"label": "High alignment is not yet reliable", "detail": f"75%+ alignment produced {wr:.1f}% TP1-first across {len(high_conf)} signals.", "severity": "CAUTION"})
        if not outputs:
            outputs.append({"label": "No dominant weakness detected yet", "detail": "Continue paper collection across different sessions and market regimes.", "severity": "GOOD"})
        return outputs[:8]

    def export_csv(self) -> str:
        with self._connect() as con:
            rows = [dict(x) for x in con.execute("SELECT * FROM paper_signals ORDER BY created_at DESC").fetchall()]
        fields = [
            "id","created_at","action","status","first_outcome","signal_price","entry_low","entry_high","stop_loss","tp1","tp2",
            "score","legacy_score","alignment","component_agreement","group_agreement","regime","quality","spread_points",
            "exact_comex_active","source_coverage","activated_at","first_outcome_at","tp1_hit","tp2_hit","sl_hit","mfe","mae",
            "h15_r","h1_r","h4_r","closed_at","note",
        ]
        stream = io.StringIO()
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            copy = dict(row)
            for key in ("created_at","activated_at","first_outcome_at","closed_at"):
                copy[key] = _iso(_f(copy.get(key))) if copy.get(key) else ""
            writer.writerow(copy)
        return stream.getvalue()

    @staticmethod
    def empty_summary(status: str = "WAITING") -> dict[str, Any]:
        return {
            "status": status, "mode": "READ-ONLY VALIDATION", "sample_status": "INSUFFICIENT SAMPLE", "minimum_sample": 30,
            "total_trade_signals": 0, "activated_signals": 0, "judged_sample": 0, "open_signals": 0,
            "wins_tp1_first": 0, "losses_sl_first": 0, "ambiguous": 0, "tp1_first_rate": None,
            "buy_tp1_first_rate": None, "sell_tp1_first_rate": None, "tp2_reached": 0,
            "average_mfe_r": None, "average_mae_r": None, "confidence_buckets": [], "current_confidence_bucket": None,
            "regime_performance": [], "weakness_diagnostics": [], "recent_signals": [],
            "note": "Paper validation begins after live BUY/SELL signals are published.",
        }
