const $ = id => document.getElementById(id);
const state = { payload: null, data: null, lastFetch: 0, page: 'signal', desktopInfo: null };
const native = typeof window.Android !== 'undefined';
if (new URLSearchParams(location.search).get('desktop') === '1') document.documentElement.classList.add('desktop-shell');
const fmt = (v, d = 2) => v === null || v === undefined || v === '' || Number.isNaN(Number(v)) ? '—' : Number(v).toFixed(d);
const esc = v => String(v ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const arr = v => Array.isArray(v) ? v : [];
const obj = v => v && typeof v === 'object' ? v : {};

function tone(value) {
  const v = String(value || '').toUpperCase();
  if (v.includes('BUY') || v.includes('BULL') || v.includes('BID-REACTION') || v === 'LIVE' || v === 'CONNECTED' || v.includes('REAL CME') || v.includes('REAL EXCHANGE') || v.includes('LIVE MT5') || v.includes('HYBRID LIVE') || v.includes('LIVE EXCHANGE VIA MT5') || v.includes('WATCHING LOCAL FILES') || v === 'HIGH' || v === 'GOOD' || v === 'IMPROVING') return 'positive';
  if (v.includes('SELL') || v.includes('BEAR') || v.includes('ASK-REACTION') || v === 'OFFLINE' || v === 'ERROR' || v.includes('STALE') || v.includes('NOT CONNECTED') || v === 'LOW' || v === 'WEAKENING') return 'negative';
  return 'neutral';
}
function heroTone(signal) { const s = String(signal || ''); return s.includes('BUY') ? 'buy' : s.includes('SELL') ? 'sell' : 'offline'; }
function timeAgo(value) {
  if (!value) return '—';
  const t = new Date(value).getTime(); if (!Number.isFinite(t)) return '—';
  const sec = Math.max(0, Math.round((Date.now() - t) / 1000));
  if (sec < 60) return `${sec}s ago`; if (sec < 3600) return `${Math.floor(sec / 60)}m ago`;
  return new Date(value).toLocaleString([], {month:'short', day:'numeric', hour:'2-digit', minute:'2-digit'});
}

async function loadData() {
  try {
    if (native) {
      const p = JSON.parse(Android.getPayload() || '{}');
      state.payload = p; state.data = obj(p.dashboard);
      $('serverInput').value = p.serverUrl || '';
      $('connectionError').textContent = p.error || '';
    } else {
      const r = await fetch('/api/v1/dashboard', {cache:'no-store'});
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      state.data = await r.json(); state.payload = {status: String(state.data.mode || '').includes('LIVE MT5') ? 'LIVE' : 'OFFLINE', dashboard: state.data};
      $('connectionCard').style.display = 'none';
    }
    state.lastFetch = Date.now(); render();
  } catch (e) {
    $('connectionText').textContent = 'OFFLINE'; $('connectionDetail').textContent = String(e.message || e);
  }
}
window.onNativeData = loadData;
$('refreshBtn').onclick = () => native ? Android.refresh() : loadData();
$('testServer').onclick = () => native ? Android.refresh() : loadData();
$('saveServer').onclick = () => {
  if (!native) return;
  Android.setServerUrl($('serverInput').value.trim()); $('connectionError').textContent = 'Connecting…';
};

async function loadDesktopInfo() {
  if (!window.pywebview || !window.pywebview.api) return;
  try {
    const info = await window.pywebview.api.get_desktop_info();
    state.desktopInfo = info;
    document.documentElement.classList.add('desktop-shell');
    if ($('desktopPhoneUrl')) $('desktopPhoneUrl').textContent = info.phone_url || 'Unavailable';
    if ($('sysPort') && info.phone_url) {
      try { $('sysPort').textContent = `Port ${new URL(info.phone_url).port || '8787'}`; } catch (_) {}
    }
  } catch (e) {
    if ($('desktopActionStatus')) $('desktopActionStatus').textContent = `Desktop information unavailable: ${e.message || e}`;
  }
}

if ($('copyPhoneUrl')) $('copyPhoneUrl').onclick = async () => {
  if (!window.pywebview || !window.pywebview.api) return;
  const result = await window.pywebview.api.copy_phone_url();
  $('desktopActionStatus').textContent = result.ok ? `Copied ${result.value}` : `Copy failed: ${result.error || 'Unknown error'}`;
};
if ($('openLogs')) $('openLogs').onclick = async () => {
  if (!window.pywebview || !window.pywebview.api) return;
  const result = await window.pywebview.api.open_logs_folder();
  $('desktopActionStatus').textContent = result.ok ? 'Logs folder opened.' : `Could not open logs: ${result.error || 'Unknown error'}`;
};
addEventListener('pywebviewready', loadDesktopInfo);

document.querySelectorAll('.bottom-nav button').forEach(btn => btn.onclick = () => {
  document.querySelectorAll('.bottom-nav button').forEach(x => x.classList.remove('active'));
  document.querySelectorAll('.page').forEach(x => x.classList.remove('active'));
  btn.classList.add('active'); state.page = btn.dataset.target;
  const page = $(state.page + 'Page'); if (page) page.classList.add('active');
  try { btn.scrollIntoView({behavior:'smooth', block:'nearest', inline:'center'}); } catch (_) {}
  scrollTo({top:0, behavior:'smooth'}); if (state.page === 'timeframes') setTimeout(drawChart, 80);
});

function render() {
  const d = obj(state.data), price = obj(d.price), sig = obj(d.signal), plan = obj(d.trade_plan);
  const inst = obj(d.institutional), vp = obj(inst.volume_profile), cot = obj(inst.cot), intel = obj(inst.intelligence), flow = obj(inst.order_flow_proxy), activity = obj(inst.activity_quantity), pro = obj(inst.pro_flow), orderFlow = obj(inst.order_flow_lab), globalFlow = obj(inst.global_gold_flow), smc = obj(d.smart_money), sys = obj(d.system), quality = obj(d.data_quality), validation = obj(d.validation);
  const modeText = String(d.mode || '');
  const marketClosed = modeText.includes('MARKET CLOSED');
  const live = modeText.includes('LIVE MT5') && Number(d.data_age_seconds) < 8;
  $('connectionDot').classList.toggle('live', live); $('connectionDot').classList.toggle('closed', marketClosed);
  $('connectionText').textContent = marketClosed ? 'MARKET CLOSED' : (live ? 'LIVE' : 'OFFLINE');
  $('connectionDetail').textContent = marketClosed ? `${d.symbol || 'XAUUSD'} · waiting for fresh broker ticks` : (live ? `${d.symbol || 'XAUUSD'} · ${fmt(d.data_age_seconds, 1)} sec old` : (arr(sig.warnings)[0] || 'Waiting for Windows engine'));
  $('topSymbol').textContent = d.symbol || 'XAUUSD'; $('topPrice').textContent = fmt(price.mid); $('modeBadge').textContent = d.mode || 'OFFLINE';

  const action = sig.action || 'DATA OFFLINE', score = Number(sig.score || 0), confidence = Number(sig.alignment_confidence || 0);
  $('signalAction').textContent = action; $('signalMeaning').textContent = sig.meaning || 'Waiting for live analysis.'; $('signalTime').textContent = timeAgo(sig.published_at || d.generated_at);
  $('confidence').textContent = `${Math.round(confidence)}%`; $('scoreText').textContent = (score >= 0 ? '+' : '') + score.toFixed(1);
  $('scoreNeedle').style.left = `calc(${Math.max(0, Math.min(100, 50 + score / 2))}% - 2px)`;
  $('ringProgress').style.strokeDashoffset = String(302 * (1 - Math.max(0, Math.min(100, confidence)) / 100));
  $('signalHero').className = 'signal-hero ' + heroTone(action);

  $('bid').textContent = fmt(price.bid); $('ask').textContent = fmt(price.ask);
  $('spread').textContent = price.spread_points == null ? '—' : `${fmt(price.spread_points, 0)} points`;
  $('tickAge').textContent = price.tick_time ? timeAgo(price.tick_time) : 'No live tick';
  $('pressure').textContent = flow.pressure || '—'; $('pressure').className = tone(flow.pressure);
  $('speed').textContent = flow.tick_rate_per_second == null ? '—' : `${fmt(flow.tick_rate_per_second, 1)} unique ticks/s · 3s ${fmt(flow.move_3s)}`;
  $('structure').textContent = smc.structure || '—'; $('structure').className = tone(smc.structure);
  $('structureDetail').textContent = smc.bos && smc.bos !== 'NONE' ? smc.bos : (smc.liquidity_sweep || '—');

  renderQuality(quality, sig); renderActivity(activity); renderProFlow(pro); renderOrderFlow(orderFlow); renderGlobalFlow(globalFlow, cot, intel); renderPlan(plan); renderReasons(sig.reasons, sig.warnings);
  renderVolume(vp); renderCot(cot); renderIntelligence(intel); renderSmc(smc); renderTimeframes(obj(d.timeframes)); renderValidation(validation, sig); renderSystem(d, sys);
  if (state.page === 'timeframes') drawChart();
}

function renderQuality(q, sig) {
  const score = Number(q.score || 0), stateText = q.state || 'LOW';
  $('qualityState').textContent = stateText; $('qualityState').className = 'pill ' + tone(stateText);
  $('qualityScore').textContent = `${Math.round(score)}/100`; $('qualityTicks').textContent = Number(q.unique_ticks_60s || 0).toLocaleString();
  $('qualityRegime').textContent = q.market_regime || '—'; $('qualityRegime').className = tone(q.market_regime);
  $('qualityAgreement').textContent = `Evidence-group agreement ${fmt(sig.group_agreement, 0)}% · component agreement ${fmt(sig.component_agreement, 0)}%`;
  $('qualityNote').textContent = arr(q.reasons).length ? arr(q.reasons).join(' · ') : 'Unique ticks, spread and timeframe consistency are within the active safety limits.';
}

function renderActivity(a) {
  const active = ['LIVE','WARMING UP'].includes(a.status);
  $('activityStatus').textContent = a.status || 'OFFLINE'; $('activityStatus').className = 'pill ' + (active ? tone(a.status) : 'muted');
  $('activityDominant').textContent = a.dominant_side || '—'; $('activityDominant').className = tone(a.dominant_side);
  $('activityLookback').textContent = `Last ${a.lookback_minutes ?? '—'} completed M1 bars`;
  $('activityBuy').textContent = a.buy_activity == null ? '—' : Number(a.buy_activity).toLocaleString();
  $('activitySell').textContent = a.sell_activity == null ? '—' : Number(a.sell_activity).toLocaleString();
  $('activityNet').textContent = a.net_activity == null ? '—' : `${Number(a.net_activity) >= 0 ? '+' : ''}${Number(a.net_activity).toLocaleString()}`;
  $('activitySamples').textContent = `${a.live_buy_samples ?? 0}↑ / ${a.live_sell_samples ?? 0}↓`;
  const bp = Math.max(0, Math.min(100, Number(a.buy_percent ?? 50))), sp = Math.max(0, Math.min(100, Number(a.sell_percent ?? 50)));
  $('activityBuyBar').style.width = `${bp}%`; $('activitySellBar').style.width = `${sp}%`;
  $('activityBuyPct').textContent = `BUY ${fmt(bp,1)}%`; $('activitySellPct').textContent = `SELL ${fmt(sp,1)}%`;
  $('activityIdentity').textContent = a.identity || 'Participant identity unavailable'; $('activityNote').textContent = a.note || 'Estimated activity only.';
}

function renderProFlow(p) {
  const status = p.status || 'WAITING', today = obj(p.today), windows = obj(p.windows), patterns = obj(p.patterns), book = obj(p.order_book), identity = obj(p.identity);
  const real = ['REAL CME','REAL EXCHANGE'].includes(status), unit = p.quantity_unit || (real ? 'contracts' : 'estimated activity units');
  $('proStatus').textContent = status; $('proStatus').className = 'pill ' + tone(status);
  $('proSignal').textContent = p.signal || 'UNAVAILABLE'; $('proSignal').className = tone(p.signal);
  $('proAge').textContent = p.data_age_seconds == null ? 'Waiting' : `${fmt(p.data_age_seconds,1)}s old`; $('proAge').className = 'pill ' + (real ? 'positive' : 'neutral');
  $('proTodayDelta').textContent = today.net_delta == null ? '—' : `${Number(today.net_delta) >= 0 ? '+' : ''}${Number(today.net_delta).toLocaleString()}`;
  $('proSession').textContent = p.session_definition || 'UTC day'; $('proSource').textContent = p.source || '—';
  $('proThreshold').textContent = p.large_trade_threshold == null ? unit : `Burst threshold ${p.large_trade_threshold} ${p.threshold_unit || ''}`;
  $('proBuyContracts').textContent = today.buy_contracts == null ? '—' : Number(today.buy_contracts).toLocaleString();
  $('proSellContracts').textContent = today.sell_contracts == null ? '—' : Number(today.sell_contracts).toLocaleString();
  $('proBuyTrades').textContent = `${today.buy_trades ?? 0} ${real ? 'trades' : 'bursts'}`; $('proSellTrades').textContent = `${today.sell_trades ?? 0} ${real ? 'trades' : 'bursts'}`;
  $('proLargestBuy').textContent = today.largest_buy == null ? '—' : Number(today.largest_buy).toLocaleString(); $('proLargestSell').textContent = today.largest_sell == null ? '—' : Number(today.largest_sell).toLocaleString();
  $('proLargestBuyUnit').textContent = real ? 'contracts' : 'activity units'; $('proLargestSellUnit').textContent = real ? 'contracts' : 'activity units';
  const directional = Math.max(0, Number(today.buy_contracts || 0) + Number(today.sell_contracts || 0)); const bp = directional ? Number(today.buy_contracts || 0) / directional * 100 : 50, sp = 100 - bp;
  $('proBuyBar').style.width = `${bp}%`; $('proSellBar').style.width = `${sp}%`; $('proBuyPct').textContent = `BUY ${fmt(bp,1)}%`; $('proSellPct').textContent = `SELL ${fmt(sp,1)}%`;
  $('proWindows').innerHTML = ['1m','5m','15m','1h'].map(k => { const x = obj(windows[k]); return `<div class="flow-window"><div><h3>${k.toUpperCase()}</h3><strong class="${tone(x.dominant)}">${esc(x.dominant || 'BALANCED')}</strong></div><p>BUY ${Number(x.buy_contracts || 0).toLocaleString()} · SELL ${Number(x.sell_contracts || 0).toLocaleString()} · Δ ${Number(x.net_delta) >= 0 ? '+' : ''}${Number(x.net_delta || 0).toLocaleString()}</p></div>`; }).join('');
  $('proCluster').textContent = patterns.cluster || 'NONE'; $('proCluster').className = tone(patterns.cluster);
  $('proAbsorption').textContent = patterns.absorption || 'NONE'; $('proAbsorption').className = tone(patterns.absorption);
  $('proIceberg').textContent = patterns.iceberg || 'NONE'; $('proIceberg').className = tone(patterns.iceberg);
  $('proIdentity').textContent = identity.note || 'Participant identity is unavailable.';

  $('bookStatus').textContent = book.status || 'WAITING'; $('bookStatus').className = 'pill ' + tone(book.status);
  $('bookBidTotal').textContent = book.bid_wall_contracts == null ? '—' : Number(book.bid_wall_contracts).toLocaleString();
  $('bookAskTotal').textContent = book.ask_wall_contracts == null ? '—' : Number(book.ask_wall_contracts).toLocaleString();
  $('bookImbalance').textContent = book.resting_imbalance_percent == null ? '—' : `${Number(book.resting_imbalance_percent) >= 0 ? '+' : ''}${fmt(book.resting_imbalance_percent,1)}%`;
  $('bookImbalance').className = Number(book.resting_imbalance_percent) > 5 ? 'positive' : Number(book.resting_imbalance_percent) < -5 ? 'negative' : 'neutral';
  const wallHtml = (items, side) => arr(items).length ? arr(items).map(x => `<div class="wall-row ${side}"><span>${fmt(x.price)} · ${esc(x.label || x.instrument_id || 'ZONE')}</span><b>${Number(x.contracts || 0).toLocaleString()}</b></div>`).join('') : '<div class="empty">No active zones</div>';
  $('bookBidWalls').innerHTML = wallHtml(book.bid_walls, 'buy'); $('bookAskWalls').innerHTML = wallHtml(book.ask_walls, 'sell');
  $('bookSpoof').textContent = `Spoof warning: ${book.spoof_warning || 'UNAVAILABLE'}`; $('bookSpoof').className = tone(book.spoof_warning); $('bookNote').textContent = book.note || 'Waiting for liquidity map.';

  const tape = arr(p.recent_large_trades); const unitLabel = real ? 'CONTRACTS' : 'ACTIVITY';
  $('proTrades').innerHTML = tape.length ? tape.map(x => `<div class="tape-row"><span class="tape-side ${String(x.side || 'unknown').toLowerCase()}">${esc(x.side || 'UNKNOWN')}</span><div class="tape-main"><b>${fmt(x.price)} · ${esc(x.symbol || 'XAUUSD')}</b><small>${timeAgo(x.time)} · ${esc(x.source || 'LOCAL')} ${x.reason ? `· ${esc(x.reason)}` : ''}</small></div><div class="tape-size"><b>${Number(x.size || 0).toLocaleString()}</b><small>${unitLabel}</small></div></div>`).join('') : `<div class="empty">No statistically unusual ${real ? 'exchange trades' : 'MT5 activity bursts'} yet.</div>`;
  const blocks = arr(p.block_trades);
  $('proBlocks').innerHTML = blocks.length ? blocks.map(x => `<div class="tape-row"><span class="tape-side unknown">BLOCK</span><div class="tape-main"><b>${fmt(x.price)} · ${esc(x.impact_estimate || 'Reaction pending')}</b><small>${timeAgo(x.time)} · ${esc(x.source || 'EXCHANGE')}</small></div><div class="tape-size"><b>${Number(x.size || 0).toLocaleString()}</b><small>CONTRACTS</small></div></div>`).join('') : '<div class="empty">No confirmed exchange block data. No-key mode does not invent blocks.</div>';
  $('proError').textContent = p.error || p.exchange_error || '';
}

function renderPlan(p) {
  $('planStatus').textContent = p.status || 'NO TRADE'; $('planStatus').className = 'pill ' + (p.status === 'ACTIVE' ? tone(p.direction) : 'muted');
  $('entryZone').textContent = p.entry_low == null ? '—' : `${fmt(p.entry_low)} – ${fmt(p.entry_high)}`;
  $('stopLoss').textContent = fmt(p.stop_loss); $('tp1').textContent = fmt(p.tp1); $('tp2').textContent = fmt(p.tp2); $('invalidation').textContent = p.invalidation || 'Wait for alignment.';
}
function renderReasons(reasons, warnings) {
  const r = arr(reasons); $('reasonList').innerHTML = r.length ? r.map(x => `<div class="reason"><i></i><p>${esc(x)}</p></div>`).join('') : '<div class="empty">Waiting for live analysis.</div>';
  const w = arr(warnings); $('warningPanel').classList.toggle('hidden', !w.length); $('warningList').innerHTML = w.map(x => `<div class="reason warning"><i></i><p>${esc(x)}</p></div>`).join('');
}
function renderVolume(vp) {
  $('vpStatus').textContent = vp.status || 'OFFLINE'; $('vpStatus').className = 'pill ' + (vp.status === 'LIVE' ? 'positive' : 'muted');
  $('vah').textContent = fmt(vp.vah); $('poc').textContent = fmt(vp.poc); $('val').textContent = fmt(vp.val);
  $('vpBias').textContent = `${vp.location || '—'} · ${vp.bias || '—'} · VWAP ${fmt(vp.session_vwap)}`; $('vpBias').className = tone(vp.bias);
  $('vpMeaning').textContent = vp.note || 'Waiting for volume profile.';
  const rows = arr(vp.rows); const step = rows.length > 1 ? Math.abs(Number(rows[1].price) - Number(rows[0].price)) : 0;
  $('volumeChart').innerHTML = rows.length ? rows.map(r => { const isPoc = Math.abs(Number(r.price) - Number(vp.poc)) <= step * 0.6; return `<div class="vbar ${r.value_area ? 'value' : ''} ${isPoc ? 'poc' : ''}" title="${esc(r.price)} · ${esc(r.relative)}% · Δ ${esc(r.delta)}"><i style="height:${Math.max(2, Number(r.relative || 0))}%"></i></div>`; }).join('') : '<div class="empty">No profile data</div>';
}
function renderCot(c) {
  $('cotStatus').textContent = c.status || 'OFFLINE'; $('cotStatus').className = 'pill ' + (['LIVE','CACHED'].includes(c.status) ? tone(c.status === 'LIVE' ? 'LIVE' : 'NEUTRAL') : 'muted');
  $('cotBias').textContent = c.bias || 'UNAVAILABLE'; $('cotBias').className = tone(c.bias);
  $('cotDate').textContent = `Report ${c.report_date || '—'}${c.age_days != null ? ` · ${c.age_days} days old` : ''}`;
  $('cotNet').textContent = c.managed_money_net == null ? '—' : Number(c.managed_money_net).toLocaleString();
  $('cotChange').textContent = c.weekly_net_change == null ? 'Weekly change —' : `Weekly change ${c.weekly_net_change >= 0 ? '+' : ''}${Number(c.weekly_net_change).toLocaleString()}`;
  $('cotLong').textContent = c.managed_money_long == null ? '—' : Number(c.managed_money_long).toLocaleString(); $('cotShort').textContent = c.managed_money_short == null ? '—' : Number(c.managed_money_short).toLocaleString(); $('cotPct').textContent = c.net_percent_open_interest == null ? '—' : `${fmt(c.net_percent_open_interest,2)}%`; $('cotNote').textContent = c.note || 'COT is a weekly confirmation filter.';
  const cats = arr(c.categories); $('cotCategories').innerHTML = cats.length ? cats.map(x => `<div class="category-card"><div class="category-top"><b>${esc(x.label)}</b><span class="${Number(x.net) >= 0 ? 'positive' : 'negative'}">NET ${Number(x.net) >= 0 ? '+' : ''}${Number(x.net || 0).toLocaleString()}</span></div><div class="category-values"><span>LONG <b>${Number(x.long || 0).toLocaleString()}</b></span><span>SHORT <b>${Number(x.short || 0).toLocaleString()}</b></span></div><small>${esc(x.meaning || '')}</small><small>Reported traders: long ${x.long_traders ?? 'suppressed'} · short ${x.short_traders ?? 'suppressed'}</small></div>`).join('') : '<div class="empty">No category data.</div>';
  const id = obj(c.identity); $('identityLevel').textContent = `Identity: ${id.available_level || 'category only'}`; $('identityNote').textContent = id.note || 'Individual institution names are not public.';
}
function renderIntelligence(i) {
  const bank = obj(i.bank_participation), sec = obj(i.named_institutions), combined = obj(bank.combined), us = obj(bank.us_banks), nonUs = obj(bank.non_us_banks);
  $('intelStatus').textContent = i.collector_state === 'REFRESHING' ? 'REFRESHING' : (i.status || 'WAITING');
  $('intelStatus').className = 'pill ' + (['LIVE','PARTIAL','CACHED'].includes(i.status) ? tone(i.bias) : 'muted');
  $('intelBias').textContent = i.bias || 'WAITING'; $('intelBias').className = tone(i.bias);
  $('intelUpdated').textContent = i.updated_at ? `Updated ${timeAgo(i.updated_at)} · cached locally` : 'No cached report yet';
  const score = Number(i.score || 0); $('intelScore').textContent = `${score >= 0 ? '+' : ''}${score.toFixed(2)}`; $('intelScore').className = score > .5 ? 'positive' : score < -.5 ? 'negative' : 'neutral';

  $('bprStatus').textContent = bank.status || 'WAITING'; $('bprStatus').className = 'pill ' + (['LIVE','CACHED'].includes(bank.status) ? 'positive' : bank.status === 'PARTIAL' ? 'neutral' : 'muted');
  $('bprInterpretation').textContent = bank.interpretation || '—'; $('bprInterpretation').className = tone(Number(bank.score || 0) > 0 ? 'BULLISH' : Number(bank.score || 0) < 0 ? 'BEARISH' : 'NEUTRAL');
  $('bprDate').textContent = `Report ${bank.report_date || '—'}${bank.age_days != null ? ` · ${bank.age_days} days old` : ''}`;
  $('bprCombinedNet').textContent = bank.status === 'UNAVAILABLE' ? '—' : `${Number(combined.net || 0) >= 0 ? '+' : ''}${Number(combined.net || 0).toLocaleString()}`;
  $('bprMonthlyChange').textContent = bank.monthly_net_change == null ? 'Monthly change —' : `Monthly net change ${Number(bank.monthly_net_change) >= 0 ? '+' : ''}${Number(bank.monthly_net_change).toLocaleString()}`;
  $('bprUsLong').textContent = us.long == null ? '—' : Number(us.long).toLocaleString(); $('bprUsShort').textContent = us.short == null ? '—' : Number(us.short).toLocaleString();
  $('bprNonLong').textContent = nonUs.long == null ? '—' : Number(nonUs.long).toLocaleString(); $('bprNonShort').textContent = nonUs.short == null ? '—' : Number(nonUs.short).toLocaleString();
  $('bprUsCount').textContent = us.bank_count == null ? 'Bank count unavailable' : `${Number(us.bank_count)} banks`; $('bprNonCount').textContent = nonUs.bank_count == null ? 'Bank count unavailable' : `${Number(nonUs.bank_count)} banks`;
  $('bprNote').textContent = bank.note || bank.error || 'Waiting for the official CFTC monthly report.';

  $('secStatus').textContent = sec.status || 'WAITING'; $('secStatus').className = 'pill ' + (['LIVE','PARTIAL','CACHED'].includes(sec.status) ? tone(sec.bias) : 'muted');
  $('secBias').textContent = sec.bias || '—'; $('secBias').className = tone(sec.bias);
  $('secDate').textContent = `Latest report ${sec.report_date || '—'}${sec.age_days != null ? ` · ${sec.age_days} days old` : ''}`;
  const inc = Number(sec.institutions_increased || 0), dec = Number(sec.institutions_reduced || 0);
  $('secChangeCount').textContent = `${inc + dec}`; $('secChangeDetail').textContent = `Increased ${inc} · Reduced ${dec}`;
  const institutions = arr(sec.institutions);
  $('secInstitutions').innerHTML = institutions.length ? institutions.map(x => {
    const change = Number(x.weighted_share_change_percent || 0), assets = arr(x.gold_assets);
    const assetText = assets.slice(0,3).map(a => `${esc(a.issuer || 'Gold asset')} · ${Number(a.shares || 0).toLocaleString()} shares`).join('<br>') || 'No matching gold ETF line items';
    return `<div class="institution-card"><div class="institution-top"><div><b>${esc(x.name || 'Institution')}</b><small>${esc(x.delay_label || 'DELAYED PUBLIC DISCLOSURE')} · report ${esc(x.report_date || '—')}</small></div><span class="${change > 1 ? 'positive' : change < -1 ? 'negative' : 'neutral'}">${esc(x.action || 'STABLE')} ${change >= 0 ? '+' : ''}${change.toFixed(1)}%</span></div><div class="institution-meta"><span>GOLD ASSETS <b>${Number(x.gold_asset_count || 0)}</b></span><span>REPORTED VALUE <b>$${Number(x.reported_value_thousands_usd || 0).toLocaleString()}k</b></span></div><p>${assetText}</p></div>`;
  }).join('') : '<div class="empty">No named gold-related 13F holdings are cached yet.</div>';
  $('secNote').textContent = sec.note || sec.error || 'Waiting for SEC EDGAR filings.';
  const errors = [...arr(i.errors), ...arr(sec.errors)]; $('intelErrors').textContent = errors.length ? errors.slice(0,4).join(' · ') : '';
  if (i.collector_state === 'REFRESHING') $('intelRefreshMessage').textContent = 'Refreshing official public sources in the background. Live MT5 analysis continues normally.';
}

function renderOrderFlow(o) {
  const status = o.status || 'WARMING UP', quality = obj(o.quality), windows = obj(o.windows);
  $('ofStatus').textContent = status; $('ofStatus').className = 'pill ' + (status.includes('LIVE') ? 'positive' : 'muted');
  $('ofSignal').textContent = o.signal || 'WARMING UP'; $('ofSignal').className = tone(o.signal);
  const score = Number(o.score || 0); $('ofScore').textContent = `${score >= 0 ? '+' : ''}${score.toFixed(2)}`; $('ofScore').className = score > 1 ? 'positive' : score < -1 ? 'negative' : 'neutral';
  $('ofAge').textContent = o.data_age_seconds == null ? 'No ticks' : `${fmt(o.data_age_seconds, 2)}s old · Q${Number(quality.score || 0)}`;
  $('ofSource').textContent = o.mode || 'MT5 PROXY'; $('ofLatency').textContent = o.calculation_latency_ms == null ? 'Calculation —' : `Calculation ${fmt(o.calculation_latency_ms, 2)} ms`;

  const order = ['5s','15s','30s','1m','5m'];
  $('ofWindows').innerHTML = order.map(k => {
    const x = obj(windows[k]), dp = Number(x.delta_percent || 0);
    return `<div class="flow-window"><div><h3>${k.toUpperCase()}</h3><strong class="${tone(x.dominant)}">${esc(x.dominant || 'BALANCED')}</strong></div><p>BUY ${Number(x.buy_events || 0)} · SELL ${Number(x.sell_events || 0)} · Δ ${dp >= 0 ? '+' : ''}${dp.toFixed(1)}%</p><p>${fmt(x.tick_rate,2)} ticks/s · move ${fmt(x.price_change)}</p></div>`;
  }).join('');

  const stacked = obj(o.stacked_imbalances); $('ofStacked').textContent = stacked.label || 'NONE'; $('ofStacked').className = 'pill ' + tone(stacked.label);
  const footprint = arr(o.footprint_proxy).slice(-16).reverse();
  $('ofFootprint').innerHTML = footprint.length ? footprint.map(x => {
    const buy = Math.max(0, Number(x.buy_activity || 0)), sell = Math.max(0, Number(x.sell_activity || 0)), total = buy + sell || 1;
    const bp = buy / total * 100, sp = 100 - bp, delta = Number(x.delta || 0);
    return `<div class="footprint-cell"><div class="fp-top"><b>${timeAgo(x.time)}</b><span class="${tone(x.imbalance)}">${esc(x.imbalance || 'BALANCED')}</span></div><div class="fp-delta"><span>BUY ${buy.toLocaleString()}</span><span>SELL ${sell.toLocaleString()}</span></div><div class="fp-bar"><i style="width:${bp}%"></i><i style="width:${sp}%"></i></div><small>Δ ${delta >= 0 ? '+' : ''}${delta.toLocaleString()} · ${fmt(x.delta_percent,1)}% · ratio ${fmt(x.imbalance_ratio,2)}</small></div>`;
  }).join('') : '<div class="empty">Waiting for completed M1 bars.</div>';

  const heat = arr(o.nearby_liquidity);
  $('ofHeatmap').innerHTML = heat.length ? heat.map(x => `<div class="heatmap-row" style="--heat:${Math.max(2,Math.min(100,Number(x.intensity||0)))}%"><b>${fmt(x.price)}</b><span>${esc(x.label || 'REACTION ZONE')} · ${Number(x.touches || 0)} touches · ${fmt(x.distance_points,0)} pts away</span><em class="${tone(x.side)}">${esc(x.side || 'BALANCED')}</em></div>`).join('') : '<div class="empty">No nearby reaction zones yet.</div>';

  const absorption = obj(o.absorption), iceberg = obj(o.iceberg_proxy), blocks = obj(o.block_trade_monitor), dark = obj(o.dark_pool_monitor);
  $('ofAbsorption').textContent = absorption.status || 'NONE'; $('ofAbsorption').className = tone(absorption.side); $('ofAbsorptionScore').textContent = `Evidence ${fmt(absorption.evidence_score,0)}/100 · estimate`;
  $('ofIceberg').textContent = iceberg.status || 'NONE'; $('ofIceberg').className = tone(iceberg.side); $('ofIcebergScore').textContent = `Evidence ${fmt(iceberg.evidence_score,0)}/100 · not confirmed`;
  $('ofBlocks').textContent = String(blocks.status || 'UNAVAILABLE').includes('UNAVAILABLE') ? 'UNAVAILABLE' : blocks.status; $('ofBlocks').className = 'negative';
  $('ofDark').textContent = String(dark.status || 'HIDDEN').includes('NOT') ? 'HIDDEN' : dark.status; $('ofDark').className = 'negative';

  const tapeRow = x => `<div class="tape-row"><span class="tape-side ${String(x.side||'').toLowerCase()}">${esc(x.side || '—')}</span><div class="tape-main"><b>${esc(x.label || x.type || 'ACTIVITY')}</b><small>${timeAgo(x.time)} · ${Number(x.events || 0)} quote/activity events · ${Number(x.duration_ms || 0)} ms</small></div><div class="tape-size"><b>${fmt(x.price)}</b><small>${fmt(x.move_points,1)} pts · score ${fmt(x.activity_score,2)}</small></div></div>`;
  const tape = arr(o.tape_proxy); $('ofTape').innerHTML = tape.length ? tape.slice(0,30).map(tapeRow).join('') : '<div class="empty">No fast quote clusters.</div>';
  const large = arr(o.large_activity_filter); $('ofLarge').innerHTML = large.length ? large.slice(0,30).map(tapeRow).join('') : '<div class="empty">No statistically unusual activity detected.</div>';
}


function renderGlobalFlow(g, cot, intel) {
  const exchange = obj(g.exchange), today = obj(exchange.today), book = obj(exchange.order_book), spot = obj(g.mt5_spot), lbma = obj(g.lbma), connector = obj(g.mt5_comex_connector), bridge = obj(g.file_bridge);
  const status = g.status || 'WAITING', conflict = Boolean(g.cross_market_conflict);
  $('gfStatus').textContent = status; $('gfStatus').className = 'pill ' + tone(status);
  $('gfSignal').textContent = g.signal || 'BALANCED'; $('gfSignal').className = tone(g.signal);
  $('gfScore').textContent = `${Number(g.score || 0) >= 0 ? '+' : ''}${fmt(g.score,1)}`;
  $('gfConfirmation').textContent = `Final confirmation ${Number(g.confirmation_score || 0) >= 0 ? '+' : ''}${fmt(g.confirmation_score,1)}`;
  $('gfCoverage').textContent = `${Math.round(Number(g.source_coverage || 0))}%`;
  $('gfAgreement').textContent = `Agreement ${Math.round(Number(g.agreement_percent || 0))}%`;
  $('gfConflict').textContent = conflict ? 'CROSS-MARKET CONFLICT' : 'NO CONFLICT'; $('gfConflict').className = 'pill ' + (conflict ? 'negative' : 'positive');
  $('gfNote').textContent = g.note || 'Independent-source agreement strengthens confidence while live safety gates remain primary.';

  $('gfComexStatus').textContent = exchange.status || 'NOT CONNECTED'; $('gfComexStatus').className = 'pill ' + tone(exchange.status);
  $('gfComexBuy').textContent = today.buy_contracts == null ? '—' : Number(today.buy_contracts).toLocaleString();
  $('gfComexSell').textContent = today.sell_contracts == null ? '—' : Number(today.sell_contracts).toLocaleString();
  $('gfComexDelta').textContent = today.net_delta == null ? '—' : `${Number(today.net_delta) >= 0 ? '+' : ''}${Number(today.net_delta).toLocaleString()}`; $('gfComexDelta').className = tone(today.dominant);
  $('gfComexSignal').textContent = exchange.signal || '—'; $('gfComexSignal').className = tone(exchange.signal);
  $('gfComexSymbol').textContent = connector.symbol || obj(arr(exchange.recent_large_trades)[0]).symbol || '—';
  $('gfComexAge').textContent = exchange.data_age_seconds == null ? '—' : `${fmt(exchange.data_age_seconds,1)}s`;
  $('gfComexExactness').textContent = g.exact_comex_active ? 'EXACT CONNECTED FUTURES CONTRACT VOLUME' : (connector.volume_exactness || 'OPTIONAL EXACT LAYER');
  $('gfComexNote').textContent = connector.note || exchange.note || 'Exact only for the connected futures contract.';

  $('gfSpotStatus').textContent = spot.status || 'OFFLINE'; $('gfSpotStatus').className = 'pill ' + tone(spot.status);
  $('gfSpotSignal').textContent = spot.signal || '—'; $('gfSpotSignal').className = tone(spot.signal);
  $('gfSpotScore').textContent = `${Number(spot.score || 0) >= 0 ? '+' : ''}${fmt(spot.score,1)}`;
  $('gfSpotQuality').textContent = spot.data_quality == null ? '—' : `${fmt(spot.data_quality,0)}/100`;
  $('gfSpotNote').textContent = spot.note || 'Real-time broker activity estimate.';

  $('gfBookStatus').textContent = book.status || 'NO BOOK'; $('gfBookStatus').className = 'pill ' + tone(book.status);
  $('gfBidLiquidity').textContent = book.bid_wall_contracts == null ? '—' : Number(book.bid_wall_contracts).toLocaleString();
  $('gfAskLiquidity').textContent = book.ask_wall_contracts == null ? '—' : Number(book.ask_wall_contracts).toLocaleString();
  $('gfBookImbalance').textContent = book.resting_imbalance_percent == null ? '—' : `${Number(book.resting_imbalance_percent) >= 0 ? '+' : ''}${fmt(book.resting_imbalance_percent,1)}%`; $('gfBookImbalance').className = tone(Number(book.resting_imbalance_percent || 0) >= 0 ? 'BUY' : 'SELL');
  const wallRows = (items, side) => arr(items).length ? arr(items).slice(0,5).map(x => `<div class="wall-row ${side}"><b>${fmt(x.price)}</b><span>${Number(x.contracts || x.size || x.quantity || 0).toLocaleString()} contracts</span></div>`).join('') : '<div class="empty">No exact MBO source</div>';
  $('gfBidWalls').innerHTML = wallRows(book.bid_walls || book.top_bids, 'buy');
  $('gfAskWalls').innerHTML = wallRows(book.ask_walls || book.top_asks, 'sell');

  $('gfLbmaStatus').textContent = lbma.status || 'WAITING'; $('gfLbmaStatus').className = 'pill ' + tone(lbma.status);
  $('gfLbmaValue').textContent = lbma.gold_turnover_usd_bn == null ? '—' : `$${Number(lbma.gold_turnover_usd_bn).toLocaleString()}bn`;
  $('gfLbmaPeriod').textContent = lbma.period_ending ? `Period ending ${lbma.period_ending}` : 'Period —';
  $('gfLbmaNote').textContent = lbma.note || 'Liquidity context only; no live BUY/SELL split.';

  $('gfStructuralStatus').textContent = (cot.status || intel.status || 'WAITING'); $('gfStructuralStatus').className = 'pill ' + tone(cot.bias || intel.bias);
  $('gfCotBias').textContent = cot.bias || '—'; $('gfCotBias').className = tone(cot.bias);
  $('gfCotScore').textContent = `${Number(cot.score || 0) >= 0 ? '+' : ''}${fmt(cot.score,1)}`;
  $('gfIntelBias').textContent = intel.bias || '—'; $('gfIntelBias').className = tone(intel.bias);

  const matrix = arr(g.source_matrix);
  $('gfSourceMatrix').innerHTML = matrix.length ? matrix.map(x => `<div class="source-row"><div><b>${esc(x.name || 'Source')}</b><small>${esc(x.quality || '')}</small></div><span class="${tone(x.status)}">${esc(x.status || 'WAITING')}</span><p>${esc(x.note || '')}</p></div>`).join('') : '<div class="empty">Waiting for source status.</div>';
  $('gfMt5Connector').textContent = connector.status || '—'; $('gfMt5Connector').className = tone(connector.status);
  $('gfFileBridge').textContent = bridge.status || '—'; $('gfFileBridge').className = tone(bridge.status);
  $('gfAcceptedEvents').textContent = Number(bridge.accepted_trades || 0) + Number(bridge.accepted_book_events || 0) + Number(connector.accepted_trades || 0);
  $('gfConnectorNote').textContent = bridge.note || connector.note || 'No source connected.';
}

function renderSmc(s) {
  $('smcStructure').textContent = s.structure || '—'; $('smcStructure').className = tone(s.structure); $('smcBos').textContent = s.bos || 'BOS —';
  $('smcChoch').textContent = s.choch || 'NONE'; $('smcChoch').className = tone(s.choch); $('smcSweep').textContent = s.liquidity_sweep || 'NONE'; $('smcSweep').className = tone(s.liquidity_sweep);
  $('smcNearOb').textContent = s.nearest_order_block || 'NONE'; $('smcNearOb').className = tone(s.nearest_order_block); $('buyLiquidity').textContent = fmt(s.buy_side_liquidity); $('sellLiquidity').textContent = fmt(s.sell_side_liquidity);
  $('smcDealingRange').textContent = s.dealing_range || '—'; $('smcEquilibrium').textContent = fmt(s.equilibrium);
  const fvg = s.bullish_fvg || s.bearish_fvg; $('smcFvg').textContent = fvg ? `${fvg.type} ${fmt(fvg.low)}–${fmt(fvg.high)}` : 'NONE'; $('smcFvg').className = tone(fvg && fvg.type);
  $('smcAdvancedNote').textContent = s.note || 'Waiting for M5 history.';
  const zones = [s.bullish_order_block, s.bearish_order_block].filter(Boolean); $('orderBlocks').innerHTML = zones.length ? zones.map(z => `<div class="zone-card"><div class="zone-top"><b class="${tone(z.type)}">${esc(z.type)} ORDER BLOCK</b><span>${esc(z.status || '')} · ${timeAgo(z.time)}</span></div><p>${fmt(z.low)} – ${fmt(z.high)} · strength ${fmt(z.strength,2)}</p></div>`).join('') : '<div class="empty">No valid order-block estimate.</div>';
}
function renderTimeframes(frames) {
  $('timeframeCards').innerHTML = ['M1','M5','M15','H1','H4'].map(tf => { const x = obj(frames[tf]), score = Number(x.score || 0), trendClass = String(x.trend).includes('BULL') ? 'bull' : String(x.trend).includes('BEAR') ? 'bear' : 'mix'; return `<article class="tf-card"><div class="tf-head"><b>${tf}</b><span class="trend ${trendClass}">${esc(x.trend || 'NO DATA')} · ${esc(x.regime || '—')}</span></div><div class="tf-metrics"><div><span>SCORE</span><b>${score >= 0 ? '+' : ''}${score.toFixed(1)}</b></div><div><span>RSI 14</span><b>${fmt(x.rsi14,1)}</b></div><div><span>ADX 14</span><b>${fmt(x.adx14,1)}</b></div><div><span>ATR 14</span><b>${fmt(x.atr14)}</b></div></div><div class="tf-score"><i style="width:${Math.max(0, Math.min(100, 50 + score / 2))}%;background:${score > 10 ? 'var(--green)' : score < -10 ? 'var(--red)' : 'var(--gold)'}"></i></div></article>`; }).join('');
}

function renderValidation(v, sig) {
  const pctText = value => value === null || value === undefined ? '—' : `${fmt(value,1)}%`;
  $('valStatus').textContent = v.status || 'WAITING'; $('valStatus').className = 'pill ' + tone(v.status);
  $('valMode').textContent = v.mode || 'READ-ONLY';
  $('valSampleStatus').textContent = v.sample_status || 'INSUFFICIENT SAMPLE'; $('valSampleStatus').className = tone(v.sample_status);
  $('valPrecision').textContent = pctText(v.tp1_first_rate); $('valPrecision').className = Number(v.tp1_first_rate || 0) >= 55 ? 'positive' : Number(v.tp1_first_rate || 0) > 0 ? 'neutral' : '';
  $('valJudged').textContent = `${Number(v.judged_sample || 0).toLocaleString()} judged signals`;
  $('valOpen').textContent = Number(v.open_signals || 0).toLocaleString();
  $('valTotal').textContent = `${Number(v.total_trade_signals || 0).toLocaleString()} total recorded`;
  $('valBuyRate').textContent = pctText(v.buy_tp1_first_rate);
  $('valSellRate').textContent = pctText(v.sell_tp1_first_rate);
  $('valTp2').textContent = Number(v.tp2_reached || 0).toLocaleString();
  $('valAmbiguous').textContent = Number(v.ambiguous || 0).toLocaleString();
  $('valNote').textContent = v.note || 'Forward paper validation is active.';

  const buckets = arr(v.confidence_buckets);
  $('valBuckets').innerHTML = buckets.length ? buckets.map(x => {
    const rate = x.observed_tp1_first_rate == null ? '—' : `${fmt(x.observed_tp1_first_rate,1)}%`;
    const sample = Number(x.sample || 0);
    return `<div class="calibration-card"><span>${esc(x.label || '—')}</span><b class="${sample >= 5 && Number(x.observed_tp1_first_rate || 0) >= 55 ? 'positive' : sample >= 5 && Number(x.observed_tp1_first_rate || 0) < 45 ? 'negative' : ''}">${rate}</b><small>${sample} judged</small><i style="width:${Math.max(0,Math.min(100,Number(x.observed_tp1_first_rate || 0)))}%"></i></div>`;
  }).join('') : '<div class="empty">Signals must accumulate before calibration becomes meaningful.</div>';
  const current = obj(v.current_confidence_bucket);
  $('valCurrentBucket').textContent = current.sample ? `${current.label} · ${current.sample} SAMPLE` : (v.sample_status || 'UNCALIBRATED');
  $('valCurrentBucket').className = 'pill ' + (current.sample >= 10 ? tone(Number(current.observed_tp1_first_rate || 0) >= 55 ? 'GOOD' : 'CAUTION') : 'muted');

  const regimes = arr(v.regime_performance);
  $('valRegimes').innerHTML = regimes.length ? regimes.map(x => `<div class="validation-row"><div><b>${esc(x.regime || 'UNKNOWN')}</b><small>${Number(x.sample || 0)} judged</small></div><strong class="${Number(x.tp1_first_rate || 0) >= 55 ? 'positive' : Number(x.tp1_first_rate || 0) < 45 ? 'negative' : 'neutral'}">${fmt(x.tp1_first_rate,1)}%</strong></div>`).join('') : '<div class="empty">No judged regime sample yet.</div>';

  const weakness = arr(v.weakness_diagnostics);
  $('valWeakness').innerHTML = weakness.length ? weakness.map(x => `<div class="reason ${String(x.severity || '').includes('CAUTION') ? 'warning' : ''}"><i></i><div><b>${esc(x.label || 'Observation')}</b><p>${esc(x.detail || '')}</p></div></div>`).join('') : '<div class="empty">Waiting for enough resolved paper signals.</div>';

  const recent = arr(v.recent_signals);
  $('valRecent').innerHTML = recent.length ? recent.slice(0,25).map(x => {
    const outcome = x.first_outcome || x.status || 'OPEN';
    const outcomeClass = outcome === 'TP1' || String(x.status).includes('TP2') ? 'positive' : outcome === 'SL' || String(x.status).includes('CANCELLED') ? 'negative' : 'neutral';
    const follow = [`MFE ${fmt(x.mfe_r,2)}R`,`MAE ${fmt(x.mae_r,2)}R`,x.h1_r == null ? null : `1h ${Number(x.h1_r)>=0?'+':''}${fmt(x.h1_r,2)}R`].filter(Boolean).join(' · ');
    return `<div class="validation-signal"><div class="validation-signal-top"><b class="${tone(x.action)}">${esc(x.action || '—')}</b><span>${timeAgo(x.time)}</span><strong class="${outcomeClass}">${esc(outcome)}</strong></div><p>${fmt(x.signal_price)} · alignment ${fmt(x.alignment,0)}% · ${esc(x.regime || '—')}</p><small>${esc(follow)}${x.exact_comex_active ? ' · COMEX exact active' : ''}</small>${x.note ? `<em>${esc(x.note)}</em>` : ''}</div>`;
  }).join('') : '<div class="empty">No live BUY/SELL signal has been recorded yet.</div>';

  const bucketRate = sig.observed_bucket_rate;
  if (bucketRate != null && Number(sig.observed_bucket_sample || 0) > 0) {
    $('qualityNote').textContent += ` · Similar alignment bucket observed ${fmt(bucketRate,1)}% TP1-first across ${Number(sig.observed_bucket_sample)} judged signals.`;
  }
}

function renderSystem(d, s) {
  const inst = obj(d.institutional), p = obj(inst.pro_flow), intel = obj(inst.intelligence), of = obj(inst.order_flow_lab), validation = obj(d.validation); $('sysMt5').textContent = s.mt5 || 'OFFLINE'; $('sysMt5').className = tone(s.mt5); $('sysBroker').textContent = d.broker || '—';
  $('sysEngine').textContent = s.engine || 'WAITING'; $('sysEngine').className = tone(s.engine); $('sysMode').textContent = d.mode || 'OFFLINE'; $('sysMode').className = tone(d.mode); $('sysSymbol').textContent = d.symbol || 'XAUUSD';
  $('sysProFlow').textContent = p.status || 'WAITING'; $('sysProFlow').className = tone(p.status); $('sysProSource').textContent = p.source || 'No-key engine active';
  $('sysIntel').textContent = intel.collector_state === 'REFRESHING' ? 'REFRESHING' : (intel.status || 'WAITING'); $('sysIntel').className = tone(intel.bias); $('sysIntelSource').textContent = intel.source_mode || 'Official public cache';
  $('sysOrderFlow').textContent = of.status || 'WARMING UP'; $('sysOrderFlow').className = tone(of.signal); $('sysOrderFlowSource').textContent = of.mode || 'No-key MT5 proxy';
  $('sysValidation').textContent = validation.sample_status || validation.status || 'WAITING'; $('sysValidation').className = tone(validation.sample_status); $('sysValidationSource').textContent = `${Number(validation.judged_sample || 0)} judged · ${Number(validation.open_signals || 0)} open`;
  if (state.desktopInfo?.phone_url && $('sysPort')) { try { $('sysPort').textContent = `Port ${new URL(state.desktopInfo.phone_url).port || '8787'}`; } catch (_) {} }
}
function drawChart() {
  const canvas = $('priceChart'), wrap = canvas.parentElement, series = arr(state.data?.price_series); $('chartEmpty').style.display = series.length ? 'none' : 'grid';
  if (!series.length || wrap.clientWidth < 100) return; const dpr = window.devicePixelRatio || 1, w = wrap.clientWidth, h = wrap.clientHeight;
  canvas.width = w * dpr; canvas.height = h * dpr; canvas.style.width = w + 'px'; canvas.style.height = h + 'px'; const ctx = canvas.getContext('2d'); ctx.scale(dpr,dpr); ctx.clearRect(0,0,w,h);
  const vals = series.map(x => Number(x.close)).filter(Number.isFinite); if (vals.length < 2) return; let min = Math.min(...vals), max = Math.max(...vals); const pad = (max - min || 1) * .14; min -= pad; max += pad;
  const mx = 12, my = 18, plotW = w - mx * 2, plotH = h - my * 2; ctx.strokeStyle = 'rgba(255,255,255,.06)'; ctx.lineWidth = 1;
  for (let i=0;i<5;i++){ const y=my+plotH*i/4;ctx.beginPath();ctx.moveTo(mx,y);ctx.lineTo(w-mx,y);ctx.stroke(); }
  ctx.beginPath(); vals.forEach((v,i)=>{ const x=mx+plotW*i/(vals.length-1),y=my+plotH*(max-v)/(max-min);i?ctx.lineTo(x,y):ctx.moveTo(x,y); });
  const grad=ctx.createLinearGradient(0,0,w,0);grad.addColorStop(0,'#9d7222');grad.addColorStop(.55,'#f2c45f');grad.addColorStop(1,'#36e39c');ctx.strokeStyle=grad;ctx.lineWidth=2.2;ctx.stroke();
  const last=vals[vals.length-1],ly=my+plotH*(max-last)/(max-min);ctx.setLineDash([4,4]);ctx.strokeStyle='rgba(242,196,95,.5)';ctx.beginPath();ctx.moveTo(mx,ly);ctx.lineTo(w-mx,ly);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='#f2c45f';ctx.font='11px Segoe UI';ctx.fillText(last.toFixed(2),w-58,Math.max(12,ly-5));
}

if ($('refreshIntelligence')) $('refreshIntelligence').onclick = async () => {
  $('intelRefreshMessage').textContent = 'Queuing background refresh…';
  try {
    const base = native ? String(state.payload?.serverUrl || '').replace(/\/$/, '') : '';
    if (native && !base) throw new Error('Windows server URL is not connected');
    const r = await fetch(`${base}/api/v1/institution/refresh`, {method:'POST', cache:'no-store'});
    const result = await r.json();
    $('intelRefreshMessage').textContent = result.message || (result.queued ? 'Refresh queued.' : 'Refresh not queued.');
  } catch (e) {
    $('intelRefreshMessage').textContent = `Refresh request failed: ${e.message || e}`;
  }
};


if ($('exportValidation')) $('exportValidation').onclick = async () => {
  $('valExportMessage').textContent = 'Preparing CSV export…';
  try {
    const base = native ? String(state.payload?.serverUrl || '').replace(/\/$/, '') : '';
    if (native && !base) throw new Error('Windows server URL is not connected');
    const r = await fetch(`${base}/api/v1/validation/export.csv`, {cache:'no-store'});
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const blob = await r.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'AuRa-X-Signals-Paper-Journal.csv';
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 2000);
    $('valExportMessage').textContent = 'Paper journal CSV exported.';
  } catch (e) {
    $('valExportMessage').textContent = `Export failed: ${e.message || e}`;
  }
};

loadData();
setTimeout(loadDesktopInfo, 800);
setInterval(() => { if (native) Android.refresh(); else loadData(); }, 650);
setInterval(() => { if (native) loadData(); }, 350);
addEventListener('resize', () => state.page === 'timeframes' && drawChart());
