@echo off
setlocal
set "APPDIR=%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%APPDIR%Uninstall-AuRa-X-Signals.ps1"
exit /b %ERRORLEVEL%
