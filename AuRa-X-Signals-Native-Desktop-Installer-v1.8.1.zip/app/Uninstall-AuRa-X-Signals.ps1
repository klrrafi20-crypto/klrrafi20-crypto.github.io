$ErrorActionPreference = 'SilentlyContinue'
$InstallDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Clear-Host
Write-Host 'AuRa X Signals Uninstaller' -ForegroundColor Yellow
$answer = Read-Host 'Remove AuRa X Signals, its shortcuts and local environment? (Y/N)'
if ($answer -notmatch '^[Yy]') { exit 1 }
Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -and $_.CommandLine -match 'desktop_app\.py|run_signals\.py' -and $_.CommandLine -match 'AuRa.X.Signals|aurax' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Remove-Item (Join-Path ([Environment]::GetFolderPath('Desktop')) 'AuRa X Signals.lnk') -Force
Remove-Item (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\AuRa X Signals') -Recurse -Force
Remove-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\AuRaXSignals' -Recurse -Force
try { Start-Process powershell.exe -Verb RunAs -Wait -ArgumentList @('-NoProfile','-Command',('Get-NetFirewallRule -DisplayName ''AuRa X Signals Mobile'' -ErrorAction SilentlyContinue | Remove-NetFirewallRule')) } catch {}
$cleanup = Join-Path $env:TEMP 'Remove-AuRa-X-Signals.ps1'
@"
Start-Sleep -Seconds 2
Remove-Item -LiteralPath '$($InstallDir.Replace("'","''"))' -Recurse -Force -ErrorAction SilentlyContinue
"@ | Set-Content -Path $cleanup -Encoding UTF8
Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $cleanup + '"'))
Write-Host 'AuRa X Signals has been removed.' -ForegroundColor Green
Start-Sleep -Seconds 1
exit 0
