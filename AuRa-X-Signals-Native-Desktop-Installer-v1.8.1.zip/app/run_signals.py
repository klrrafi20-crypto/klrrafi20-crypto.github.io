from pathlib import Path
import json
import signal
import sys
import time

from aurax_signals.engine import AuRaSignalsEngine
from aurax_signals.server import SignalsServer


def main() -> int:
    root = Path(__file__).resolve().parent
    settings = json.loads((root / "config" / "settings.json").read_text(encoding="utf-8"))
    engine = AuRaSignalsEngine(root)
    server = SignalsServer(root, engine, int(settings.get("port", 8787)))
    engine.start()
    server.start()
    print("\n" + "=" * 66)
    print("  AuRa X Signals v1.8.1 — ENGINE-ONLY MODE")
    print("=" * 66)
    print(f"PC dashboard : http://127.0.0.1:{server.port}")
    print(f"Phone URL    : {server.address}")
    print("MT5 must remain open and logged in. No paid API key is required.")
    print("This tool never places trades.")
    print("Press Ctrl+C to stop.\n")
    stopping = False
    def stop(*_):
        nonlocal stopping
        stopping = True
    signal.signal(signal.SIGINT, stop)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, stop)
    try:
        while not stopping:
            time.sleep(0.5)
    finally:
        server.stop()
        engine.stop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
