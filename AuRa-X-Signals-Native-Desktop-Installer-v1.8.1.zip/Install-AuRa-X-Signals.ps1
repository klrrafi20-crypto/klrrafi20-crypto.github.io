$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$ProductName = 'AuRa X Signals'
$Version = '1.8.1'
$SourceDir = Join-Path $PSScriptRoot 'app'
$InstallDir = Join-Path $env:LOCALAPPDATA $ProductName
$StartMenuDir = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\AuRa X Signals'
$DesktopShortcut = Join-Path ([Environment]::GetFolderPath('Desktop')) 'AuRa X Signals.lnk'
$LogFile = Join-Path $env:TEMP 'AuRa-X-Signals-Install.log'

function Write-Step([string]$Text) {
    Write-Host "`n>> $Text" -ForegroundColor Yellow
    Add-Content -Path $LogFile -Value "$(Get-Date -Format s) | $Text"
}
function Fail([string]$Text) {
    Write-Host "`nERROR: $Text" -ForegroundColor Red
    Write-Host "Installer log: $LogFile" -ForegroundColor DarkGray
    Read-Host 'Press Enter to close'
    exit 1
}
function Find-Python312 {
    try {
        $candidate = (& py -3.12 -c "import sys; print(sys.executable)" 2>$null | Select-Object -Last 1).Trim()
        if ($candidate -and (Test-Path $candidate)) { return $candidate }
    } catch {}
    $candidate = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'
    if (Test-Path $candidate) { return $candidate }
    return $null
}
function Test-WebView2Runtime {
    $keys = @(
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}',
        'HKLM:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}',
        'HKCU:\Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}'
    )
    foreach ($key in $keys) {
        try {
            $version = (Get-ItemProperty -Path $key -Name pv -ErrorAction Stop).pv
            if ($version -and $version -ne '0.0.0.0') { return $true }
        } catch {}
    }
    return $false
}
function New-Shortcut([string]$Path, [string]$Target, [string]$Arguments, [string]$WorkingDirectory, [string]$Icon) {
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($Path)
    $shortcut.TargetPath = $Target
    $shortcut.Arguments = $Arguments
    $shortcut.WorkingDirectory = $WorkingDirectory
    $shortcut.IconLocation = "$Icon,0"
    $shortcut.Description = 'Hybrid XAUUSD signals with validation, calibration, optional COMEX flow and strict source labels'
    $shortcut.Save()
}

try {
    "AuRa X Signals installer started $(Get-Date)" | Set-Content -Path $LogFile
    Clear-Host
    Write-Host '==============================================================' -ForegroundColor DarkYellow
    Write-Host '     AuRa X Signals v1.8.1 - Native Desktop Installer' -ForegroundColor Yellow
    Write-Host '==============================================================' -ForegroundColor DarkYellow
    Write-Host 'Installs a real Windows application window, icon and shortcuts.'
    Write-Host 'All v1.8 features are preserved. v1.8.1 fixes native-window sizing and responsive layouts for laptops and phones.'

    if (-not (Test-Path (Join-Path $SourceDir 'desktop_app.py'))) {
        Fail 'The installer package is incomplete. Extract the full ZIP before running Setup.'
    }

    Write-Step 'Closing any older AuRa X Signals desktop process'
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -and $_.CommandLine -match 'desktop_app\.py|run_signals\.py' -and $_.CommandLine -match 'AuRa.X.Signals|aurax' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

    Write-Step "Installing application files to $InstallDir"
    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
    # Preserve existing logs but replace application code and interface files.
    $exclude = @('.venv', 'logs', 'config\desktop-storage')
    Get-ChildItem -Path $SourceDir -Force | ForEach-Object {
        if ($_.Name -notin @('.venv','logs')) {
            Copy-Item -Path $_.FullName -Destination $InstallDir -Recurse -Force
        }
    }
    New-Item -ItemType Directory -Path (Join-Path $InstallDir 'logs') -Force | Out-Null
    New-Item -ItemType Directory -Path (Join-Path $InstallDir 'data') -Force | Out-Null

    Write-Step 'Checking Python 3.12'
    $Python = Find-Python312
    if (-not $Python) {
        if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
            Fail 'Python 3.12 is required. Install 64-bit Python 3.12 and run this installer again.'
        }
        Write-Host 'Python 3.12 is missing. Windows Package Manager will install it now.' -ForegroundColor Cyan
        & winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
        if ($LASTEXITCODE -ne 0) { Fail 'Python 3.12 installation failed.' }
        $Python = Find-Python312
        if (-not $Python) { Fail 'Python was installed but could not be detected. Restart Windows and run Setup again.' }
    }
    Write-Host "Python: $Python" -ForegroundColor Green

    Write-Step 'Checking Microsoft Edge WebView2 Runtime'
    if (-not (Test-WebView2Runtime)) {
        if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
            Fail 'Microsoft Edge WebView2 Runtime is missing. Install it from Microsoft, then run Setup again.'
        }
        Write-Host 'Installing the Microsoft WebView2 Runtime required for the native application window...' -ForegroundColor Cyan
        & winget install -e --id Microsoft.EdgeWebView2Runtime --accept-package-agreements --accept-source-agreements
        if ($LASTEXITCODE -ne 0 -or -not (Test-WebView2Runtime)) {
            Fail 'WebView2 Runtime installation failed. Install Microsoft Edge WebView2 Runtime and retry.'
        }
    }
    Write-Host 'WebView2 Runtime: ready' -ForegroundColor Green

    $VenvPython = Join-Path $InstallDir '.venv\Scripts\python.exe'
    $VenvPythonW = Join-Path $InstallDir '.venv\Scripts\pythonw.exe'
    if (-not (Test-Path $VenvPython)) {
        Write-Step 'Creating isolated AuRa X environment'
        & $Python -m venv (Join-Path $InstallDir '.venv')
        if ($LASTEXITCODE -ne 0) { Fail 'Could not create the Python environment.' }
    }

    Write-Step 'Installing MT5 connector and native desktop window components'
    & $VenvPython -m pip install --disable-pip-version-check --upgrade pip
    if ($LASTEXITCODE -ne 0) { Fail 'pip upgrade failed.' }
    & $VenvPython -m pip install --disable-pip-version-check -r (Join-Path $InstallDir 'requirements.txt')
    if ($LASTEXITCODE -ne 0) { Fail 'Required components could not be installed. Check the internet connection.' }

    Write-Step 'Creating Desktop and Start Menu shortcuts'
    New-Item -ItemType Directory -Path $StartMenuDir -Force | Out-Null
    $Icon = Join-Path $InstallDir 'assets\aurax_signals.ico'
    $DesktopArgs = '"' + (Join-Path $InstallDir 'desktop_app.py') + '"'
    New-Shortcut -Path $DesktopShortcut -Target $VenvPythonW -Arguments $DesktopArgs -WorkingDirectory $InstallDir -Icon $Icon
    New-Shortcut -Path (Join-Path $StartMenuDir 'AuRa X Signals.lnk') -Target $VenvPythonW -Arguments $DesktopArgs -WorkingDirectory $InstallDir -Icon $Icon
    New-Shortcut -Path (Join-Path $StartMenuDir 'Repair AuRa X Signals.lnk') -Target 'powershell.exe' -Arguments ('-NoProfile -ExecutionPolicy Bypass -File "' + (Join-Path $InstallDir 'Repair-AuRa-X-Signals.ps1') + '"') -WorkingDirectory $InstallDir -Icon $Icon
    New-Shortcut -Path (Join-Path $StartMenuDir 'Uninstall AuRa X Signals.lnk') -Target (Join-Path $InstallDir 'Uninstall-AuRa-X-Signals.bat') -Arguments '' -WorkingDirectory $InstallDir -Icon $Icon
    New-Shortcut -Path (Join-Path $StartMenuDir 'Global Flow Guide.lnk') -Target 'notepad.exe' -Arguments ('"' + (Join-Path $InstallDir 'COMEX-GLOBAL-FLOW-GUIDE.txt') + '"') -WorkingDirectory $InstallDir -Icon $Icon
    New-Shortcut -Path (Join-Path $StartMenuDir 'Validation Guide.lnk') -Target 'notepad.exe' -Arguments ('"' + (Join-Path $InstallDir 'VALIDATION-GUIDE.txt') + '"') -WorkingDirectory $InstallDir -Icon $Icon
    New-Shortcut -Path (Join-Path $StartMenuDir 'Phone Connection Guide.lnk') -Target 'notepad.exe' -Arguments ('"' + (Join-Path $InstallDir 'PHONE-CONNECTION-GUIDE.txt') + '"') -WorkingDirectory $InstallDir -Icon $Icon

    Write-Step 'Registering the application in Windows Apps list'
    $UninstallKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\AuRaXSignals'
    New-Item -Path $UninstallKey -Force | Out-Null
    New-ItemProperty -Path $UninstallKey -Name DisplayName -Value $ProductName -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $UninstallKey -Name DisplayVersion -Value $Version -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $UninstallKey -Name Publisher -Value 'AuRa X' -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $UninstallKey -Name InstallLocation -Value $InstallDir -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $UninstallKey -Name DisplayIcon -Value $Icon -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $UninstallKey -Name UninstallString -Value ('"' + (Join-Path $InstallDir 'Uninstall-AuRa-X-Signals.bat') + '"') -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $UninstallKey -Name NoModify -Value 1 -PropertyType DWord -Force | Out-Null

    Write-Step 'Requesting Windows Firewall permission for Android connection'
    $FirewallScript = Join-Path $InstallDir 'Configure-Firewall.ps1'
    try {
        $proc = Start-Process powershell.exe -Verb RunAs -Wait -PassThru -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $FirewallScript + '"'))
        if ($proc.ExitCode -eq 0) {
            Write-Host 'Phone connection firewall access enabled.' -ForegroundColor Green
        } else {
            Write-Host 'Firewall permission was skipped. The Windows app will still work; Android connection may require Repair later.' -ForegroundColor Yellow
        }
    } catch {
        Write-Host 'Firewall permission was not granted. The Windows app will still work.' -ForegroundColor Yellow
    }

    Write-Step 'Installation complete'
    Write-Host ''
    Write-Host 'AuRa X Signals v1.8.1 is installed. Existing validation data and every v1.8 feature are preserved.' -ForegroundColor Green
    Write-Host 'Desktop shortcut: AuRa X Signals' -ForegroundColor Green
    Write-Host 'It opens inside its own window and does not launch a browser.' -ForegroundColor Green
    Write-Host ''
    Write-Host 'Open MetaTrader 5 and log in before using live signals.' -ForegroundColor Cyan
    Write-Host 'On weekends the app will correctly show MARKET CLOSED.' -ForegroundColor Cyan

    $answer = Read-Host 'Launch AuRa X Signals now? (Y/N)'
    if ($answer -match '^[Yy]') {
        Start-Process -FilePath $VenvPythonW -ArgumentList $DesktopArgs -WorkingDirectory $InstallDir
    }
    exit 0
} catch {
    Add-Content -Path $LogFile -Value ($_ | Out-String)
    Fail $_.Exception.Message
}
