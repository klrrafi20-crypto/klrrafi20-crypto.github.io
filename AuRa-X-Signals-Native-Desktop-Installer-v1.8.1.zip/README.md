# AuRa X Signals v1.8.1 — Responsive Validation Edition

Version 1.8 preserves every v1.7 feature and adds a forward paper-validation system. It is still a read-only Windows + Android XAUUSD decision-support tool; it never places trades.

## Complete workflow

1. MT5 supplies XAUUSD bid/ask, unique ticks, spread and M1–H4 completed candles.
2. The engine checks data freshness, spread stability, market state and timeframe conflict.
3. All existing indicators, SMC, Volume Profile, VWAP, Order Flow, public institutional context and optional COMEX data remain available.
4. Correlated inputs are grouped into four independent evidence families before the final decision score:
   - Trend Context
   - Structure & Location
   - Live Flow
   - Macro Bias
5. BUY / SELL / WAIT is published only after confirmation and safety gates.
6. The paper journal records each published BUY/SELL, waits for the proposed entry zone, then evaluates completed M1 bars for TP1, TP2 and SL.
7. Validation statistics show confidence-bucket performance, regime performance, MFE/MAE, 15m/1h/4h follow-through and false-signal weaknesses.

## Why grouping helps

Every v1.7 component is still calculated and displayed. The grouped decision score prevents several correlated indicators from repeatedly counting the same price move. The old all-component score is also stored as `legacy_score` for audit and comparison.

## Validation rules

- Journal mode is paper-only.
- Entry must touch the proposed entry zone before outcome tracking begins.
- TP1-before-SL is the primary judged outcome.
- If TP1 and SL occur inside the same completed M1 candle, the result is marked `AMBIGUOUS` and excluded from precision.
- Signals that never touch entry are marked untriggered/expired rather than losses.
- Alignment percentage is not a guaranteed win probability.
- The app does not automatically optimize thresholds from a small sample.

## Validation tab

- Total, open and judged signals
- TP1-before-SL rate
- BUY and SELL performance
- TP2 count
- Confidence calibration buckets
- Market-regime performance
- Weakness diagnostics
- Recent signal replay journal
- CSV export

## Existing tabs preserved

Signal, Pro Flow, Order Flow, Global Flow, Market Data, Intelligence, Smart Money, Timeframes, System and every existing data connector remain intact.

## Installation

1. Close the older AuRa X Signals app.
2. Extract the complete installer ZIP.
3. Run `Install-AuRa-X-Signals.bat` over the existing installation.
4. Keep MetaTrader 5 open and logged in.
5. Use the desktop shortcut.

An in-place install preserves the local journal and logs. Use Uninstall only when you intentionally want a clean removal.

The journal database is stored locally under the application `data` folder and is designed to survive normal upgrades.

## Android

- Version name: **1.8**
- Version code: **9**
- Package: `com.rafi.auraxsignalapp`
- Uses the same v1.5+ signing identity.
