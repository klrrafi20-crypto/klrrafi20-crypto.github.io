@echo off
setlocal
cd /d "%~dp0"
title AuRa X Signals Setup v1.8.1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-AuRa-X-Signals.ps1"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo Installation did not complete. Error code: %RC%
  pause
)
exit /b %RC%
